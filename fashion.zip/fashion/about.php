<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>About US</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <!-- About starts -->
    <div class="about-us">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h3>Know More <span class="about">About Us</span></h3>
                <p>We M/s One Step Fashions Pvt Ltd are a Belagavi based company located at Club, Road Belagavi. We are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids.</p>

                <p>We believe in being updated and so we have our own digital platform which provides us the reach beyond boundaries.</p>
                <p>We believe in updating with technological advancements so as to take advantages of the market changes by meeting the changing requirements of customers.</p>
                <p>Through this initiative we want to help people to improve their Life style and upgrade their standard of living. We provide them with opportunity to earn unlimited income through their own smart work.</p>
                <h2>Welcome to your dream <span class="about-fashion">Os Fashion</span></h2>


            </div>
            <div class="col-md-3">
                <img src="img/about-1.jpg" alt="About Us Image">
            </div>
            <div class="col-md-3">
                <img src="img/about-2.jpg" alt="About Us Image">
            </div>
        </div>
    </div>
</div>
<div class="vision-mission">
<div class="container">
    <div class="row">
        <div class="col-md">
            <h3>Vision</h3>
            <ul>
                <li><p>To be among the top corporates known for being following the best ethical practices at all levels from administration to customer satisfaction.</p></li>
                <li><p>To provide opportunities of self-employment through our business model.</p></li>
                <li><p>To provide job opportunities in our organisation to the deserving candidates.</p></li>
                <li><p>To be involved in social responsibility activities so as to give back to the society from the earning what we have made by associating with non-profit making organisations involved in educational or environmental or economic upliftment activities of general public.</p></li>
            </ul>
            <h3>Mission</h3>
            <ul>
                <li><p>To create future Business Leaders. WE WANT TO BE A PART OF NATION BUILDING by creating administrators or business leaders.</p></li>
            </ul>

        </div>
    </div>
</div>
</div>



    <!-- About ends -->  
    
    <!-- Partner Logo Section Begin -->
    <div class="partner-logo">
        <div class="container">
            <div class="logo-carousel owl-carousel">
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-1.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-2.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-3.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-4.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-5.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Partner Logo Section End -->

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>
</body>

</html>
<?php

session_start();
// if (!isset($_SESSION['user_email'])) {
//     header('Location: index.php');
// }

include_once('conn/conn.php');
$db = new DatabaseClass();
$con = $db->getCon();
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>Address</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <!-- My Profile Begin -->
    <div class="my-profile mt-5">
        <div class="container">
            <div class="mobile-quick-access">
                <div class="row">
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="myprofile.php" class="text-dark">My Profile</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow  p-2 text-center">
                        <a href="my_orders.php" class="text-dark">My Orders</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="mlm.php" class="text-dark">My Network</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center my-profile-color">
                        <a href="add_address.php" class="text-white">Add Address</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="my_credit_history.php" class="text-dark">My Credits</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="withdraw.php" class="text-dark">My Withdrawal</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="kyc.php" class="text-dark">My KYC</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="identity_card.php" class="text-dark">My ID</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="networking_business_plan.php" class="text-dark">Networking Business Plans</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3 desktop-quick-access">
                    <h4>Quick Access</h4>

                    <ul class="quick-menu">
                        <li class="list"><a href="myprofile.php">My Profile</a></li>
                        <li class="list"><a href="my_orders.php">My Orders</a></li>
                        <li class="list"><a href="mlm.php">My Network</a></li>
                        <li class="list"><a href="add_address.php">Add Address</a></li>
                        <li class="list"><a href="withdraw.php">My Withdrawal</a></li>
                        <li class="list"><a href="kyc.php">My KYC</a></li>
                        <li class="list"><a href="identity_card.php">My ID</a></li>
                        <li class="list"><a href="networking_business_plan.php">N & B Plans</a></li>
                    </ul>
                </div>


                <div class="add-address text-center">
                    <h2 class="text-center">Add <span>Your</span> Address</h2>
                    <div class="container" id="address">
                        <div class="col-md-12 card">
                            <form class="pt-3" id="addressForm" method="post" action="">
                                <div class="form-row">
                                    <input type="hidden" class="form-control" id="txtId" placeholder="Full Name"
                                        value="">

                                    <div class="form-group col-md-6">
                                        <label for="inputEmail4" class="text-left">Full Name</label>
                                        <input type="text" class="form-control" id="txtFullName" placeholder="Full Name"
                                            value="">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="inputPassword4" class="text-left">Mobile Number</label>
                                        <input type="text" class="form-control" id="txtMobileNo1"
                                            placeholder="Mobile Number" onkeypress="return isNumberKey(event);"
                                            maxlength="10">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputAddress" class="text-left">Address</label>
                                    <textarea type="text" class="form-control" id="txtAddress" placeholder="Address"></textarea>
                                </div>
                                <div class="form-group d-none">
                                    <label for="inputAddress2" class="text-left">Address
                                        2<span>(optional)</span></label>
                                    <input type="text" class="form-control" id="txtAddress2" placeholder="Address2">
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-4">
                                        <label for="inputCity" class="text-left">City</label>
                                        <input type="text" class="form-control" id="txtCity" placeholder="city">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="inputState" class="text-left">State</label>
                                        <select id="txtState" class="form-control">
                                            <option selected value="">Choose...</option>
                                            <?php
                                            $sql = "SELECT DISTINCT(st_name), st_id FROM state ORDER BY st_name ASC";
                                            $query = $con->query($sql);
                                            while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
                                                echo '<option value="' . $row['st_id'] . '">' . $row['st_name'] . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="inputZip" class="text-left">Pincode</label>
                                        <input type="text" class="form-control" id="txtPincode" placeholder="pincode">
                                    </div>
                                    <button type="button" id="addNewAddress" value="Submit">Save</button>
                            </form>
                        </div>
                    </div>
                    <!-- <div class="container mt-3"> -->
                    <div class="row  mt-3">
                        <div class="col-md-12" id="addressList">

                            <!-- <div class="card mb-4 shadow-lg">
                                    <div class="card-body">
                                        <p class="card-text"><b>'+lclJSON.userAddress[i].ads_fullName+','+lclJSON.userAddress[i].ads_address+','+lclJSON.userAddress[i].ads_pincode+' &emsp;'+lclJSON.userAddress[i].ads_city+', '+lclJSON.userAddress[i].ads_state+', '+lclJSON.userAddress[i].ads_mobile_number+'</b></p>
                                        <a href="JavaScript:void(0)" onclick="deleteAddress('+addressID+');" class="font-weight-bold  text-secondary btn">Edit</a>
                                        <a href="#" class="font-weight-bold text-danger btn">Delete</a>
                                    </div>
                                </div> -->

                        </div>
                    </div>


                    <!-- </div> -->

                </div>
            </div>
        </div>
    </div>

    <!-- My Profile Begin -->

    <!-- Partner Logo Section Begin -->
    <div class="partner-logo">
        <div class="container">
            <div class="logo-carousel owl-carousel">
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-1.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-2.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-3.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-4.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-5.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Partner Logo Section End -->

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsMyProfile.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>

</body>

</html>
<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$params = $_REQUEST;

	$lclQuery = "SELECT * FROM admin_login WHERE ad_lg_email = '".$params["inputEmail"]."' AND ad_lg_password = '".$params["inputPassword"]."'";
	$lclResult = $con->query($lclQuery);

	if($lclResult->rowCount() > 0) {
		if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
			$_SESSION["user_email"] = $_POST["inputEmail"];
			$_SESSION["username"] = $row['ad_lg_name'];
			$_SESSION["role"] = $row['ad_lg_role'];

			echo "1";
			
		}
	} else {
		echo "10";
	}

?>
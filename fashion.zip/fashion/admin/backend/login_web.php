<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();

	$lclQuery = "SELECT * FROM login_web WHERE lgw_email = '".$_POST["inputEmail"]."' AND lgw_password = '".$_POST["inputPassword"]."'";
	$lclResult = $con->query($lclQuery);

	if($lclResult->rowCount() > 0) {
		$_SESSION["infynow_web"] = $_POST["inputEmail"];
		$_SESSION["selMedium"] = $_POST["selMedium"];
		$_SESSION["selClass"] = $_POST["selClass"];
		header("Location: ../../learn.php");
	} else {
		header("Location: ../../login.php");
	}

?>
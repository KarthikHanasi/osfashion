<?php
	session_start();
  	// session_unset($_SESSION["infynow_username"]);
	session_unset();
  	session_destroy();
  	header("Location: ../index.php");
?>
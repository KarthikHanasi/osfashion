<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'add':
			addClass($params, $con);
			break;

		case 'update':
			updateClass($params, $con);
			break;

		case 'delete':
			deleteClass($params, $con);
			break;
	}

	function addClass($params, $con) {
		$lclQuery = $con->prepare("INSERT INTO about_us (ab_header_name, ab_description, ab_vision, ab_mission) VALUES(:ab_header_name, :ab_description, :ab_vision, :ab_mission)");

		$lclQuery->bindParam(':ab_header_name', $params['txtHeader']);
		$lclQuery->bindParam(':ab_description', $params['txtDescription']);
		$lclQuery->bindParam(':ab_vision', $params['txtVision']);
		$lclQuery->bindParam(':ab_mission', $params['txtMission']);
		// $lclQuery->bindParam(':al_user_email', $_SESSION["infynow_username"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function updateClass($params, $con) {
		if($params["txtImage1"] == "") {
			move_uploaded_file($_FILES["phPhoto1"]["tmp_name"],"../../uploads/img/about_us/".$params["id"]."-about.jpg");       
        $imageURL ="uploads/img/about_us/".$params["id"]."-about.jpg";
		} else {
			$imageURL = $params["txtImage1"];
		}

		$lclQuery = $con->prepare("UPDATE about_us SET 
							  ab_header_name = :ab_header_name,
							  ab_description = :ab_description,
							  ab_vision = :ab_vision,
							  ab_mission = :ab_mission,
							  ab_choose = :ab_choose,
							  ab_image = :ab_image

							  WHERE ab_id = :ab_id");

		$lclQuery->bindParam(':ab_header_name', $params['txtHeader1']);
		$lclQuery->bindParam(':ab_description', $params['txtDescription1']);
		$lclQuery->bindParam(':ab_vision', $params['txtVision1']);
		$lclQuery->bindParam(':ab_mission', $params['txtMission1']);
		$lclQuery->bindParam(':ab_choose', $params['txtChoose1']);
		$lclQuery->bindParam(':ab_image', $imageURL);
		$lclQuery->bindParam(':ab_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function deleteClass($params, $con) {

		$lclQuery = $con->prepare("UPDATE about_us SET 
							  ab_status = :ab_status

							  WHERE ab_id = :ab_id");

		$lclQuery->bindParam(':ab_status', $lclStatus);
		$lclQuery->bindParam(':ab_id', $params["id"]);
		$lclStatus = 1;

		$lclResult = $lclQuery->execute();
		echo "1";
	}


?>


<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'add':
			addData($params, $con);
			break;

		case 'update':
			updateData($params, $con);
			break;

		case 'delete':
			deleteData($params, $con);
			break;
	}

	function addData($params, $con) {

		$lclQuery = "SELECT * FROM admin_login WHERE ad_lg_email = '".$params['txtEmail']."'";
	    $lclResult = $con->query($lclQuery); 


 		if($lclResult->rowCount() > 0) {
	         echo "10";
	    } else {
	    	
			$lclQuery = $con->prepare("INSERT INTO admin_login (ad_lg_name, ad_lg_email, ad_lg_mobile, ad_lg_password, ad_lg_role, ad_created_by) VALUES(:ad_lg_name, :ad_lg_email, :ad_lg_mobile, :ad_lg_password, :ad_lg_role, :ad_created_by)");

			$lclQuery->bindParam(':ad_lg_name', $params['txtName']);
			$lclQuery->bindParam(':ad_lg_email', $params['txtEmail']);
			$lclQuery->bindParam(':ad_lg_mobile', $params['txtMobileNo']);
			$lclQuery->bindParam(':ad_lg_password', $params['txtPassword']);
			$lclQuery->bindParam(':ad_lg_role', $params['selRole']);
			$lclQuery->bindParam(':ad_created_by', $params["loggedInBy"]);
			$lclResult = $lclQuery->execute();
			echo "1";
		}


		
	}

	function updateData($params, $con) {

		$lclQuery = $con->prepare("UPDATE admin_login SET 
							  ad_lg_name = :ad_lg_name,
							  ad_lg_email = :ad_lg_email,
							  ad_lg_mobile = :ad_lg_mobile,
							  ad_lg_password = :ad_lg_password,	
							  ad_lg_role = :ad_lg_role
							  WHERE ad_lg_id = :ad_lg_id");

		$lclQuery->bindParam(':ad_lg_name', $params['txtName1']);
		$lclQuery->bindParam(':ad_lg_email', $params['txtEmail1']);
		$lclQuery->bindParam(':ad_lg_mobile', $params['txtMobileNo1']);
		$lclQuery->bindParam(':ad_lg_password', $params['txtPassword1']);
		$lclQuery->bindParam(':ad_lg_role', $params['selRole1']);
		$lclQuery->bindParam(':ad_lg_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function deleteData($params, $con) {

		$lclQuery = "DELETE FROM admin_login WHERE ad_lg_id = ".$params['id'];

		$lclQuery = $con->query($lclQuery);
		echo "1";
	}


?>


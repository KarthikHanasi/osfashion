<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'add':
			add($params, $con);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;
	}

	function add($params, $con) {
		$lclQuery1 = "SELECT * FROM area WHERE ar_name = '".$params['txtName']."' AND ar_status = 0";
	    $lclResult1 = $con->query($lclQuery1); 

	    if($lclResult1->rowCount() > 0) {
	         echo "10";
	    } else {
		$lclQuery = $con->prepare("INSERT INTO area (ar_name, ar_distance, ar_created_by) VALUES(:ar_name, :ar_distance, :ar_created_by)");

		$lclQuery->bindParam(':ar_name', $params['txtName']);
		$lclQuery->bindParam(':ar_distance', $params['txtDistance']);
		$lclQuery->bindParam(':ar_created_by',$_SESSION["user_email"]);

		$lclResult = $lclQuery->execute();
		echo "1";
	}
}

	function update($params, $con) {

		$lclQuery = $con->prepare("UPDATE area SET 
							  ar_name = :ar_name,
							  ar_distance = :ar_distance

							  WHERE ar_id = :ar_id");

		$lclQuery->bindParam(':ar_name', $params['txtName1']);
		$lclQuery->bindParam(':ar_distance', $params['txtDistance1']);
		$lclQuery->bindParam(':ar_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}


	function delete($params, $con) {

		$lclQuery = $con->prepare("UPDATE area SET 
							  ar_status = :ar_status
							  
							  WHERE ar_id = :ar_id");

		$lclQuery->bindParam(':ar_status', $lclStatus);
		$lclQuery->bindParam(':ar_id', $params["id"]);
		$lclStatus = 1;
		$lclResult = $lclQuery->execute();

		echo "1";
	}


?>
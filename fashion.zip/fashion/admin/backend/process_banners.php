<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'add':
			add($params, $con);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;
	}

	function add($params, $con) {

		$lclQuery = "SELECT count(*) AS total FROM banners";
	    $lclResult = $con->query($lclQuery); 

	  	if($lclResult->rowCount() > 0) {
	          if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {

	              $lclID1 = $row['total'];
	              $lclID = $lclID1 + 1;

	            }
	    } else {
	    	$lclID = 1;
	    }

		move_uploaded_file($_FILES["fileImage"]["tmp_name"],"../../uploads/img/banners/".$lclID.".jpg");       
        $imageURL ="uploads/img/banners/".$lclID.".jpg";
		
		$lclQuery = $con->prepare("INSERT INTO banners (bn_image, bn_title) VALUES(:bn_image, :bn_title)");

		$lclQuery->bindParam(':bn_image', $imageURL);
		$lclQuery->bindParam(':bn_title', $params['txtTitle']);

		$lclResult = $lclQuery->execute();
		echo "1";
	}


	function update($params, $con) {

		if($params["imageURL1"] == "") {
			move_uploaded_file($_FILES["fileImage1"]["tmp_name"],"../../uploads/img/banners/".$params["id"].".jpg");
        	$imageURL ="uploads/img/banners/".$params["id"].".jpg";
		} else {
			$imageURL = $params["imageURL1"];
		}

		$lclQuery = $con->prepare("UPDATE banners SET 
							  bn_image = :bn_image,
							  bn_title = :bn_title

							  WHERE bn_id = :bn_id");

		$lclQuery->bindParam(':bn_image', $imageURL);
		$lclQuery->bindParam(':bn_title', $params['txtTitle1']);
		$lclQuery->bindParam(':bn_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function delete($params, $con) {

		$lclQuery = $con->prepare("UPDATE banners SET 
							  bn_status = :bn_status

							  WHERE bn_id = :bn_id");

		$lclQuery->bindParam(':bn_status', $lclStatus);
		$lclQuery->bindParam(':bn_id', $params["id"]);
		$lclStatus = 1;
		$lclResult = $lclQuery->execute();
		echo "1";
	}


?>


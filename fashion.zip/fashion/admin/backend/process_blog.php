<?php
	session_start();
	error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'add':
			addSubject($params, $con);
			break;

		case 'update':
			updateSubject($params, $con);
			break;

		case 'delete':
			deleteSubject($params, $con);
			break;
	}

	function addSubject($params, $con) {

		$lclQuery = "SELECT bl_id FROM blog ORDER BY bl_id DESC";
    	$lclResult = $con->query($lclQuery); 

	    if($lclResult->rowCount() > 0) {
	          if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {

	              $lclID1 = $row['bl_id'];
	              $lclID = $lclID1 + 1;

	            }
	    } else {
	    	$lclID = 1;
	    }

	   echo $date =  $params['date']."-".$params['month']."-".$params['year'];

	$lclQuery = $con->prepare("INSERT INTO blog (bl_image, bl_title, bl_content, bl_date, bl_created_by) VALUES(:bl_image, :bl_title, :bl_content,  :bl_date, :bl_created_by)");

		move_uploaded_file($_FILES["imageBlog"]["tmp_name"],"../../uploads/img/blog/".$lclID."-blog.jpg");     
        $imageBlogURL = "uploads/img/blog/".$lclID."-blog.jpg";
       
		$lclQuery->bindParam(':bl_image', $imageBlogURL);
		$lclQuery->bindParam(':bl_title', $params['txtTitle']);
		$lclQuery->bindParam(':bl_content', $params['txtContent']);
		$lclQuery->bindParam(':bl_date', $date);
		$lclQuery->bindParam(':bl_created_by', $_SESSION["infynow_username"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function updateSubject($params, $con) {

		if($params["imageURL1"] == "") {
			move_uploaded_file($_FILES["imageBlog1"]["tmp_name"],"../../uploads/img/blog/".$params["id"]."-blog.jpg");     
        	$imageBlogURL = "uploads/img/blog/".$params["id"]."-blog.jpg";
		} else {
			$imageBlogURL = $params["imageURL1"];
		}

		 // $date = $params['date']."-".$params['month'].$params['year'];

		$lclQuery = $con->prepare("UPDATE blog SET 
							  bl_image = :bl_image,
							  bl_title = :bl_title,
							  bl_content = :bl_content,
							  -- bl_date = :bl_date
							  WHERE bl_id = :bl_id");

		$lclQuery->bindParam(':bl_image', $imageBlogURL);
		$lclQuery->bindParam(':bl_title', $params['txtTitle1']);
		$lclQuery->bindParam(':bl_content', $params['txtContent1']);
		// $lclQuery->bindParam(':bl_date', $date);
		$lclQuery->bindParam(':bl_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function deleteSubject($params, $con) {

		$lclQuery = "DELETE FROM blog WHERE bl_id = ".$params['id'];

		$lclQuery = $con->query($lclQuery);
		echo "1";
	}


?>


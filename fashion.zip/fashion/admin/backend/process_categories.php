<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();

	require 'vendor/autoload.php';
	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;

	switch ($action) {
		case 'add':
			add($params, $con, $UUID);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;

		case 'get_category':
			getCategory($params, $con);
			break;
	}

	function add($params, $con, $UUID) {
		$lclQuery1 = "SELECT * FROM categories WHERE ca_name = '".$params['txtName']."' AND ca_status = 0";
	    $lclResult1 = $con->query($lclQuery1);
	    if($lclResult1->rowCount() > 0) {
	         echo "10";
	    } else {

			$data = file_get_contents($_FILES["phPhoto"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
    		$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = $params['txtName'].".png";
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$imageURL = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}

			$lclQuery = $con->prepare("INSERT INTO categories (ca_id, ca_image, ca_name, ca_tax, ca_sequence, ca_created_by) VALUES(:ca_id, :ca_image, :ca_name, :ca_tax, :ca_sequence, :ca_created_by)");

			$lclQuery->bindParam(':ca_id', $UUID);
			$lclQuery->bindParam(':ca_image', $imageURL);
			$lclQuery->bindParam(':ca_name', $params['txtName']);
			$lclQuery->bindParam(':ca_tax', $params['txtTax']);
			$lclQuery->bindParam(':ca_sequence', $params['txtSequence']);
			$lclQuery->bindParam(':ca_created_by', $params["loggedInBy"]);

			$lclResult = $lclQuery->execute();
			echo "1";
		}
	}

	function update($params, $con) {

		if($params["imageURL1"] == "") {
			$data = file_get_contents($_FILES["phPhoto1"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
    		$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = $params['txtName1'].".png";
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$imageURL = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}
		} else {
			$imageURL = $params["imageURL1"];
		}

		$lclQuery = $con->prepare("UPDATE categories SET
							  ca_image = :ca_image,
							  ca_name = :ca_name,
							  ca_tax = :ca_tax,
							  ca_sequence = :ca_sequence
							  WHERE ca_id = :ca_id");

		$lclQuery->bindParam(':ca_image', $imageURL);
		$lclQuery->bindParam(':ca_name', $params['txtName1']);
		$lclQuery->bindParam(':ca_tax', $params['txtTax1']);
		$lclQuery->bindParam(':ca_sequence', $params['txtSequence1']);
		$lclQuery->bindParam(':ca_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	// }
	}

	function delete($params, $con) {

		$lclQuery = "DELETE FROM categories WHERE ca_id = '".$params['id']."'";
		$lclQuery = $con->query($lclQuery);
		echo "1";
	}

	function getCategory($params, $con) {
		$lclQuery = "SELECT * FROM categories WHERE ca_id ='".$params['id']."'";

		$lclResult = $con->query($lclQuery);

		if($lclResult->rowCount() > 0) {
			while($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
				$category[] = $row;
			  }
		}

		echo json_encode($category);
	}


?>
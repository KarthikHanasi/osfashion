<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();

	require 'vendor/autoload.php';
	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;

	switch ($action) {
		case 'add':
			add($params, $con, $UUID);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;
	}

	function add($params, $con, $UUID) {
		$lclQuery1 = "SELECT * FROM company_compliance WHERE cc_name = '".$params['txtName']."'";
	    $lclResult1 = $con->query($lclQuery1);
	    if($lclResult1->rowCount() > 0) {
	         echo "10";
	    } else {

			$data = file_get_contents($_FILES["phPhoto"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
    		$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = "company/".$params['txtName'].".png";
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$imageURL = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}

			$lclQuery = $con->prepare("INSERT INTO company_compliance (cc_id, cc_name, cc_image) VALUES(:cc_id, :cc_name, :cc_image)");

			$lclQuery->bindParam(':cc_id', $UUID);
			$lclQuery->bindParam(':cc_name', $params['txtName']);
			$lclQuery->bindParam(':cc_image', $imageURL);

			$lclResult = $lclQuery->execute();
			echo "1";
		}
	}

	function update($params, $con) {

		if($params["imageURL1"] == "") {
			$data = file_get_contents($_FILES["phPhoto1"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
    		$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = "company/".$params['txtName1'].".png";
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$imageURL = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}
		} else {
			$imageURL = $params["imageURL1"];
		}

		$lclQuery = $con->prepare("UPDATE company_compliance SET
							  cc_name = :cc_name,
							  cc_image = :cc_image
							  WHERE cc_id  = :cc_id");

		$lclQuery->bindParam(':cc_name', $params['txtName1']);
		$lclQuery->bindParam(':cc_image', $imageURL);
		$lclQuery->bindParam(':cc_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	// }
	}

	function delete($params, $con) {

		$lclQuery = "DELETE FROM company_compliance WHERE cc_id = '".$params['id']."'";
		$lclQuery = $con->query($lclQuery);
		echo "1";
	}


?>
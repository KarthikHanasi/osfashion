<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'add':
			addClass($params, $con);
			break;

		case 'update':
			updateClass($params, $con);
			break;

		case 'delete':
			deleteClass($params, $con);
			break;
	}

	function addClass($params, $con) {



		move_uploaded_file($_FILES["phPhoto"]["tmp_name"],"../../uploads/img/contact/logo.jpg");       
        $imageURL ="img/contact/logo.jpg";
		$lclQuery = $con->prepare("INSERT INTO contact (co_email, co_mobile, co_address, co_map, co_image, co_facebook, co_twitter, co_instagram, co_youtube) VALUES(:co_email, :co_mobile, :co_address, :co_map, :co_image, :co_facebook, :co_twitter, :co_instagram, :co_youtube)");

		$lclQuery->bindParam(':co_email', $params['txtEmail']);
		$lclQuery->bindParam(':co_mobile', $params['txtMobile']);
		$lclQuery->bindParam(':co_address', $params['txtAddress']);
		$lclQuery->bindParam(':co_map', $params['txtMap']);
		$lclQuery->bindParam(':co_image', $imageURL); 
        $lclQuery->bindParam(':co_facebook', $params['txtFacebook']);
        $lclQuery->bindParam(':co_twitter', $params['txtTwitter']);
        $lclQuery->bindParam(':co_instagram', $params['txtInstagram']);
        $lclQuery->bindParam(':co_youtube', $params['txtYoutube']);
		// $lclQuery->bindParam(':al_user_email', $_SESSION["infynow_username"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function updateClass($params, $con) {

		if($params["txtImage1"] == "") {
			move_uploaded_file($_FILES["phPhoto1"]["tmp_name"],"../../uploads/img/contact/".$params["id"]."-chairman.jpg");       
        $imageURL ="img/contact/".$params["id"]."-contact.jpg";
		} else {
			$imageURL = $params["txtImage1"];
		}


		$lclQuery = $con->prepare("UPDATE contact SET
		                      co_email = :co_email, 
							  co_mobile = :co_mobile,
							  co_address = :co_address,
							  co_map = :co_map,
							  co_image = :co_image,
							  co_facebook = :co_facebook,
							  co_twitter = :co_twitter,
							  co_instagram = :co_instagram,
							  co_youtube = :co_youtube

							  WHERE co_id = :co_id");

		$lclQuery->bindParam(':co_mobile', $params['txtMobile1']);
		$lclQuery->bindParam(':co_address', $params['txtAddress1']);
		$lclQuery->bindParam(':co_map', $params['txtMap1']);
		$lclQuery->bindParam(':co_image', $imageURL);
		$lclQuery->bindParam(':co_email', $params['txtEmail1']);
		 $lclQuery->bindParam(':co_facebook', $params['txtFacebook1']);
        $lclQuery->bindParam(':co_twitter', $params['txtTwitter1']);
        $lclQuery->bindParam(':co_instagram', $params['txtInstagram1']);
        $lclQuery->bindParam(':co_youtube', $params['txtYoutube1']);
		$lclQuery->bindParam(':co_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function deleteClass($params, $con) {

		$lclQuery = $con->prepare("UPDATE contact SET 
							  co_status = :co_status

							  WHERE co_id = :co_id");

		$lclQuery->bindParam(':co_status', $lclStatus);
		$lclQuery->bindParam(':co_id', $params["id"]);
		$lclStatus = 1;

		$lclResult = $lclQuery->execute();
		echo "1";
	}


?>


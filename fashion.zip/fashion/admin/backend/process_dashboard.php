<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'add':
			getTeacher($params, $con);
			break;

	}

	function getTeacher($params, $con) {

		$lclQuery1 = "SELECT count(*) FROM lessons WHERE al_user_email = '".$params['selTeacher']."'";
	    $lclResult1 = $con->query($lclQuery1);
	    $lclRes1 = $lclResult1->fetchColumn();

	    $lclQuery2 = "SELECT count(*) FROM video_link WHERE vl_user_email = '".$params['selTeacher']."'";
	    $lclResult2 = $con->query($lclQuery2);
	    $lclRes2 = $lclResult2->fetchColumn();

	    $lclQuery3 = "SELECT count(*) FROM lib_imp_questions WHERE lq_created_by = '".$params['selTeacher']."'";
	    $lclResult3 = $con->query($lclQuery3);
	    $lclRes3 = $lclResult3->fetchColumn();

	    $lclQuery4 = "SELECT count(*) FROM lib_imp_video WHERE lv_created_by = '".$params['selTeacher']."'";
	    $lclResult4 = $con->query($lclQuery4);
	    $lclRes4 = $lclResult4->fetchColumn();

	    $lclQuery5 = "SELECT count(*) FROM lib_notes WHERE ln_created_by = '".$params['selTeacher']."'";
	    $lclResult5 = $con->query($lclQuery5);
	    $lclRes5 = $lclResult5->fetchColumn();

	    $lclQuery6 = "SELECT count(*) FROM lib_question_paper WHERE lp_created_by = '".$params['selTeacher']."'";
	    $lclResult6 = $con->query($lclQuery6);
	    $lclRes6 = $lclResult6->fetchColumn();

	    $lclQuery7 = "SELECT count(*) FROM lib_textbooks WHERE lt_created_by = '".$params['selTeacher']."'";
	    $lclResult7 = $con->query($lclQuery7);
	    $lclRes7 = $lclResult7->fetchColumn();

	    $lclQuery8 = "SELECT count(*) FROM test_configuration WHERE tc_created_by = '".$params['selTeacher']."'";
	    $lclResult8 = $con->query($lclQuery8);
	    $lclRes8 = $lclResult8->fetchColumn();

	    echo json_encode(array("lessons" => $lclRes1, "videos" => $lclRes2, "impQuestions" => $lclRes3, "impVideos" => $lclRes4, "impNotes" => $lclRes5, "impQuestionPaper" => $lclRes6, "impTextBoks" => $lclRes7, "testConfig" => $lclRes8));


	}

?>


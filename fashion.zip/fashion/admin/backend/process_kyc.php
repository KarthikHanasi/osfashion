<?php
session_start();
// error_reporting(0);
include_once('../../conn/conn.php');
$lclCon = new DatabaseClass();
$con = $lclCon->getCon();
$con->exec("SET NAMES 'utf8'");
$params = $_REQUEST;
$action = $params['action'];

switch ($action) {

    case 'update_documents_status':
        updateData($params, $con);
        break;

    case 'get_kyc_files':
        getKYCFiles($params, $con);
        break;
}

function updateData($params, $con) {
    $lclQuery = $con->prepare("UPDATE kyc SET 
                            aadhar_status = :aadhar_status,
                            pan_status = :pan_status,
                            bank_status = :bank_status
                            WHERE id = :id");

    $lclQuery->bindParam(':aadhar_status', $params['aadharStatus']);
    $lclQuery->bindParam(':pan_status', $params['panStatus']);
    $lclQuery->bindParam(':bank_status', $params['bankStatus']);
    $lclQuery->bindParam(':id', $params['id']);
    $lclResult = $lclQuery->execute();
    echo $lclResult;
}

function getKYCFiles($params, $con) {
    $kyc_details = array();
    $lclQuery = "SELECT * FROM kyc WHERE id = '".$params['id']."'";
    $lclResult = $con->query($lclQuery);
    if ($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
        $kyc_details[] = $row;
    }
    echo json_encode(array("kyc_details" => $kyc_details));
	
}
?>
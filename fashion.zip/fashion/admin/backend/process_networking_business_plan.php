<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();

	require 'vendor/autoload.php';
	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;

	switch ($action) {
		case 'add':
			add($params, $con, $UUID);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;
	}

	function add($params, $con, $UUID) {
		$lclQuery1 = "SELECT * FROM network_business_plan WHERE nbp_file_name = '".$params['txtName']."'";
	    $lclResult1 = $con->query($lclQuery1);
	    if($lclResult1->rowCount() > 0) {
	         echo "10";
	    } else {

			$data = file_get_contents($_FILES["phPhoto"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
    		$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';

            if($params['selFileType'] == "Image") {
			    $key1 = "network/".$params['txtName'].".png";
            } else if($params['selFileType'] == "PDF") {
                $key1 = "network/".$params['txtName'].".pdf";
            } else {
                $key1 = "network/".$params['txtName'].".mp4";
            }
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$imageURL = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}

			$lclQuery = $con->prepare("INSERT INTO network_business_plan (nbp_id, nbp_file_name, nbp_file_type, nbp_file) VALUES(:nbp_id, :nbp_file_name, :nbp_file_type, :nbp_file)");

			$lclQuery->bindParam(':nbp_id', $UUID);
			$lclQuery->bindParam(':nbp_file_name', $params['txtName']);
			$lclQuery->bindParam(':nbp_file_type', $params['selFileType']);
			$lclQuery->bindParam(':nbp_file', $imageURL);

			$lclResult = $lclQuery->execute();
			echo "1";
		}
	}

	function update($params, $con) {

		if($params["imageURL1"] == "") {
			$data = file_get_contents($_FILES["phPhoto1"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
    		$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);

            $bucket = 'multimediastorage124243-dev';

            if($params['selFileType1'] == "Image") {
			    $key1 = "network/".$params['txtName1'].".png";
            } else if($params['selFileType1'] == "PDF") {
                $key1 = "network/".$params['txtName1'].".pdf";
            } else {
                $key1 = "network/".$params['txtName1'].".mp4";
            }
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$imageURL = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}
		} else {
			$imageURL = $params["imageURL1"];
		}

		$lclQuery = $con->prepare("UPDATE network_business_plan SET
							  nbp_file_name = :nbp_file_name,
							  nbp_file_type = :nbp_file_type,
							  nbp_file = :nbp_file
							  WHERE nbp_id = :nbp_id");

		$lclQuery->bindParam(':nbp_file_name', $params['txtName1']);
		$lclQuery->bindParam(':nbp_file_type', $params['selFileType1']);
		$lclQuery->bindParam(':nbp_file', $imageURL);
		$lclQuery->bindParam(':nbp_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	// }
	}

	function delete($params, $con) {

		$lclQuery = "DELETE FROM network_business_plan WHERE nbp_id = '".$params['id']."'";
		$lclQuery = $con->query($lclQuery);
		echo "1";
	}


?>
<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'update':
			update($params, $con);
			break;
	}

	function update($params, $con) {

		$lclQuery = $con->prepare("UPDATE order_return_days SET
							  ord_days = :ord_days

							  WHERE ord_id = :ord_id");
		
		$lclQuery->bindParam(':ord_days', $params['txtDays1']);
		$lclQuery->bindParam(':ord_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}


?>
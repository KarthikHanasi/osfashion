<?php
	session_start();
	error_reporting(0);
	include_once('../../conn/conn.php');
	include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();

	switch ($action) {
		case 'get_order_details':
			getOrderDetails($params, $con);
			break;

		case 'update_payment':
			updatePayment($params, $con);
			break;

		case 'update_delivery':
			updateDelivery($params, $con);
			break;

		case 'cancel_order':
			cancelOrder($params, $con, $UUID);
			break;
	}

	function getOrderDetails($params, $con) {

		$productDetails = array();

		$lclQuery1 = "SELECT * FROM orders
		LEFT JOIN purchased_products ON purchased_products.pp_od_id = orders.or_id
		LEFT JOIN products ON products.pd_id = purchased_products.pp_pd_id
		LEFT JOIN address ON address.ads_id = orders.or_address_id
		LEFT JOIN state ON state.st_id = address.ads_state
		LEFT JOIN size ON size.sz_id = purchased_products.pp_sz_id
		LEFT JOIN color ON color.co_id = products.pd_color
		WHERE or_id = '".$params['orderID']."'";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$productDetails[] = $row1;
		}
		echo json_encode($productDetails);
	}

	function updatePayment($params, $con) {
		$lclQuery = $con->prepare("UPDATE orders SET 
							  or_payment_status = :or_payment_status
							  WHERE or_id = :or_id");

		$lclQuery->bindParam(':or_payment_status', $params['selPaymentStatus']);
		$lclQuery->bindParam(':or_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function updateDelivery($params, $con) {
		$lclQuery = $con->prepare("UPDATE orders SET 
							  os_delivery_status = :os_delivery_status
							  WHERE or_id = :or_id");

		$lclQuery->bindParam(':os_delivery_status', $params['selDeliveryStatus']);
		$lclQuery->bindParam(':or_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function cancelOrder($params, $con, $UUID) {

		$orderUser = "SELECT * FROM orders WHERE or_id = '".$params['orderID']."' AND os_delivery_status != 'CANCELLED'";
		$orderUserResult = $con->query($orderUser);

		if($orderUserRow = $orderUserResult->fetch(PDO::FETCH_ASSOC)) {

			$updateBVUser = "SELECT * FROM purchased_products 
			LEFT JOIN products ON products.pd_id = purchased_products.pp_pd_id
			WHERE pp_od_id = '".$params['orderID']."'";
			$updateBVUserResult = $con->query($updateBVUser);

			while($updateBVUserRow = $updateBVUserResult->fetch(PDO::FETCH_ASSOC)) {
				$lclUpdate = "UPDATE users SET 
				us_bv = us_bv - ".$updateBVUserRow['pd_bv']."
				WHERE us_id = '".$orderUserRow['or_us_id']."'";
				$con->query($lclUpdate);
				$deliveryID = $updateBVUserRow['pp_awb_number'];
			}

			$cancelReason = $con->prepare("INSERT INTO cancel_reason (cr_id, cr_od_id, cr_us_id, cr_reason) VALUES(:cr_id, :cr_od_id, :cr_us_id, :cr_reason)");

			$cancelReason->bindParam(':cr_id', $UUID);
			$cancelReason->bindParam(':cr_od_id', $params['orderID']);
			$cancelReason->bindParam(':cr_us_id', $orderUserRow['or_us_id']);
			$cancelReason->bindParam(':cr_reason', $params['txtReason']);
			$cancelReason->execute();

			// update order status to CANCELLED
			$lclOrder = "UPDATE orders SET os_delivery_status = 'CANCELLED'
				WHERE or_id = '".$params['orderID']."'";
			$con->query($lclOrder);

			$lclRegDate = new DateTime(date('Y-m-d', strtotime($orderUserRow['or_created_date'])));
			$lclOrderDate = new DateTime(date('Y-m-d'));
			$abs_diff = $lclOrderDate->diff($lclRegDate)->format("%a");

			$orderCancelDays = "SELECT * FROM order_cancel_days";
			$orderCancelDaysResult = $con->query($orderCancelDays);

			if($orderCancelDaysRow = $orderCancelDaysResult->fetch(PDO::FETCH_ASSOC)) {
				$cancelDays = $orderCancelDaysRow['ocd_days'];
			}

			if($abs_diff < $cancelDays) {
				$recursiveQuery = "WITH RECURSIVE company_hierarchy AS (
					SELECT   us_id,
							  us_name,
							  us_mobile,
							  us_referred_user_id,
						   1 AS hierarchy_level
					FROM users
					WHERE us_id = '".$orderUserRow['or_us_id']."'
					UNION ALL
					SELECT    u.us_id,
							  u.us_name,
							  u.us_mobile,
							  u.us_referred_user_id,
						  hierarchy_level + 1
					FROM users u, company_hierarchy ch
					WHERE u.us_id = ch.us_referred_user_id
				  )
				   
				  SELECT ch.us_name AS employee_name,
						 ch.us_mobile AS employee_mobile,
						 u.us_id AS main_id,
						 u.us_name AS main_name,
						 u.us_mobile AS main_mobile,
						 hierarchy_level
				  FROM company_hierarchy ch
				  LEFT JOIN users u
				  ON ch.us_referred_user_id = u.us_id
				  ORDER BY ch.hierarchy_level DESC";
		
				$recursiveResult = $con->query($recursiveQuery);
		
				while($recursiveRow = $recursiveResult->fetch(PDO::FETCH_ASSOC)) {
					if($recursiveRow['main_id'] != "") {
						// demote user once cancellation start pending for review start
						$lclCheckLevelComplete = "SELECT count(*) FROM level_information WHERE li_main_user_id = '".$recursiveRow['main_id']."' AND li_level_count = '".$recursiveRow['hierarchy_level']."' AND li_status = 'CREATED'";
						$lclCheckLevelCompleteRes = $con->query($lclCheckLevelComplete);
						$lclCheckLevelCompleteCount = $lclCheckLevelCompleteRes->fetchColumn();

						$lvlCount = "SELECT * FROM levels_count WHERE lvl_level = ".$recursiveRow['hierarchy_level']."";
						$lvlCountRes = $con->query($lvlCount);

						if($lvlRow = $lvlCountRes->fetch(PDO::FETCH_ASSOC)) {
							if($lclCheckLevelCompleteCount == $lvlRow['lvl_level_count']) {
								$lclUpdate = "UPDATE users SET us_level = us_level - 1
								WHERE us_id = '".$recursiveRow['main_id']."'";
								$con->query($lclUpdate);
							}
						}

						// demote user once cancellation start pending for review end
		
						$lclMainUserAmtDeductNoWithin = "SELECT * FROM amount_credit_history WHERE ach_or_id = '".$params['orderID']."' AND ach_main_id = '".$recursiveRow['main_id']."' AND ach_level = '".$recursiveRow['hierarchy_level']."'";
						$lclMainUserAmtDeductNoWithinRes = $con->query($lclMainUserAmtDeductNoWithin);

						while($lclMainUserAmtDeductNoWithinRow = $lclMainUserAmtDeductNoWithinRes->fetch(PDO::FETCH_ASSOC)) {
		
							$lclDebitAmount = "UPDATE users SET us_wallet = us_wallet - ".$lclMainUserAmtDeductNoWithinRow['ach_amount']."
							WHERE us_id = '".$recursiveRow['main_id']."'";
							$con->query($lclDebitAmount);

							$lclUpdate = "UPDATE amount_credit_history SET ach_type = 'CANCELLED'
								WHERE ach_id = '".$lclMainUserAmtDeductNoWithinRow['ach_id']."'";
							$con->query($lclUpdate);
		
							// $lclUpdate = "UPDATE level_information SET li_status = 'CANCELLED'
							// 	WHERE li_main_user_id = '".$recursiveRow['main_id']."'";
							// $con->query($lclUpdate);
						}
		
					}
				}
				echo "1";
			} else {
				echo "10";
			}
		} else {
			echo "20";
		}
	}


?>


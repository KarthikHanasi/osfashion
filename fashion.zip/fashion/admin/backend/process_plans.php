<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();

	switch ($action) {
		case 'add':
			add($params, $con, $UUID);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;

		case 'get_category':
			getCategory($params, $con);
			break;
	}

	function add($params, $con, $UUID) {
		$lclQuery1 = "SELECT * FROM plans WHERE pl_name = '".$params['txtName']."'";
	    $lclResult1 = $con->query($lclQuery1);
	    if($lclResult1->rowCount() > 0) {
	         echo "10";
	    } else {

			$lclQuery = $con->prepare("INSERT INTO plans (pl_id, pl_name, pl_amount, pl_percentage) VALUES(:pl_id, :pl_name, :pl_amount, :pl_percentage)");

			$lclQuery->bindParam(':pl_id', $UUID);
			$lclQuery->bindParam(':pl_name', $params['txtName']);
			$lclQuery->bindParam(':pl_amount', $params['txtAmount']);
			$lclQuery->bindParam(':pl_percentage', $params['txtPercentage']);

			$lclResult = $lclQuery->execute();
			echo "1";
		}
	}

	function update($params, $con) {

		$lclQuery = $con->prepare("UPDATE plans SET
							  pl_name = :pl_name,
							  pl_amount = :pl_amount,
							  pl_percentage = :pl_percentage
							  WHERE pl_id = :pl_id");

		$lclQuery->bindParam(':pl_name', $params['txtName1']);
		$lclQuery->bindParam(':pl_amount', $params['txtAmount1']);
		$lclQuery->bindParam(':pl_percentage', $params['txtPercentage1']);
		$lclQuery->bindParam(':pl_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function delete($params, $con) {

		$lclQuery = "DELETE FROM plans WHERE pl_id = '".$params['id']."'";
		$lclQuery = $con->query($lclQuery);
		echo "1";
	}

?>
<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	 $params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();
	require 'vendor/autoload.php';
	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;
	switch ($action) {
		case 'add':
			add($params, $con, $UUID);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;
		
		case 'enable':
			enable($params, $con);
			break;

		case 'disable':
			disable($params, $con);
			break;

		case 'getSubCategory':
			getSubCategory($params, $con);
			break;

		case 'getColorSize':
			getColorSize($params, $con);
			break;

		case 'get_size_sub_category':
			getSizeSubcategory($params, $con);
			break;
	}

	function add($params, $con, $UUID) {

		$lclQuery1 = "SELECT * FROM products WHERE pd_product_id = '".$params['txtProductID']."'";
	    $lclResult1 = $con->query($lclQuery1); 
	    if($lclResult1->rowCount() > 0) {
	         echo "10";
	    } else {

			$lclQuery = "SELECT count(*) AS total FROM products";
			$lclResult = $con->query($lclQuery); 

			if($lclResult->rowCount() > 0) {
				if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {

					$lclID1 = $row['total'];
					$lclID = $lclID1 + 1;

				}
			} else {
				$lclID = 1;
			}

			$data = file_get_contents($_FILES["phPhoto"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
    		$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = $UUID."main.png";
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$imageURL = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}

			if($params['txtSubImageText1'] == "") {

				$data = file_get_contents($_FILES["subImage1"]["tmp_name"]);
				$base64 = 'data:image/png;base64,' . base64_encode($data);
				$base64_str = substr($base64, strpos($base64, ",") + 1);
				$image = base64_decode($base64_str);

				$s3Client = new S3Client([
					'version' => '2006-03-01',
					'region'  => "us-east-1",
					'credentials' => [
						'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
						'secret' => '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'
					]
				]);
		
				$bucket = 'multimediastorage124243-dev';
				$key1 = $UUID."1.png";
		
				try {
					$result1 = $s3Client->putObject([
						'Bucket' => $bucket,
						'Key'    => $key1,
						'Body'   => $image,
						'ACL'    => 'public-read', // make file 'public'
					]);
					// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
					$lclSubImage1 = $result1->get('ObjectURL');
				} catch (Aws\S3\Exception\S3Exception $e) {
					echo "There was an error uploading the file.\n";
					echo $e->getMessage();
				}
			} else {
				$lclSubImage1 = "";
			}

			if($params['txtSubImageText2'] == "") {
				$data = file_get_contents($_FILES["subImage2"]["tmp_name"]);
				$base64 = 'data:image/png;base64,' . base64_encode($data);
				$base64_str = substr($base64, strpos($base64, ",") + 1);
				$image = base64_decode($base64_str);

				$s3Client = new S3Client([
					'version' => '2006-03-01',
					'region'  => "us-east-1",
					'credentials' => [
						'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
						'secret' => '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'
					]
				]);
		
				$bucket = 'multimediastorage124243-dev';
				$key1 = $UUID."2.png";
		
				try {
					$result1 = $s3Client->putObject([
						'Bucket' => $bucket,
						'Key'    => $key1,
						'Body'   => $image,
						'ACL'    => 'public-read', // make file 'public'
					]);
					// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
					$lclSubImage2 = $result1->get('ObjectURL');
				} catch (Aws\S3\Exception\S3Exception $e) {
					echo "There was an error uploading the file.\n";
					echo $e->getMessage();
				}
			} else {
				$lclSubImage2 = "";
			}

			if($params['txtSubImageText3'] == "") {
				$data = file_get_contents($_FILES["subImage3"]["tmp_name"]);
				$base64 = 'data:image/png;base64,' . base64_encode($data);
				$base64_str = substr($base64, strpos($base64, ",") + 1);
				$image = base64_decode($base64_str);

				$s3Client = new S3Client([
					'version' => '2006-03-01',
					'region'  => "us-east-1",
					'credentials' => [
						'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
						'secret' => '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'
					]
				]);
		
				$bucket = 'multimediastorage124243-dev';
				$key1 = $UUID."3.png";
		
				try {
					$result1 = $s3Client->putObject([
						'Bucket' => $bucket,
						'Key'    => $key1,
						'Body'   => $image,
						'ACL'    => 'public-read', // make file 'public'
					]);
					// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
					$lclSubImage3 = $result1->get('ObjectURL');
				} catch (Aws\S3\Exception\S3Exception $e) {
					echo "There was an error uploading the file.\n";
					echo $e->getMessage();
				}
			} else {
				$lclSubImage3 = "";
			}

			if($params['txtSubImageText4'] == "") {
				$data = file_get_contents($_FILES["subImage4"]["tmp_name"]);
				$base64 = 'data:image/png;base64,' . base64_encode($data);
				$base64_str = substr($base64, strpos($base64, ",") + 1);
				$image = base64_decode($base64_str);

				$s3Client = new S3Client([
					'version' => '2006-03-01',
					'region'  => "us-east-1",
					'credentials' => [
						'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
						'secret' => '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'
					]
				]);
		
				$bucket = 'multimediastorage124243-dev';
				$key1 = $UUID."4.png";
		
				try {
					$result1 = $s3Client->putObject([
						'Bucket' => $bucket,
						'Key'    => $key1,
						'Body'   => $image,
						'ACL'    => 'public-read', // make file 'public'
					]);
					// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
					$lclSubImage4 = $result1->get('ObjectURL');
				} catch (Aws\S3\Exception\S3Exception $e) {
					echo "There was an error uploading the file.\n";
					echo $e->getMessage();
				}
			} else {
				$lclSubImage4 = "";
			}

			$lclSize = explode(',', $params['size']);
			$lclSizeStock = explode(',', $params['sizeStock']);

			for($i = 0; $i < count($lclSize); $i++) {
				if($lclSize[$i] != "") {
					$productUUID = guidv4();
					$productSize = $con->prepare("INSERT INTO product_size (ps_id, ps_pd_id, ps_sz_id, ps_stock) VALUES(:ps_id, :ps_pd_id, :ps_sz_id, :ps_stock)");

					$productSize->bindParam(':ps_id', $productUUID);
					$productSize->bindParam(':ps_pd_id', $UUID);
					$productSize->bindParam(':ps_sz_id', $lclSize[$i]);
					$productSize->bindParam(':ps_stock', $lclSizeStock[$i]);
					$productSize->execute();
				}
			}

			$lclQuery = $con->prepare("INSERT INTO products (pd_id, pd_name, pd_product_id, pd_price, pd_quantity, pd_color, pd_size, pd_short_desc, pd_long_desc, pd_image, pd_sub_image1, pd_sub_image2, pd_sub_image3, pd_sub_image4, pd_category_name,pd_sub_category_name, pd_stock, pd_discount, pd_discount_price, pd_bv, pd_pv, pd_created_by) VALUES(:pd_id, :pd_name, :pd_product_id, :pd_price, :pd_quantity, :pd_color, :pd_size, :pd_short_desc, :pd_long_desc, :pd_image, :pd_sub_image1, :pd_sub_image2, :pd_sub_image3, :pd_sub_image4, :pd_category_name, :pd_sub_category_name, :pd_stock, :pd_discount, :pd_discount_price, :pd_bv, :pd_pv, :pd_created_by)");

			$lclQuery->bindParam(':pd_id', $UUID);
			$lclQuery->bindParam(':pd_name', $params['txtName']);
			$lclQuery->bindParam(':pd_product_id', $params['txtProductID']);
			$lclQuery->bindParam(':pd_price', $params['txtPrice']);
			$lclQuery->bindParam(':pd_quantity', $params['txtQuantity']);
			$lclQuery->bindParam(':pd_color', $params['color']);
			$lclQuery->bindParam(':pd_size', $params['size']);
			$lclQuery->bindParam(':pd_short_desc', $params['txtShortDescription']);
			$lclQuery->bindParam(':pd_long_desc', $params['txtLongDescription']);
			$lclQuery->bindParam(':pd_category_name', $params['selCategory']);
			$lclQuery->bindParam(':pd_sub_category_name', $params['selSubCategory']);
			$lclQuery->bindParam(':pd_stock', $params['txtStock']);
			$lclQuery->bindParam(':pd_discount', $params['txtDiscount']);
			$lclQuery->bindParam(':pd_discount_price', $params['txtDiscountPrice']);
			$lclQuery->bindParam(':pd_bv', $params['txtBV']);
			$lclQuery->bindParam(':pd_pv', $params['txtPV']);
			$lclQuery->bindParam(':pd_image', $imageURL);
			$lclQuery->bindParam(':pd_sub_image1', $lclSubImage1);
			$lclQuery->bindParam(':pd_sub_image2', $lclSubImage2);
			$lclQuery->bindParam(':pd_sub_image3', $lclSubImage3);
			$lclQuery->bindParam(':pd_sub_image4', $lclSubImage4);
			$lclQuery->bindParam(':pd_created_by', $params["loggedInBy"]);
			$lclResult = $lclQuery->execute();
			echo "1";

		}
	
	}

	function s3Storage() {

	}


	function update($params, $con) {

		if($params["imageURL1"] == "") {

			$data = file_get_contents($_FILES["phPhoto1"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
    		$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = $params["id"]."main.png";
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$imageURL = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}
		} else {
			$imageURL = $params["imageURL1"];
		}
		

		if($params['txtSubImageText11'] == "") {

			$data = file_get_contents($_FILES["subImage11"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
			$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = $params["id"]."1.png";
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$lclSubImage1 = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}
		} else {

			if (substr($params['txtSubImageText11'],0, 7) == "uploads" || substr($params['txtSubImageText11'],0, 5) == "https") {
				$lclSubImage1 = $params['txtSubImageText11'];
			} else {
				$lclSubImage1 = "";
			}
			
		}

		if($params['txtSubImageText22'] == "") {
			$data = file_get_contents($_FILES["subImage22"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
			$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = $params["id"]."2.png";
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$lclSubImage2 = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}
		} else {
			if (substr($params['txtSubImageText22'],0, 7) == "uploads" || substr($params['txtSubImageText22'],0, 5) == "https") {
				$lclSubImage2 = $params['txtSubImageText22'];
			} else {
				$lclSubImage2 = "";
			}
		}

		if($params['txtSubImageText33'] == "") {
			$data = file_get_contents($_FILES["subImage33"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
			$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = $params["id"]."3.png";
	
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$lclSubImage3 = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}
		} else {
			if (substr($params['txtSubImageText33'],0, 7) == "uploads" || substr($params['txtSubImageText33'],0, 5) == "https") {
				$lclSubImage3 = $params['txtSubImageText33'];
			} else {
				$lclSubImage3 = "";
			}
		}

		if($params['txtSubImageText44'] == "") {
			$data = file_get_contents($_FILES["subImage44"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
			$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region'  => "us-east-1",
				'credentials' => [
					'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);
	
			$bucket = 'multimediastorage124243-dev';
			$key1 = $params["id"]."4.png";
			
			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key'    => $key1,
					'Body'   => $image,
					'ACL'    => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$lclSubImage4 = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}
		} else {
			if (substr($params['txtSubImageText44'],0, 7) == "uploads" || substr($params['txtSubImageText44'],0, 5) == "https") {
				$lclSubImage4 = $params['txtSubImageText44'];
			} else {
				$lclSubImage4 = "";
			}
		}

		$lclSize = explode(',', $params['size']);
		$lclSizeStock = explode(',', $params['sizeStock']);
			for($i = 0; $i < count($lclSize); $i++) {

				if($lclSize[$i] != "") {
					$lclQuerySize = "SELECT * FROM product_size WHERE ps_sz_id = '".$lclSize[$i]."' AND ps_pd_id = '".$params['id']."'";
					$lclResultSize = $con->query($lclQuerySize); 
					if($lclResultSize->rowCount() > 0) {
						$lclUpdate = "UPDATE product_size SET ps_stock = ".$lclSizeStock[$i]."
						WHERE ps_sz_id = '".$lclSize[$i]."' AND ps_pd_id = '".$params['id']."'";
						$lclRes = $con->query($lclUpdate);
					} else {
						$productUUID = guidv4();
						$productSize = $con->prepare("INSERT INTO product_size (ps_id, ps_pd_id, ps_sz_id, ps_stock) VALUES(:ps_id, :ps_pd_id, :ps_sz_id, :ps_stock)");
		
						$productSize->bindParam(':ps_id', $productUUID);
						$productSize->bindParam(':ps_pd_id', $params['id']);
						$productSize->bindParam(':ps_sz_id', $lclSize[$i]);
						$productSize->bindParam(':ps_stock', $lclSizeStock[$i]);
						$productSize->execute();
					}
				}
			}
		

		$lclQuery = $con->prepare("UPDATE products SET 
							  pd_name = :pd_name,
							  pd_product_id = :pd_product_id,
							  pd_color = :pd_color,
							  pd_size = :pd_size,
							  pd_price = :pd_price,
							  pd_quantity = :pd_quantity,
							  pd_short_desc = :pd_short_desc,
							  pd_long_desc = :pd_long_desc,
							  pd_category_name = :pd_category_name,
							  pd_sub_category_name = :pd_sub_category_name,
							  pd_image = :pd_image,
							  pd_sub_image1 = :pd_sub_image1,
							  pd_sub_image2 = :pd_sub_image2,
							  pd_sub_image3 = :pd_sub_image3,
							  pd_sub_image4 = :pd_sub_image4,
							  pd_stock = :pd_stock,
							  pd_discount = :pd_discount,
							  pd_discount_price = :pd_discount_price,
							  pd_bv = :pd_bv,
							  pd_pv = :pd_pv
							  WHERE pd_id = :pd_id");

		$lclQuery->bindParam(':pd_name', $params['txtName1']);
		$lclQuery->bindParam(':pd_product_id', $params['txtProductID1']);
		$lclQuery->bindParam(':pd_color', $params['color']);
		$lclQuery->bindParam(':pd_size', $params['size']);
		$lclQuery->bindParam(':pd_price', $params['txtPrice1']);
		$lclQuery->bindParam(':pd_quantity', $params['txtQuantity1']);
		$lclQuery->bindParam(':pd_short_desc', $params['txtShortDescription1']);
		$lclQuery->bindParam(':pd_long_desc', $params['txtLongDescription1']);
		$lclQuery->bindParam(':pd_category_name', $params['selCategory1']);	
		$lclQuery->bindParam(':pd_sub_category_name', $params['selSubCategory1']);	
		$lclQuery->bindParam(':pd_image', $imageURL);
		$lclQuery->bindParam(':pd_sub_image1', $lclSubImage1);
		$lclQuery->bindParam(':pd_sub_image2', $lclSubImage2);
		$lclQuery->bindParam(':pd_sub_image3', $lclSubImage3);
		$lclQuery->bindParam(':pd_sub_image4', $lclSubImage4);
		$lclQuery->bindParam(':pd_stock', $params['txtStock1']);
		$lclQuery->bindParam(':pd_discount', $params['txtDiscount1']);
		$lclQuery->bindParam(':pd_discount_price', $params['txtDiscountPrice1']);
		$lclQuery->bindParam(':pd_bv', $params['txtBV1']);
		$lclQuery->bindParam(':pd_pv', $params['txtPV1']);
		$lclQuery->bindParam(':pd_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function delete($params, $con) {

		$lclQuery = $con->prepare("UPDATE products SET 
							  pd_status = :pd_status
							  
							  WHERE pd_id = :pd_id");

		$lclQuery->bindParam(':pd_status', $lclStatus);
		$lclQuery->bindParam(':pd_id', $params["id"]);
		$lclStatus = 1;
		$lclResult = $lclQuery->execute();

		echo "1";
	}

	function enable($params, $con) {
		$lclStatus = 0;
		$lclQuery = $con->prepare("UPDATE products SET 
							  pd_status = :pd_status
							  
							  WHERE pd_id = :pd_id");

		$lclQuery->bindParam(':pd_status', $lclStatus);
		$lclQuery->bindParam(':pd_id', $params["id"]);
		$lclResult = $lclQuery->execute();

		echo "1";
	}

	function disable($params, $con) {
		$lclStatus = 1;
		$lclQuery = $con->prepare("UPDATE products SET 
							  pd_status = :pd_status
							  
							  WHERE pd_id = :pd_id");

		$lclQuery->bindParam(':pd_status', $lclStatus);
		$lclQuery->bindParam(':pd_id', $params["id"]);
		$lclResult = $lclQuery->execute();

		echo "1";
	}



	function getSubCategory($params, $con) {

		$lclQuery = "SELECT sub_id, sub_category_name FROM sub_category WHERE sub_ca_id ='".$params['selCategory']."'";

		$lclResult = $con->query($lclQuery);

		if($lclResult->rowCount() > 0) {
			while($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
				$category[] = $row;
			  }
		}

		echo json_encode($category);

	}

	function getColorSize($params, $con) {
		$color = array();
		$lclQuery1 = "SELECT co_id, co_name FROM color";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$color[] = $row1;
		}

		$size = array();
		$lclQuery2 = "SELECT * FROM sub_category
		WHERE sub_category_name = '".$params['sub_category']."'";
		$lclResult2 = $con->query($lclQuery2);
			
		if($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$lclSizeID = explode(",", $row2['sub_size_id']);
			for($i = 0; $i < count($lclSizeID); $i++) {
				$lclQuery4 = "SELECT * FROM size
				WHERE sz_id = '".$lclSizeID[$i]."'";
				$lclResult4 = $con->query($lclQuery4);

				while($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
					$size[] = $row4;
				}
			}

		}

		$productSize = array();
		$lclQuery6 = "SELECT * FROM product_size
		LEFT JOIN size ON size.sz_id = product_size.ps_sz_id 
		WHERE ps_pd_id = '".$params['id']."'";
		$lclResult6 = $con->query($lclQuery6);
			
		while($row6 = $lclResult6->fetch(PDO::FETCH_ASSOC)) {
			$productSize[] = $row6;
		}

		$product = array();
		$lclQuery3 = "SELECT pd_short_desc, pd_long_desc, pd_image, pd_sub_image1, pd_sub_image2, pd_sub_image3, pd_sub_image4, pd_color, pd_size, pd_product_id, pd_discount_price FROM products WHERE pd_id = '".$params['id']."'";
		$lclResult3 = $con->query($lclQuery3);
			
		while($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$product[] = $row3;
		}

		echo json_encode(array("color" => $color, "size" => $size, "product" => $product, "productSize" => $productSize));
	}

	function getSizeSubcategory($params, $con) {
		$size = array();
		$lclQuery2 = "SELECT * FROM sub_category
		WHERE sub_id = '".$params['selSubCategory']."'";
		$lclResult2 = $con->query($lclQuery2);
			
		if($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$lclSizeID = explode(",",$row2['sub_size_id']);
			for($i = 0; $i < count($lclSizeID); $i++) {
				$lclQuery3 = "SELECT * FROM size
				WHERE sz_id = '".$lclSizeID[$i]."'";
				$lclResult3 = $con->query($lclQuery3);

				while($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
					$size[] = $row3;
				}
			}

		}

		echo json_encode(array("size" => $size));
	}
?>
<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	 $params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'add':
			addProduct($params, $con);
			break;

		case 'update':
			updateSubject($params, $con);
			break;

		case 'delete':
			deleteSubject($params, $con);
			break;
	}

	function addProduct($params, $con) {



	   $lclQuery = "SELECT * FROM products WHERE pd_name = '".$params['txtName']."' AND pd_status = 0";
	    $lclResult = $con->query($lclQuery); 

	  if($lclResult->rowCount() > 0) {
	          if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {

	              $lclID1 = $row['pd_id'];
	              $lclID = $lclID1 + 1;

	            }
	    } else {
	    	$lclID = 1;
	    }
		move_uploaded_file($_FILES["phPhoto"]["tmp_name"],"../../uploads/img/products/".$lclID."-product.jpg");       
        $imageURL ="uploads/img/products/".$lclID."-product.jpg";

        $lclQuery = $con->prepare("INSERT INTO products (pd_name, pd_price, pd_quantity, pd_short_desc, pd_long_desc, pd_image, pd_category_name, pd_stock, pd_discount, pd_created_by) VALUES(:pd_name, :pd_price, :pd_quantity, :pd_short_desc, :pd_long_desc, :pd_image, :pd_category_name, :pd_stock, :pd_discount, :pd_created_by)");

		$lclQuery->bindParam(':pd_name', $params['txtName']);
		$lclQuery->bindParam(':pd_price', $params['txtPrice']);
		$lclQuery->bindParam(':pd_quantity', $params['txtQuantity']);
		$lclQuery->bindParam(':pd_short_desc', $params['txtShortDescription']);
		$lclQuery->bindParam(':pd_long_desc', $params['txtLongDescription']);
		$lclQuery->bindParam(':pd_category_name', $params['selCategory']);
		$lclQuery->bindParam(':pd_stock', $params['txtStock']);
		$lclQuery->bindParam(':pd_discount', $params['txtDiscount']);		
		$lclQuery->bindParam(':pd_image', $imageURL); 
		$lclQuery->bindParam(':pd_created_by', $_SESSION["user_email"]);
		// $lclQuery->bindParam(':bl_user_email', $_SESSION["infynow_username"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	
}


	function updateSubject($params, $con) {

		if($params["txtImage1"] == "") {
			move_uploaded_file($_FILES["phPhoto1"]["tmp_name"],"../../uploads/img/products/".$params["id"]."-product.jpg");       
        	$imageURL ="uploads/img/products/".$params["id"]."-product.jpg";
		} else {
			$imageURL = $params["txtImage1"];
		}

		$lclQuery = $con->prepare("UPDATE products SET 
							  pd_name = :pd_name,
							  pd_price = :pd_price,
							  pd_quantity = :pd_quantity,
							  pd_short_desc = :pd_short_desc,
							  pd_long_desc = :pd_long_desc,
							  pd_category_name = :pd_category_name,
							  pd_image = :pd_image,
							  pd_stock = :pd_stock,
							  pd_discount = :pd_discount
							  WHERE pd_id = :pd_id");

		$lclQuery->bindParam(':pd_name', $params['txtName1']);
		$lclQuery->bindParam(':pd_price', $params['txtPrice1']);
		$lclQuery->bindParam(':pd_quantity', $params['txtQuantity1']);
		$lclQuery->bindParam(':pd_short_desc', $params['txtShortDescription1']);
		$lclQuery->bindParam(':pd_long_desc', $params['txtLongDescription1']);
		$lclQuery->bindParam(':pd_category_name', $params['selCategory1']);	
		$lclQuery->bindParam(':pd_image', $imageURL);
		$lclQuery->bindParam(':pd_stock', $params['txtStock1']);
		$lclQuery->bindParam(':pd_discount', $params['txtDiscount1']);
		$lclQuery->bindParam(':pd_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}

	function deleteSubject($params, $con) {

	$lclQuery = "DELETE FROM products WHERE pd_id = ".$params['id'];

		$lclQuery = $con->query($lclQuery);
		echo "1";
	}


?>
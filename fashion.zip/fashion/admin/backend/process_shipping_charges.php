<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];

	switch ($action) {
		case 'add':
			add($params, $con);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;
	}

	function update($params, $con) {

		$lclQuery = $con->prepare("UPDATE shipping_charges SET
							  sc_amount = :sc_amount,
							  sc_below_amount = :sc_below_amount

							  WHERE sc_id = :sc_id");
		
		$lclQuery->bindParam(':sc_amount', $params['txtAmount1']);
		$lclQuery->bindParam(':sc_below_amount', $params['txtAboveAmount1']);
		$lclQuery->bindParam(':sc_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
	}


?>
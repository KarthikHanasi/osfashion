<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
    $UUID = guidv4();
	switch ($action) {
		case 'add':
			add($params, $con, $UUID);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;
	}

	function add($params, $con, $UUID) {
		$lclQuery1 = "SELECT * FROM size WHERE sz_name = '".$params['txtName']."' AND sz_status = 0";
	    $lclResult1 = $con->query($lclQuery1); 

	    if($lclResult1->rowCount() > 0) {
	         echo "10";
	    } else {
            $lclQuery = $con->prepare("INSERT INTO size (sz_id, sz_name, sz_sequence,  sz_created_by) VALUES(:sz_id, :sz_name, :sz_sequence, :sz_created_by)");

            $lclQuery->bindParam(':sz_id', $UUID);
            $lclQuery->bindParam(':sz_name', $params['txtName']);
            $lclQuery->bindParam(':sz_sequence', $params['txtSequence']);
            $lclQuery->bindParam(':sz_created_by', $params["loggedInBy"]);

            $lclResult = $lclQuery->execute();
            echo "1";
	    }
    }

	function update($params, $con) {

		$lclQuery = $con->prepare("UPDATE size SET 
							sz_name = :sz_name,
							sz_sequence = :sz_sequence
							WHERE sz_id = :sz_id");

		$lclQuery->bindParam(':sz_name', $params['txtName1']);
		$lclQuery->bindParam(':sz_sequence', $params['txtSequence1']);
		$lclQuery->bindParam(':sz_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";
    }

	function delete($params, $con) {
		$lclQuery = "DELETE FROM size WHERE sz_id = '".$params['id']."'";
		$lclQuery = $con->query($lclQuery);
		echo "1";
	}


?>


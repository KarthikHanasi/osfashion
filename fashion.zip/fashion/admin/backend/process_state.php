<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
    $UUID = guidv4();
	switch ($action) {
		case 'add':
			add($params, $con, $UUID);
			break;

		case 'update':
			update($params, $con);
			break;

		case 'delete':
			delete($params, $con);
			break;
	}

	function add($params, $con, $UUID) {
		$lclQuery1 = "SELECT * FROM state WHERE st_name = '".$params['txtName']."'";
	    $lclResult1 = $con->query($lclQuery1); 

	    if($lclResult1->rowCount() > 0) {
	         echo "10";
	    } else {
            $lclQuery = $con->prepare("INSERT INTO state (st_id, st_name, st_code) VALUES(:st_id, :st_name, :st_code)");

            $lclQuery->bindParam(':st_id', $UUID);
            $lclQuery->bindParam(':st_name', $params['txtName']);
            $lclQuery->bindParam(':st_code', $params['txtStateCode']);

            $lclResult = $lclQuery->execute();
            echo "1";
	    }
    }

	function update($params, $con) {

		$lclQuery = $con->prepare("UPDATE state SET 
							st_name = :st_name,
							st_code = :st_code
							WHERE st_id = :st_id");

		$lclQuery->bindParam(':st_name', $params['txtName1']);
		$lclQuery->bindParam(':st_code', $params['txtStateCode1']);
		$lclQuery->bindParam(':st_id', $params["id"]);
		$lclResult = $lclQuery->execute();
		echo "1";

    }

	function delete($params, $con) {
		$lclQuery = "DELETE FROM state WHERE st_id = '".$params['id']."'";
		$lclQuery = $con->query($lclQuery);
		echo "1";
	}


?>


<?php
	session_start();
	// error_reporting(0);
	include_once('../../conn/conn.php');
	include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();
	switch ($action) {
		case 'add':
			addSubCategory($params, $con, $UUID);
			break;

		case 'update':
			updateSubCategory($params, $con);
			break;

		case 'delete':
			deleteSubCategory($params, $con);
			break;

		case 'getSize':
			getSize($params, $con);
		
	}

	function addSubCategory($params, $con, $UUID) {
		$lclQuery1 = "SELECT * FROM sub_category WHERE sub_ca_id = '".$params['txtCategoryName']."' AND sub_category_name = '".$params['txtSubCategoryName']."' AND status = 0";
	    $lclResult1 = $con->query($lclQuery1); 

	    if($lclResult1->rowCount() > 0) {
	         echo "10";
	    } else {
			$lclQuery = $con->prepare("INSERT INTO sub_category (sub_id, sub_ca_id, sub_category_name, sub_size_id, created_by) VALUES(:sub_id, :sub_ca_id, :sub_category_name, :sub_size_id, :created_by)");

			$lclQuery->bindParam(':sub_id', $UUID);
			$lclQuery->bindParam(':sub_ca_id', $params['txtCategoryName']);
			$lclQuery->bindParam(':sub_category_name', $params['txtSubCategoryName']);
			$lclQuery->bindParam(':sub_size_id', $params['size']);
			$lclQuery->bindParam(':created_by', $params["loggedInBy"]);

			$lclResult = $lclQuery->execute();
			echo "1";
		}
	}

	function updateSubCategory($params, $con) {
		// $lclQuery1 = "SELECT * FROM sub_category WHERE sub_category_name = '".$params['txtSubCategoryName1']."'";
	    // $lclResult1 = $con->query($lclQuery1);

	    // if($lclResult1->rowCount() > 0) {
	    //      echo "10";
	    // } else {

			$lclQuery = $con->prepare("UPDATE sub_category SET 
								sub_ca_id = :sub_ca_id,
								sub_category_name = :sub_category_name,
								sub_size_id = :sub_size_id
								WHERE sub_id = :sub_id");

			$lclQuery->bindParam(':sub_ca_id', $params['txtCategoryName1']);
			$lclQuery->bindParam(':sub_category_name', $params['txtSubCategoryName1']);
			$lclQuery->bindParam(':sub_size_id', $params['size1']);
			$lclQuery->bindParam(':sub_id', $params["id"]);
			$lclResult = $lclQuery->execute();
			echo "1";
		// }
	}

	function deleteSubCategory($params, $con) {

		$lclQuery = "DELETE FROM sub_category WHERE sub_id = '".$params['id']."'";

		$lclQuery = $con->query($lclQuery);
		echo "1";
	}

	function getSize($params, $con) {

		$size = array();
		$lclQuery2 = "SELECT sz_id, sz_name FROM size";
		$lclResult2 = $con->query($lclQuery2);
			
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$size[] = $row2;
		}

		$sub_category = array();
		$lclQuery3 = "SELECT * FROM sub_category WHERE sub_id = '".$params['id']."'";
		$lclResult3 = $con->query($lclQuery3);
			
		while($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$sub_category[] = $row3;
		}

		echo json_encode(array("size" => $size, "sub_category" => $sub_category));
	}

?>


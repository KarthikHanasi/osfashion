<?php
	session_start();
	error_reporting(0);
	include_once('../../conn/conn.php');
    include_once('generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
    $UUID = guidv4();

	switch ($action) {
		case 'get_user_heirarchy_details':
			getUserHeirarchyDetails($params, $con);
			break;

        case 'update_wallet':
            updateWallet($params, $con, $UUID);
            break;

        case 'get_mynetwork_refid':
            getMyNetworkRefID($params, $con);
            break;

        case 'user_history':
            userHistory($params, $con);
            break;
	}

	function getUserHeirarchyDetails($params, $con) {

		$treeView = array();

		$recursiveTopToBottomQuery = "WITH RECURSIVE company_hierarchy AS (
            SELECT    us_id,
                        us_name,
                        us_mobile,
                        us_referred_user_id,
						us_referral_code,
                    0 AS hierarchy_level
            FROM users
            WHERE us_id = '".$params['main_id']."'
            UNION ALL
            SELECT    u.us_id,
                        u.us_name,
                        u.us_mobile,
                        u.us_referred_user_id,
						u.us_referral_code,
                    hierarchy_level + 1
            FROM users u, company_hierarchy ch
            WHERE u.us_referred_user_id = ch.us_id
            )
            
            SELECT  ch.us_id AS employee_id,
                    ch.us_name AS name,
                    ch.us_referral_code AS title,
                    ch.us_mobile AS employee_mobile,
                    u.us_id AS main_id,
                    u.us_name AS main_name,
                    u.us_mobile AS main_mobile,
                    hierarchy_level
            FROM company_hierarchy ch
            LEFT JOIN users u
            ON ch.us_referred_user_id = u.us_id
            ORDER BY ch.hierarchy_level, ch.us_id;";

        $recursiveTopToBottomResult = $con->query($recursiveTopToBottomQuery);
        $count = 0;
        while($recursiveTopToBottomRow = $recursiveTopToBottomResult->fetch(PDO::FETCH_ASSOC)) {
            if($count == 0) {

                $recursiveTopToBottomRow['main_id'] = null;
                $recursiveTopToBottomRow['main_name'] = null;
                $recursiveTopToBottomRow['main_mobile'] = null;
                $treeView[] = $recursiveTopToBottomRow;
            } else {
                $treeView[] = $recursiveTopToBottomRow;
            }
            $count++;
            
        }

		echo json_encode($treeView);
	}

    function updateWallet($params, $con, $UUID) {

        if($params['selType'] == "Credit") {
            $newWalletAmount = $params['txtWalletOriginal'] + $params['txtAmount2'];
        } else {
            $newWalletAmount = $params['txtWalletOriginal'] - $params['txtAmount2'];
        }
        
		$lclQuery = $con->prepare("UPDATE users SET
							  us_wallet = :us_wallet
							  WHERE us_id = :us_id");

		$lclQuery->bindParam(':us_wallet', $newWalletAmount);
		$lclQuery->bindParam(':us_id', $params["id"]);
		$lclResult = $lclQuery->execute();

        $lclQuery = $con->prepare("INSERT INTO user_wallet_transactions (uwt_id, uwt_us_id, uwt_type, uwt_prev_wallet, uwt_amount, uwt_new_wallet, uwt_updated_by) VALUES(:uwt_id, :uwt_us_id, :uwt_type, :uwt_prev_wallet, :uwt_amount, :uwt_new_wallet, :uwt_updated_by)");

        $lclQuery->bindParam(':uwt_id', $UUID);
        $lclQuery->bindParam(':uwt_us_id', $params["id"]);
        $lclQuery->bindParam(':uwt_type', $params['selType']);
        $lclQuery->bindParam(':uwt_prev_wallet', $params['txtWalletOriginal']);
        $lclQuery->bindParam(':uwt_amount', $params['txtAmount2']);
        $lclQuery->bindParam(':uwt_new_wallet', $newWalletAmount);
        $lclQuery->bindParam(':uwt_updated_by', $params["loggedInBy"]);
        $lclResult = $lclQuery->execute();

		echo "1";
	}

    function getMyNetworkRefID($params, $con) {
		$details = array();
		$lclQuery1 = "SELECT * FROM users 
		WHERE us_referral_code = '".$params['refId']."'";
		$lclResult1 = $con->query($lclQuery1);

		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$details[] = $row1;
		}

		$details2 = array();
		$lclQuery2 = "SELECT * FROM users 
		WHERE us_id = '".$details[0]['us_referred_user_id']."'";
		$lclResult2 = $con->query($lclQuery2);
		
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$details2[] = $row2;
		}

		echo json_encode(array("details" => $details, "details2" => $details2));
	}

    function userHistory($params, $con) {
        $profiles = array();
		$lclQuery1 = "SELECT * FROM users 
		WHERE us_id = '".$params['user_id']."'";
		$lclResult1 = $con->query($lclQuery1);

		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$profiles[] = $row1;
		}

        $details2 = array();
		$lclQuery = "SELECT * FROM users 
		WHERE us_id = '".$profiles[0]['us_referred_user_id']."'";
		$lclResult = $con->query($lclQuery);
		
		while($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
			$details2[] = $row;
		}

		$orders = array();
		$lclQuery2 = "SELECT * FROM orders
        LEFT JOIN purchased_products ON purchased_products.pp_od_id = orders.or_id
		LEFT JOIN products ON products.pd_id = purchased_products.pp_pd_id
		LEFT JOIN address ON address.ads_id = orders.or_address_id
		LEFT JOIN state ON state.st_id = address.ads_state
		LEFT JOIN size ON size.sz_id = purchased_products.pp_sz_id
		LEFT JOIN color ON color.co_id = products.pd_color 
		WHERE or_us_id = '".$params['user_id']."' ORDER BY or_created_date DESC";
		$lclResult2 = $con->query($lclQuery2);
		
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$orders[] = $row2;
		}

        $network = array();

		$recursiveTopToBottomQuery = "WITH RECURSIVE company_hierarchy AS (
            SELECT    us_id,
                        us_name,
                        us_mobile,
                        us_referred_user_id,
						us_referral_code,
                    0 AS hierarchy_level
            FROM users
            WHERE us_id = '".$params['user_id']."'
            UNION ALL
            SELECT    u.us_id,
                        u.us_name,
                        u.us_mobile,
                        u.us_referred_user_id,
						u.us_referral_code,
                    hierarchy_level + 1
            FROM users u, company_hierarchy ch
            WHERE u.us_referred_user_id = ch.us_id
            )
            
            SELECT  ch.us_id AS employee_id,
                    ch.us_name AS name,
                    ch.us_referral_code AS title,
                    ch.us_mobile AS employee_mobile,
                    u.us_id AS main_id,
                    u.us_name AS main_name,
                    u.us_mobile AS main_mobile,
                    hierarchy_level
            FROM company_hierarchy ch
            LEFT JOIN users u
            ON ch.us_referred_user_id = u.us_id
            ORDER BY ch.hierarchy_level, ch.us_id;";

        $recursiveTopToBottomResult = $con->query($recursiveTopToBottomQuery);
        $count = 0;
        while($recursiveTopToBottomRow = $recursiveTopToBottomResult->fetch(PDO::FETCH_ASSOC)) {
            if($count == 0) {

                $recursiveTopToBottomRow['main_id'] = null;
                $recursiveTopToBottomRow['main_name'] = null;
                $recursiveTopToBottomRow['main_mobile'] = null;
                $network[] = $recursiveTopToBottomRow;
            } else {
                $network[] = $recursiveTopToBottomRow;
            }
            $count++;
            
        }

        $credits = array();
		$creditHistory = "SELECT * FROM amount_credit_history
		LEFT JOIN users ON users.us_id = amount_credit_history.ach_us_id
		WHERE (ach_main_id = '".$params['user_id']."') AND (ach_type != 'coin_credits' AND ach_type != 'business_rank') ORDER BY amount_credit_history.ach_level ASC";
		$creditHistoryResult = $con->query($creditHistory);

		while($creditHistoryRow = $creditHistoryResult->fetch(PDO::FETCH_ASSOC)) {
			$credits[] = $creditHistoryRow;
		}

        $kyc = array();
		$lclQuery4 = "SELECT * FROM kyc 
		WHERE user_id = '".$params['user_id']."'";
		$lclResult4 = $con->query($lclQuery4);

		while($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
			$kyc[] = $row4;
		}

        $withdrawalsDetails = array();
		$lclQuery1 = "SELECT * FROM withdrawals
		LEFT JOIN users ON users.us_id = withdrawals.wt_us_id
		LEFT JOIN kyc ON kyc.id = withdrawals.wt_kyc_id
		WHERE wt_us_id = '".$params['user_id']."'";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$withdrawalsDetails[] = $row1;
		}

        $memberDetails = array();
		$lclQuery6 = "SELECT * FROM users_plans 
        LEFT JOIN plans ON plans.pl_id = users_plans.up_pl_id
		WHERE up_us_id = '".$params['user_id']."'";
		$lclResult6 = $con->query($lclQuery6);

		while($row6 = $lclResult6->fetch(PDO::FETCH_ASSOC)) {
			$memberDetails[] = $row6;
		}

        $walletHistory = array();
		$lclQuery7 = "SELECT * FROM user_wallet_transactions 
        LEFT JOIN users ON users.us_id = user_wallet_transactions.uwt_us_id
		WHERE uwt_us_id = '".$params['user_id']."' ORDER BY uwt_created_date ASC";
		$lclResult7 = $con->query($lclQuery7);

		while($row7 = $lclResult7->fetch(PDO::FETCH_ASSOC)) {
			$walletHistory[] = $row7;
		}

		echo json_encode(array("profiles" => $profiles, "details2" => $details2, "orders" => $orders, "network" => $network, "credits" => $credits, "kyc" => $kyc, "withdrawalsDetails" => $withdrawalsDetails, "memberDetails" => $memberDetails, "walletHistory" => $walletHistory));
    }

?>


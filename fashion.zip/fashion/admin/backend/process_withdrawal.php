<?php
session_start();
// error_reporting(0);
include_once('../../conn/conn.php');
include_once('generate_uuid.php');
$lclCon = new DatabaseClass();
$con = $lclCon->getCon();
$con->exec("SET NAMES 'utf8'");
$params = $_REQUEST;
$action = $params['action'];
$UUID = guidv4();

switch ($action) {

    case 'add':
        add($params, $con, $UUID);
        break;

    case 'get_user_kyc':
        getUserKYC($params, $con, $UUID);
        break;
}

function add($params, $con, $UUID) {
    $lclQuery = $con->prepare("INSERT INTO withdrawals (wt_id, wt_us_id, wt_kyc_id, wt_amount, wt_payment_date, wt_transaction_id) VALUES(:wt_id, :wt_us_id, :wt_kyc_id, :wt_amount, :wt_payment_date, :wt_transaction_id)");

    $lclQuery->bindParam(':wt_id', $UUID);
    $lclQuery->bindParam(':wt_us_id', $params['selUsers']);
    $lclQuery->bindParam(':wt_kyc_id', $params['selKYC']);
    $lclQuery->bindParam(':wt_amount', $params['txtAmount']);
    $lclQuery->bindParam(':wt_payment_date', $params['txtDate']);
    $lclQuery->bindParam(':wt_transaction_id', $params["txtTransactionID"]);
    $lclResult = $lclQuery->execute();

    $lclUpdate = "UPDATE users SET us_wallet = us_wallet - ".$params['txtAmount']."
				WHERE us_id = '".$params['selUsers']."'";
				$con->query($lclUpdate);
    echo "1";
}

function getUserKYC($params, $con) {
    $kyc_details = array();
    $lclQuery = "SELECT * FROM kyc WHERE user_id = '".$params['user_id']."'";
    $lclResult = $con->query($lclQuery);
    if ($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
        $kyc_details[] = $row;
    }
    echo json_encode(array("kyc_details" => $kyc_details));
	
}
?>
<?php
 
/*
 * DataTables example server-side processing script.
 *
 * Please note that this script is intentionally extremely simple to show how
 * server-side processing can be implemented, and probably shouldn't be used as
 * the basis for a large complex system. It is suitable for simple use cases as
 * for learning.
 *
 * See http://datatables.net/usage/server-side for full details on the server-
 * side processing requirements of DataTables.
 *
 * @license MIT - http://datatables.net/license_mit
 */
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */
session_start();
header( 'Content-Type: text/html; charset=utf-8');
// DB table to use
$table = 'orders';
 
// Table's primary key
$primaryKey = 'or_id';
 
// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
$columns = array(
	array( 'db' => '`or_id`', 'dt' => 0, 'field' => 'or_id' ),
	array( 'db' => '`or_readable_id`', 'dt' => 1, 'field' => 'or_readable_id' ),
    array( 'db' => '`ads_fullName`', 'dt' => 2, 'field' => 'ads_fullName' ),
	array( 'db' => '`ads_mobile_number`', 'dt' => 3, 'field' => 'ads_mobile_number' ),
	array( 'db' => '`ads_address`', 'dt' => 4, 'field' => 'ads_address' ),
	array( 'db' => '`or_transaction_no`', 'dt' => 5, 'field' => 'or_transaction_no' ),
	array( 'db' => '`or_total_amount`', 'dt' => 6, 'field' => 'or_total_amount' ),
	array( 'db' => '`or_payment_type`', 'dt' => 7, 'field' => 'or_payment_type' ),
	array( 'db' => '`os_delivery_status`', 'dt' => 8, 'field' => 'os_delivery_status' ),
	array( 'db' => '`or_created_date`', 'dt' => 9, 'field' => 'or_created_date' ),
															
);

$where = "";

include_once('../../conn/table_conn.php');
 
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
 
require( 'ssp.customized.class.php' );

$joinQuery = "FROM `orders` LEFT JOIN `address` ON (`orders`.`or_address_id` = `address`.`ads_id`)";
$extraWhere = "";
$groupBy = "";
$having = "";
 
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, $having )
);

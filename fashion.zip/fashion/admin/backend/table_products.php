<?php
 
/*
 * DataTables example server-side processing script.
 *
 * Please note that this script is intentionally extremely simple to show how
 * server-side processing can be implemented, and probably shouldn't be used as
 * the basis for a large complex system. It is suitable for simple use cases as
 * for learning.
 *
 * See http://datatables.net/usage/server-side for full details on the server-
 * side processing requirements of DataTables.
 *
 * @license MIT - http://datatables.net/license_mit
 */
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */
session_start();
header( 'Content-Type: text/html; charset=utf-8');
// DB table to use
$table = 'products';
 
// Table's primary key
$primaryKey = 'pd_id';
 
// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
$columns = array(
	array( 'db' => '`pd_id`', 'dt' => 0, 'field' => 'pd_id' ),
    array( 'db' => '`ca_name`', 'dt' => 1, 'field' => 'ca_name' ),
	array( 'db' => '`sub_category_name`', 'dt' => 2, 'field' => 'sub_category_name' ),
	// array( 'db' => '`pd_image`', 'dt' => 3, 'field' => 'pd_image' ),
	array( 'db' => '`pd_name`', 'dt' => 3, 'field' => 'pd_name' ),
	array( 'db' => '`pd_product_id`', 'dt' => 4, 'field' => 'pd_product_id' ),
	// array( 'db' => '`pd_short_desc`', 'dt' => 5, 'field' => 'pd_short_desc' ),
	// array( 'db' => '`pd_long_desc`', 'dt' => 6, 'field' => 'pd_long_desc' ),
	array( 'db' => '`pd_price`', 'dt' => 5, 'field' => 'pd_price' ),
	array( 'db' => '`pd_stock`', 'dt' => 6, 'field' => 'pd_stock' ),
	array( 'db' => '`pd_discount`', 'dt' => 7, 'field' => 'pd_discount' ),
	array( 'db' => '`pd_bv`', 'dt' => 8, 'field' => 'pd_bv' ),
	array( 'db' => '`pd_pv`', 'dt' => 9, 'field' => 'pd_pv' ),
	array( 'db' => '`pd_created_at`', 'dt' => 10, 'field' => 'pd_created_at' ),
	array( 'db' => '`pd_status`', 'dt' => 11, 'field' => 'pd_status' ),
															
);

$where = "";

include_once('../../conn/table_conn.php');
 
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
 
require( 'ssp.customized.class.php' );

$joinQuery = "FROM `products` LEFT JOIN `categories` ON (`products`.`pd_category_name` = `categories`.`ca_id`) LEFT JOIN `sub_category` ON (`products`.`pd_sub_category_name` = `sub_category`.`sub_id`)";
$extraWhere = "";
$groupBy = "";
$having = "";
 
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, $having )
);

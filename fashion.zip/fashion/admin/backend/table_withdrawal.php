<?php
 
/*
 * DataTables example server-side processing script.
 *
 * Please note that this script is intentionally extremely simple to show how
 * server-side processing can be implemented, and probably shouldn't be used as
 * the basis for a large complex system. It is suitable for simple use cases as
 * for learning.
 *
 * See http://datatables.net/usage/server-side for full details on the server-
 * side processing requirements of DataTables.
 *
 * @license MIT - http://datatables.net/license_mit
 */
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */
session_start();
header( 'Content-Type: text/html; charset=utf-8');
// DB table to use
$table = 'withdrawals';
 
// Table's primary key
$primaryKey = 'wt_id';
 
// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
$columns = array(
	array( 'db' => '`wt_id`', 'dt' => 0, 'field' => 'wt_id' ),
    array( 'db' => '`us_name`', 'dt' => 1, 'field' => 'us_name' ),
	array( 'db' => '`us_mobile`', 'dt' => 2, 'field' => 'us_mobile' ),
	array( 'db' => '`wt_amount`', 'dt' => 3, 'field' => 'wt_amount' ),
	array( 'db' => '`wt_transaction_id`', 'dt' => 4, 'field' => 'wt_transaction_id'),
	array( 'db' => '`wt_payment_date`', 'dt' => 5, 'field' => 'wt_payment_date' ),
	array( 'db' => '`bank_user_name`', 'dt' => 6, 'field' => 'bank_user_name' ),
	array( 'db' => '`bank_number`', 'dt' => 7, 'field' => 'bank_number' )
															
);

$where = "";

include_once('../../conn/table_conn.php');
 
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
 
require( 'ssp.customized.class.php' );

$joinQuery = "FROM `withdrawals` LEFT JOIN `kyc` ON (`kyc`.`id` = `withdrawals`.`wt_kyc_id`) LEFT JOIN `users` ON (`users`.`us_id` = `withdrawals`.`wt_us_id`) ";
$extraWhere = "";
$groupBy = "";
$having = "";
 
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, $having )
);

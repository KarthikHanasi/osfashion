<?php

    session_start();
    // if (!isset($_SESSION['user_email'])) {
    //     header('Location: index.php');
    // }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Slider Banners</title>
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link href="css/styles.css" rel="stylesheet" />
    <link href="plugins/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous"/>
    <script src="plugins/js/font-awesome-all.min.js" crossorigin="anonymous"></script>

    <style>
        hr {
            margin-top: 1rem;
            margin-bottom: 1rem;
            border: 0;
            border-top: 1px solid rgba(0, 0, 0, 1);
        }
    </style>

</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand" href="#">OsFashion</a><button class="btn btn-link btn-sm order-1 order-lg-0"
            id="sidebarToggle" href="#">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw"></i><?php echo $_SESSION['role']; ?></a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="backend/logout.php">Logout</a>
                </div>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php
                if($_SESSION['role'] == "Admin") {
                    include_once('include/admin_nav.php');
                } else {
                    include_once('include/admin_nav.php');
                }

            ?>
        </div>
        <div id="layoutSidenav_content">
            <div class="container-fluid pt-3">
               

                <div class="row">
                    <div class="col-12">
                        <form>
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-12 text-right mb-4">
                                            <button type="button" class="btn btn-success" data-toggle="modal"
                                                data-target="#add_modal">
                                                Add Banners
                                            </button>
                                        </div>
                                        <div class="col-12">
                                            <div class="card mb-4">
                                                <div class="card-body">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered" id="tableData" width="100%"
                                                            cellspacing="0">
                                                            <thead>
                                                                <tr>
                                                                    <th>Sl No</th>
                                                                    <th>Image</th>
                                                                    <th>Action</th>
                                                                    
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php include_once('include/footer.php'); ?>
        </div>
    </div>

    <!-- SNACKBAR/TOAST -->

    <div id="snackbar-success">success</div>
    <div id="snackbar-error">error</div>

    <!-- SNACKBAR/TOAST -->

    <!-- Loader -->
    <div class="se-pre-con"></div>
    <!-- Loader -->

    <!-- ADD WORK  -->

    <!-- The Modal -->
    <div class="modal fade" id="add_modal">
        <div class="modal-dialog modal-md" style="width: 60%;">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">ADD Banner</h4>
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="#">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Slider Image<span
                                            class="text-danger">*</span></label>
                                    <input type="file" class="form-control" id="fileImage">
                                </div>
                            </div>
                            <div class="col-12 text-center mt-3">
                                <button type="button" class="btn btn-success" id="btn_add">
                                    <span class="spinner-border spinner-border-sm"></span> Save
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- ADD WORK -->

    <!-- EDIT WORK  -->

    <!-- The Modal -->
    <div class="modal fade" id="edit_modal">
        <div class="modal-dialog modal-md" style="width: 60%;">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">EDIT Banner</h4>
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="#">
                        <input type="hidden" id="edit_id">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Slider Image<span
                                            class="text-danger">*</span></label>
                                    <input type="file" class="form-control" id="fileImage1">
                                    <input type="hidden" class="form-control" id="imageURL1">
                                </div>
                            </div>
                            
                            <div class="col-12 text-center mt-3">
                                <button type="button" class="btn btn-success" id="btn_update">
                                    <span class="spinner-border spinner-border-sm"></span> Update
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- EDIT WORK -->


    <!-- Delete Field -->

    <!-- The Modal -->
    <div class="modal fade" id="delete_modal">
        <div class="modal-dialog" style="width: 40%">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <p class="text-center">
                        Are you sure you want to delete?
                    </p>
                    <input type="hidden" id="delete_id">
                    <div class="row">
                        <div class="col-6 text-right">
                            <button type="button" class="btn btn-success" id="btn_delete">Yes</button>
                        </div>
                        <div class="col-6 text-left">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">
                                No
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Field -->

    <script src="plugins/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jsBanners.js"></script>

</body>
</html>
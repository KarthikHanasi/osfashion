<?php

  session_start();
  // if (!isset($_SESSION['user_email'])) {
  //   header('Location: index.php');
  // }
  include_once('../conn/conn.php');
  $db = new DatabaseClass();
  $con = $db->getCon();

  // $sql1 = "SELECT count(*) FROM class";
  // $res1 = $con->query($sql1);
  // $resCount1 = $res1->fetchColumn();

  // $sql2 = "SELECT count(*) FROM subjects";
  // $res2 = $con->query($sql2);
  // $resCount2 = $res2->fetchColumn();

  // $sql3 = "SELECT count(*) FROM lessons";
  // $res3 = $con->query($sql3);
  // $resCount3 = $res3->fetchColumn();

  // $sql4 = "SELECT count(*) FROM video_link";
  // $res4 = $con->query($sql4);
  // $resCount4 = $res4->fetchColumn();


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="csrf-token" content="">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>Dashboard</title>
  <link rel="icon" type="image/x-icon" href="images/logo.png">
  <link href="css/styles.css" rel="stylesheet" />
  <link href="plugins/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous"/>
  <script src="plugins/js/font-awesome-all.min.js" crossorigin="anonymous"></script>
  
</head>

<body class="sb-nav-fixed">
  <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
    <a class="navbar-brand" href="#">OsFashion</a><button class="btn btn-link btn-sm order-1 order-lg-0"
      id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown"
          aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw"></i><?php echo $_SESSION['role']; ?></a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="backend/logout.php">Logout</a>
        </div>
      </li>
    </ul>
  </nav>
  <div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <?php
            if($_SESSION['role'] == "Admin") {
                include_once('include/admin_nav.php');
            } else {
                include_once('include/admin_nav.php');
            }

        ?>
    </div>
    <div id="layoutSidenav_content">
      <main>
        <div class="container-fluid pt-3">
          
          <div class="row">
            <div class="col-xl-12">
              <div class="card bg-primary text-white mb-4">
                <div class="card-body">WELCOME TO ADMIN PANEL</div>
                <!-- <div class="card-footer d-flex align-items-center justify-content-between">
                  <a class="small text-white stretched-link" href="#">View Details</a>
                  <div class="small text-white">
                    <i class="fas fa-angle-right"></i>
                  </div>
                </div> -->
              </div>
            </div>
            <div class="col-xl-3 col-md-6">
              <div class="card bg-warning text-white mb-4">
                <div class="card-body"><b>TOTAL Classes &emsp; <?php echo $resCount1;?></b></div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                  <a class="small text-white stretched-link" href="class.php">View Details</a>
                  <div class="small text-white">
                    <i class="fas fa-angle-right"></i>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6">
              <div class="card bg-success text-white mb-4">
                <div class="card-body"><b>TOTAL Subjects &emsp; <?php echo $resCount2;?></b></div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                  <a class="small text-white stretched-link" href="subjects.php">View Details</a>
                  <div class="small text-white">
                    <i class="fas fa-angle-right"></i>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6">
              <div class="card bg-danger text-white mb-4">
                <div class="card-body"><b>TOTAL Lessons &emsp; <?php echo $resCount3;?></b></div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                  <a class="small text-white stretched-link" href="lessons.php">View Details</a>
                  <div class="small text-white">
                    <i class="fas fa-angle-right"></i>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-6">
              <div class="card bg-primary text-white mb-4">
                <div class="card-body"><b>TOTAL Videos &emsp; <?php echo $resCount4;?></b></div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                  <a class="small text-white stretched-link" href="video_link.php">View Details</a>
                  <div class="small text-white">
                    <i class="fas fa-angle-right"></i>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="form-group">
                  <label>Select Teacher <span class="text-danger">*</span></label>
                    <select class="form-control" id="selTeacher">
                      <option value=""> Please Select Teacher</option>
                      <?php

                        $sql = "SELECT * FROM login";
                        $query = $con->query($sql);
                        while($row = $query->fetch(PDO::FETCH_ASSOC)) {
                          echo '<option value="'.$row['lg_email'].'">'.$row['lg_name'].'</option>';
                        }
                      ?>
                    </select>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="form-group">
                  <label>Search <span class="text-danger">*</span></label>
                  <input type="button" id="btn_search" value="SEARCH" class="form-control btn btn-success">
                </div>
            </div>

            <div class="col-xl-12">
              <div>

                <table class="table">

                  <tr>
                    <th></th>
                    <th>Result</th>
                  </tr>
                  
                  <tr>
                    <td width="500">Total Number of Lessons Uploaded</td>
                    <td id="totalSpanLessons">0</td>
                  </tr>

                  <tr>
                    <td width="500">Total Number of Videos Uploaded</td>
                    <td id="totalSpanVideos">0</td>
                  </tr>

                  <tr>
                    <td width="500">Total Number of Important Questions Uploaded</td>
                    <td id="totalSpanImpQuestions">0</td>
                  </tr>

                  <tr>
                    <td width="500">Total Number of Important Videos Uploaded</td>
                    <td id="totalSpanImpVideos">0</td>
                  </tr>

                  <tr>
                    <td width="500">Total Number of Important Notes Uploaded</td>
                    <td id="totalSpanImpNotes">0</td>
                  </tr>

                  <tr>
                    <td width="500">Total Number of Question Paper Uploaded</td>
                    <td id="totalSpanImpQuestionPaper">0</td>
                  </tr>

                  <tr>
                    <td width="500">Total Number of Text Book Uploaded</td>
                    <td id="totalSpanTextbook">0</td>
                  </tr>

                  <tr>
                    <td width="500">Total Number of Test Taken</td>
                    <td id="totalSpanTestTaken">0</td>
                  </tr>
                </table>
              </div>
            </div>

          </div>
        </div>
      </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; <a href="http://www.infynow.com" target="_blank"> Infynow Business Solutions 2020</a></div>
                    </div>
                </div>
            </footer>
    </div>
  </div>

  <!-- SNACKBAR/TOAST -->

  <div id="snackbar-success">success</div>
  <div id="snackbar-error">error</div>

  <!-- SNACKBAR/TOAST -->

  <!-- Loader -->
  <div class="se-pre-con"></div>
  <!-- Loader -->

    <script src="plugins/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jsDashboard.js"></script>

</body>
</html>
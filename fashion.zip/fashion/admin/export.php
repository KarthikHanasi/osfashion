<?php

require_once 'PHPExcel/Classes/PHPExcel.php';
require_once 'PHPExcel/Classes/PHPExcel/IOFactory.php';
// require_once 'PHPExcel/Classes/PHPExcel/Worksheet.php';
// require_once 'PHPExcel/Classes/PHPExcel/Worksheet/ColumnDimension.php';
include_once('../conn/conn.php');
$lclCon = new DatabaseClass();
$con = $lclCon->getCon();

$lclClass = $_POST['txtClassExport'];

$objPHPExcel    =   new PHPExcel();
if ($lclClass == NULL) {
	# code...
	$result =   $con->query("SELECT * FROM register") or die(mysql_error());
}else
{
	$result   = $con->query("SELECT * FROM register WHERE reg_class = '".$lclClass."'");
}


 
$objPHPExcel->setActiveSheetIndex(0);
 
$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'SI No');
$objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Student Name');
$objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Mobie No');
$objPHPExcel->getActiveSheet()->SetCellValue('D1', 'Email Id');
$objPHPExcel->getActiveSheet()->SetCellValue('E1', 'Roll No');
$objPHPExcel->getActiveSheet()->SetCellValue('F1', 'Medium');
$objPHPExcel->getActiveSheet()->SetCellValue('G1', 'Class');
$objPHPExcel->getActiveSheet()->SetCellValue('H1', 'Address');
 
$objPHPExcel->getActiveSheet()->getStyle("A1:H1")->getFont()->setBold(true);
// $objPHPExcel->getActiveSheet()->getColumnDimensions("A1:H1");
// $objPHPExcel->getActiveSheet()->mergeCells('A1:H1');


 
$rowCount   =   2;
while($row =$result->FETCH(PDO::FETCH_ASSOC)){
    $objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, mb_strtoupper($row['reg_id'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, mb_strtoupper($row['reg_name'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, mb_strtoupper($row['reg_phone']));
    $objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, mb_strtoupper($row['reg_email'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, mb_strtoupper($row['reg_roll_no'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, mb_strtoupper($row['reg_medium'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount, mb_strtoupper($row['reg_class'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount, mb_strtoupper($row['reg_address'],'UTF-8'));
    $rowCount++;
}

 
 
$objWriter  =   new PHPExcel_Writer_Excel2007($objPHPExcel);
 
 
header('Content-Type: application/vnd.ms-excel'); //mime type
header('Content-Disposition: attachment;filename="Student record.xlsx"'); //tell browser what's the file name
header('Cache-Control: max-age=0'); //no cache
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');  
$objWriter->save('php://output');
?>
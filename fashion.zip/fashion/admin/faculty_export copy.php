<?php

require_once 'PHPExcel/Classes/PHPExcel.php';
require_once 'PHPExcel/Classes/PHPExcel/IOFactory.php';
// require_once 'PHPExcel/Classes/PHPExcel/Worksheet.php';
// require_once 'PHPExcel/Classes/PHPExcel/Worksheet/ColumnDimension.php';
include('backend/conn.php');
$lclCon = new DatabaseClass();
$con = $lclCon->getCon();

// $lclClass = $_POST['txtClassExport'];


 
$objPHPExcel    =   new PHPExcel();
$result =   $con->query("SELECT * FROM login") or die(mysql_error());



 
$objPHPExcel->setActiveSheetIndex(0);
 
$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'SI No');
$objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Teacher Name');
$objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Teacher Email');
$objPHPExcel->getActiveSheet()->SetCellValue('D1', 'Teacher Mobile');
$objPHPExcel->getActiveSheet()->SetCellValue('E1', 'Teacher Designation');
$objPHPExcel->getActiveSheet()->SetCellValue('F1', 'Teacher Role');
$objPHPExcel->getActiveSheet()->SetCellValue('G1', 'Teacher Medium');

 
$objPHPExcel->getActiveSheet()->getStyle("A1:G1")->getFont()->setBold(true);
// $objPHPExcel->getActiveSheet()->getColumnDimensions("A1:H1");
// $objPHPExcel->getActiveSheet()->mergeCells('A1:H1');


 
$rowCount   =   2;
while($row =$result->FETCH(PDO::FETCH_ASSOC)){
    $objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, mb_strtoupper($row['lg_id'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, mb_strtoupper($row['lg_name'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, mb_strtoupper($row['lg_email']));
    $objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, mb_strtoupper($row['lg_mobile_no'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, mb_strtoupper($row['lg_designation'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, mb_strtoupper($row['lg_role'],'UTF-8'));
    $objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount, mb_strtoupper($row['lg_medium'],'UTF-8'));
    $rowCount++;
}

 
 
$objWriter  =   new PHPExcel_Writer_Excel2007($objPHPExcel);
 
 
header('Content-Type: application/vnd.ms-excel'); //mime type
header('Content-Disposition: attachment;filename="Faculty record.xlsx"'); //tell browser what's the file name
header('Cache-Control: max-age=0'); //no cache
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');  
$objWriter->save('php://output');
?>
            
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
    
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts"
                                aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Admin Panel
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
    
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne"
                                data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="admin_master.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Admin
                                    </a>
    
                                    <a class="nav-link" href="users.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Users
                                    </a>
    
                                    <a class="nav-link" href="kyc.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        KYC
                                    </a>

                                    <a class="nav-link" href="contact_us.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Contact Us
                                    </a>
                                </nav>
                            </div>
    
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts1"
                                aria-expanded="false" aria-controls="collapseLayouts1">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Order Details
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
    
                            <div class="collapse" id="collapseLayouts1" aria-labelledby="headingOne"
                                data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="orders.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Order Details
                                    </a>
    
                                    <a class="nav-link" href="order_return_reason.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Order Return Reasons
                                    </a>
    
                                    <a class="nav-link" href="order_return_days.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Order Return Days
                                    </a>
    
                                    <a class="nav-link" href="shipping_charges.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Shipping charges
                                    </a>
                                </nav>
    
                            </div>
                            
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts2"
                                aria-expanded="false" aria-controls="collapseLayouts2">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Product Details
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
    
                            <div class="collapse" id="collapseLayouts2" aria-labelledby="headingOne"
                                data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
    
                                    
                                    <a class="nav-link" href="categories.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Category
                                    </a>
    
                                    <a class="nav-link" href="sub_categories.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Sub Category
                                    </a>
    
                                    <a class="nav-link" href="color.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Color
                                    </a>
    
                                    <a class="nav-link" href="size.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Size
                                    </a>
                                    
                                    <a class="nav-link" href="products.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Products
                                    </a>
                                </nav>

                            </div>

                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts3"
                                aria-expanded="false" aria-controls="collapseLayouts3">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Customer Plan Details
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
    
                            <div class="collapse" id="collapseLayouts3" aria-labelledby="headingOne"
                                data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">

                                <a class="nav-link" href="plans.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Plans
                                    </a>
    
                                    
                                    <a class="nav-link" href="member_subscription.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Membership Subscriptions
                                    </a>
    
                                    
                                </nav>
    
                            </div>
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts4"
                                aria-expanded="false" aria-controls="collapseLayouts4">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Documentation 
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
    
                            <div class="collapse" id="collapseLayouts4" aria-labelledby="headingOne"
                                data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
    
                                    
                                    <a class="nav-link" href="networking_business_plan.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        networking business plan
                                    </a>
    
                                    <a class="nav-link" href="company_compliance.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        company compliance
                                    </a>
    
                                    
                                </nav>
    
                            </div>
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts5"
                                aria-expanded="false" aria-controls="collapseLayouts5">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Banners
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
    
                            <div class="collapse" id="collapseLayouts5" aria-labelledby="headingOne"
                                data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
    
                                    
                                    <a class="nav-link" href="banners.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Banner
                                    </a>
    
                                    <a class="nav-link" href="slider_banners.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Slider Banners
                                    </a>
    
                                    
                                </nav>
    
                            </div>
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts6"
                                aria-expanded="false" aria-controls="collapseLayouts6">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Cart Details
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
    
                            <div class="collapse" id="collapseLayouts6" aria-labelledby="headingOne"
                                data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">

                                <a class="nav-link" href="cart.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="far fa-calendar-plus"></i>
                                        </div>
                                        Cart
                                    </a>
    
                                </nav>
    
                            </div>

                            <a class="nav-link" href="withdrawal.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="fas fa-columns"></i>
                                        </div>
                                        Withdrawal
                            </a>

                            <a class="nav-link" href="contact_us.php">
                                        <div class="sb-nav-link-icon">
                                            <i class="fas fa-columns"></i>
                                        </div>
                                        Contact us 
                            </a>

                        </div>
                            
                    </div>
                </nav>        
            </div>
            
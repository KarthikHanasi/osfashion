<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; <a href="#" target="_blank"> Infynow Business Solutions 2023</a></div>
        </div>
    </div>
</footer>
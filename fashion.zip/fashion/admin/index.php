<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Login</title>
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link href="css/styles.css" rel="stylesheet" />
    <script src="plugins/js/font-awesome-all.min.js" crossorigin="anonymous"></script>

    <style>
      .login_body {
        /*background-image: url("./images/ngocover.jpg");*/
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
      }
      .login_body #layoutAuthentication_content {
        position: relative;
      }
      .login_body .col-lg-4 {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      }
      .login_body input[type="email"],
      .login_body input[type="password"] {
        border: 0;
        border-bottom: 1.4px solid #ccc;
        border-radius: 0;
        background-color: white !important;
      }
      .login_body input[type="email"]:focus,
      .login_body input[type="password"]:focus {
        box-shadow: 0 0 0 0.1rem rgb(66 69 72 / 38%);
      }
      .login_body input[type="button"] {
        background: #ff953e;
        border-color: #ff953e;
        color: #fff;
      }
      .login_body input[type="button"]:focus {
        box-shadow: none;
        border:1px solid black;
      }
      .login_body .card {
        position: relative;
        /* box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24) !important; */
      }
      .login_body .card-header {
        background-color: white !important;
        border: none !important;
        padding: 2.8rem;
      }
      .login_body .card-header h3 {
        font-weight: bold !important;
        text-transform: uppercase;
        color: #424242;
        font-size: 1.56rem;
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: #fff;
        margin: auto;
        display: flex;
        justify-content: center;
        align-items: center;
        position: absolute;
        top: -20%;
        left: 50%;
        transform: translateX(-50%);
        box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
      }
    </style>

  </head>
  <body class="login_body">
    <div id="layoutAuthentication">
      <div id="layoutAuthentication_content">
        <main>
          <div class="container">
            <div class="row justify-content-center">
              <div class="col-lg-4">
                <div class="card shadow-lg border-0 rounded-lg mt-5">
                  <div class="card-header">
                    <h3 class="text-center font-weight-light my-4">Login</h3>
                  </div>
                  <div class="card-body pt-0">
                    <form action="backend/login.php" method="POST">
                      <div class="form-group">
                        <label class="small mb-1" for="inputEmailAddress">Email</label>
                        <input class="form-control py-4" autocomplete="off" id="inputEmail" name="inputEmail" type="email" placeholder="Enter email address"/ required>
                      </div>
                      <div class="form-group">
                        <label class="small mb-1" for="inputPassword">Password</label>
                        <input class="form-control py-4" autocomplete="off" id="inputPassword" name="inputPassword" type="password" placeholder="Enter password"/ required>
                      </div>

                      <div class="form-group d-flex align-items-center justify-content-center mt-4 mb-0">
                        <!-- <a type="submit" class="btn btn-primary">Login</a> -->
                        <input type="button" name="submit" id="login" value="Login" class="btn px-4">
                      </div>
                      
                    </form>
                    <div class="d-flex align-items-center justify-content-center small pt-2">
                      <div class="text-muted">Copyright &copy; <b>FASHION</b></div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
      <!-- <div id="layoutAuthentication_footer">
        <footer class="py-4 bg-light mt-auto">
          <div class="container-fluid">
            <div
              class="d-flex align-items-center justify-content-between small"
            >
              <div class="text-muted">Copyright &copy; System Web 2020</div>
            </div>
          </div>
        </footer>
      </div> -->
    </div>
    <script
      src="https://code.jquery.com/jquery-3.4.1.min.js"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"
      crossorigin="anonymous"
    ></script>
    <!-- <script src="js/scripts.js"></script> -->
  </body>
</html>

<script>
  $("#login").click(function (e) {
    //verification
    if ($("#inputEmail").val() == "") {
      alert("Please Enter Valid Email ID");
      $("#inputEmail").focus();
      return false;
    }

    if ($("#inputPassword").val().trim().length < 1) {
      alert("Please Enter Password");
      $("#inputPassword").focus();
      return false;
    }
    
    let formData = new FormData();
    formData.append("inputEmail", $("#inputEmail").val());
    formData.append("inputPassword", $("#inputPassword").val());

    formData.append("action", "login");

    $.ajax({
      beforeSend: function () {
        $("#login").attr("disabled", true);
      },
      url: "backend/login.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {

        if(res == "10") {
          alert("Email ID OR Password is incorrect, Please try again!!!");
        } else {
          localStorage.setItem("admin-login", $("#inputEmail").val());
          window.location = 'admin_master.php';
        }
        
      },
      error: function (res, error) {
        console.error(error);
      },
      complete: function () {
        $("#login").attr("disabled", false);
      },
    });
  });
</script>

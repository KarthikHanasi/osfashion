
$("#btn_add").click(function (e) {
  //verification
  if ($("#txtHeader").val().trim().length < 1) {
      snackbar_error("Please Enter Header");
      $("#txtHeader").focus();
      return false;
  }
   if ($("#txtDescription").val().trim().length < 1) {
      snackbar_error("Please Please Enter Description");
      $("#txtDescription").focus();
      return false;
  }
   if ($("#txtVision").val().trim().length < 1) {
      snackbar_error("Please enter vision");
      $("#txtVision").focus();
      return false;
  }
   if ($("#txtMission").val().trim().length < 1) {
      snackbar_error("Please Enter Missioin");
      $("#txtMission").focus();
      return false;
  }

  //append data
  var formData = new FormData();
 

  formData.append("txtHeader", $("#txtHeader").val());
  formData.append("txtDescription", $("#txtDescription").val());
  formData.append("txtVision", $("#txtVision").val());
  formData.append("txtMission", $("#txtMission").val());
  formData.append("action", "add");

  var table = $("#tableData").DataTable();

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
      $("#btn_add").attr("disabled", true);
    },
    url: "backend/process_about_us.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (result) {
      snackbar_success("About Information added Successfully");
      // location.reload();
      table.ajax.reload();
      $("#add_modal").modal('hide');
    },
    error: function (request, error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
      $("#btn_add").attr("disabled", false);
    },
  });
});

// ADD Testimnials data Table (DONE)
$(document).ready(function () {

  $.fn.dataTableExt.errMode = 'ignore';
  //show data
  var table = $("#tableData").DataTable({
    order: [[0, "desc"]],
    processing: true,
    serverSide: true,
    ajax: "backend/table_about_us.php",
    columnDefs: [
      {
        targets: -1,
        data: null,
        defaultContent:
          '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-pen"></i></a></div>',
      },
    ],
  });

  table.on( 'draw.dt', function () {
    var PageInfo = $('#tableData').DataTable().page.info();
         table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
            cell.innerHTML = i + 1;
        });
    });

  //Edit Btn click
  $(document).on("click", "#edit_row", function () {

    var data = table.row($(this).parents("tr")).data();
    var formData = new FormData();

    $("#txtHeader1").val(data[1]);
    $("#txtDescription1").val(data[2]);
    $("#txtVision1").val(data[3]);
    $("#txtMission1").val(data[4]);
    $("#txtChoose1").val(data[5]);
    $("#edit_id").val(data[0]);

  });

  $(document).on("click", "#delete_row", function () {

    var data = table.row($(this).parents("tr")).data();
    var formData = new FormData();

    $("#delete_id").val(data[0]);

  });

  //Edit modal submit click
  $(document).on("click", "#btn_update", function () {

  if ($("#txtHeader1").val().trim().length < 1) {
      snackbar_error("Please Enter Header");
      $("#txtHeader1").focus();
      return false;
  }
   if ($("#txtDescription1").val().trim().length < 1) {
      snackbar_error("Please Please Enter Description");
      $("#txtDescription1").focus();
      return false;
  }
   if ($("#txtVision1").val().trim().length < 1) {
      snackbar_error("Please enter vision");
      $("#txtVision1").focus();
      return false;
  }
   if ($("#txtMission1").val().trim().length < 1) {
      snackbar_error("Please Enter Missioin");
      $("#txtMission1").focus();
      return false;
  }
  //  if ($("#txtChoose1").val().trim().length < 1) {
  //     snackbar_error("Please Enter Why Choose Us");
  //     $("#txtChoose1").focus();
  //     return false;
  // }
    
    var formData = new FormData()
     if($("#txtImage1").val() != "") {
      var lclImage = document.getElementById("txtImage1");
      lclImage1 = lclImage.files[0];
      formData.append("phPhoto1", lclImage1);
      // formData.append("imageURL1", $("#imageURL1").val());
      $("#txtImage1").val("");
    }
    formData.append("txtHeader1", $("#txtHeader1").val());
    formData.append("txtDescription1", $("#txtDescription1").val());
    formData.append("txtVision1", $("#txtVision1").val());
    formData.append("txtMission1", $("#txtMission1").val());
    formData.append("txtChoose1", $("#txtChoose1").val());
    formData.append("action", "update");
    formData.append("id", $("#edit_id").val());

    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_update").attr("disabled", true);
      },
      url: "backend/process_about_us.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (result) {
        snackbar_success("About Information Updated Succesfully");
        // location.reload();
        table.ajax.reload();
        $("#edit_modal").modal('hide');
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_update").attr("disabled", false);
        
      },
    });
  });

  //Delete work step
  $(document).on("click", "#btn_delete", function () {

    var formData = new FormData();
    formData.append("action", "delete");
    formData.append("id", $("#delete_id").val());


    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
      },

      url: "backend/process_about_us.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function () {
        snackbar_success("About information deleted succesfully");
        // location.reload();
        table.ajax.reload();
        $("#delete_modal").modal('hide');
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        // Reset Form
        //$("#view_field_form")[0].reset();
        $(".close").click();
      },
    });
  });

  $("#selSubjects").change(function() {
    
    var formData = new FormData()
    formData.append("selMedium", $("#selMedium").val());
    formData.append("selClass", $("#selClass").val());
    formData.append("selSubjects", $("#selSubjects").val());
    formData.append("action", "search");

  //   $.ajax({
  //     beforeSend: function () {
  //       $(".btn .spinner-border").show();
  //     },

  //     url: "backend/process_video_link.php",
  //     type: "POST",
  //     data: formData,
  //     processData: false,
  //     contentType: false,
  //     success: function (response) {
  //       $(".btn .spinner-border").hide();
  //       var lclJSON = JSON.parse(response);
  //       $("#selLesson").empty();
  //       $("#selLesson").append("<option value=''>Please Select Lesson</option>");
  //       if(lclJSON.length != 0) {
  //         for(var i = 0; i < lclJSON.length; i++) {
  //           $("#selLesson").append("<option value='"+lclJSON[i].al_lesson_name+"'>"+lclJSON[i].al_lesson_name+"</option>");
  //         }
  //       } else {
  //          snackbar_error("No Lessons Found For this class and subject");
  //       }
        
  //     }
  //   });
  // });

  // $("#selSubjects1").change(function() {
    
  //   var formData = new FormData()
  //   formData.append("selMedium", $("#selMedium1").val());
  //   formData.append("selClass", $("#selClass1").val());
  //   formData.append("selSubjects", $("#selSubjects1").val());
  //   formData.append("action", "search");

  //   $.ajax({
  //     beforeSend: function () {
  //       $(".btn .spinner-border").show();
  //     },

  //     url: "backend/process_video_link.php",
  //     type: "POST",
  //     data: formData,
  //     processData: false,
  //     contentType: false,
  //     success: function (response) {
  //       $(".btn .spinner-border").hide();
  //       var lclJSON = JSON.parse(response);
  //       $("#selLesson1").empty();
  //       $("#selLesson1").append("<option value=''>Please Select Lesson</option>");
  //       if(lclJSON.length != 0) {
  //         for(var i = 0; i < lclJSON.length; i++) {
  //           $("#selLesson1").append("<option value='"+lclJSON[i].al_lesson_name+"'>"+lclJSON[i].al_lesson_name+"</option>");
  //         }
  //       } else {
  //          snackbar_error("No Lessons Found For this class and subject");
  //       }
        
  //     }
  //   });
  });
});

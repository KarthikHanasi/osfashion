

$("#btn_add").click(function (e) {
  //verification
  if ($("#txtName").val().trim().length < 1) {
    snackbar_error("Please Enter Area");
    $("#txtName").focus();
    return false;
  }

  if ($("#txtDistance").val().trim().length < 1) {
    snackbar_error("Please Enter Distance");
    $("#txtDistance").focus();
    return false;
  }

  //append data
  var formData = new FormData();
  formData.append("txtName", $("#txtName").val());
  formData.append("txtDistance", $("#txtDistance").val());

  formData.append("action", "add");

  var table = $("#tableData").DataTable();

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
      $("#btn_add").attr("disabled", true);
    },
    url: "backend/process_areas.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (result) {
       if(result.trim() == "10") {
        snackbar_error("Area already Exist, Please Check and Add");
      } else {
        snackbar_success("Area Added Successfully");
        // location.reload();
        table.ajax.reload();
        $("#add_modal").modal('hide');
      }
    },
    error: function (request, error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
      $("#btn_add").attr("disabled", false);
    },
  });
});

// ADD Testimnials data Table (DONE)
$(document).ready(function () {

  // $.fn.dataTableExt.errMode = 'ignore';
  //show data
  var table = $("#tableData").DataTable({
    order: [[0, "desc"]],
    processing: true,
    serverSide: true,
    ajax: "backend/table_areas.php",
    columnDefs: [
      {
        targets: -1,
        data: null,
        defaultContent:
          '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-pen"></i></a><a href="javascript:void(0);" title="Delete" data-toggle="modal" data-target="#delete_modal" class="text-danger" id="delete_row"> <i class="far fa-trash-alt"></i></a></div>',
      },
    ],
  });

  table.on( 'draw.dt', function () {
    var PageInfo = $('#tableData').DataTable().page.info();
         table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
            cell.innerHTML = i + 1;
        });
    });

  //Edit Btn click
  $(document).on("click", "#edit_row", function () {

    var data = table.row($(this).parents("tr")).data();
    var formData = new FormData();

    $("#txtName1").val(data[1]);
    $("#txtDistance1").val(data[2]);
    $("#edit_id").val(data[0]);

  });

  $(document).on("click", "#delete_row", function () {

    var data = table.row($(this).parents("tr")).data();
    var formData = new FormData();

    $("#delete_id").val(data[0]);

  });

  //Edit modal submit click
  $(document).on("click", "#btn_update", function () {

    if ($("#txtName1").val().trim().length < 1) {
      snackbar_error("Please Enter Area Name");
      $("#txtName1").focus();
      return false;
    }

    if ($("#txtDistance1").val().trim().length < 1) {
      snackbar_error("Please Enter Distance");
      $("#txtDistance1").focus();
      return false;
    }
    
    var formData = new FormData()
    formData.append("txtName1", $("#txtName1").val());
    formData.append("txtDistance1", $("#txtDistance1").val());
    formData.append("action", "update");
    formData.append("id", $("#edit_id").val());

    var table = $("#tableData").DataTable();

    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_update").attr("disabled", true);
      },
      url: "backend/process_areas.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (result) {
       if(result.trim() == "10") {
        snackbar_error("Area already Exist, Please Check and Add");
      } else {
        snackbar_success("Area Updated Successfully");
        // location.reload();
        table.ajax.reload();
        $("#edit_modal").modal('hide');
      }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_update").attr("disabled", false);
      },
    });
  });

  //Delete work step
  $(document).on("click", "#btn_delete", function () {

    var formData = new FormData();
    formData.append("action", "delete");
    formData.append("id", $("#delete_id").val());

    var table = $("#tableData").DataTable();

    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
      },

      url: "backend/process_areas.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function () {
        snackbar_success("Area deleted succesfully");
        // location.reload();
        table.ajax.reload();
        $("#delete_modal").modal('hide');
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $(".close").click();
      },
    });
  });
});


$("#btn_add").click(function (e) {
  //verification
  if ($("#txtEmail").val().trim().length < 1) {
      snackbar_error("Please Enter EmailId");
      $("#txtEmail").focus();
      return false;
  }
   if ($("#txtMobile").val().trim().length < 1) {
      snackbar_error("Please Enter Mobile No");
      $("#txtMobile").focus();
      return false;
  }
  if ($("#txtAddress").val().trim().length < 1) {
      snackbar_error("Please Enter Address");
      $("#txtAddress").focus();
      return false;
  }
   if ($("#txtMap").val().trim().length < 1) {
      snackbar_error("Please Enter Map Link");
      $("#txtMap").focus();
      return false;
  }

  if ($("#txtImage").val().trim().length < 1) {
      snackbar_error("Please Select Image");
      $("#txtImage").focus();
      return false;
  }


  if ($("#txtFacebook").val().trim().length < 1) {
      snackbar_error("Please Enter Facebook Link");
      $("#txtFacebook").focus();
      return false;
  }

  if ($("#txtTwitter").val().trim().length < 1) {
      snackbar_error("Please Enter Twitter Link");
      $("#txtTwitter").focus();
      return false;
  }

  if ($("#txtInstagram").val().trim().length < 1) {
      snackbar_error("Please Enter Instagram Link");
      $("#txtInstagram").focus();
      return false;
  }

  if ($("#txtYoutube").val().trim().length < 1) {
      snackbar_error("Please Enter Instagram Link");
      $("#txtYoutube").focus();
      return false;
  }
  var str = $("#txtMap").val();
  var n = str.search("<iframe");
  if (n == -1) {
      // alert("please enter the correct youtube embed link");
      snackbar_error("please enter the correct Map embed link");
      return false;
  }
  

  //append data
  var formData = new FormData();
  var lclImage = document.getElementById("txtImage");
  lclImage1 = lclImage.files[0];
  formData.append("phPhoto", lclImage1);

  formData.append("txtEmail", $("#txtEmail").val());
  formData.append("txtMobile", $("#txtMobile").val());
  formData.append("txtAddress", $("#txtAddress").val());
  formData.append("txtMap", $("#txtMap").val());
  formData.append("txtFacebook", $("#txtFacebook").val());
  formData.append("txtTwitter", $("#txtTwitter").val());
  formData.append("txtInstagram", $("#txtInstagram").val());
  formData.append("txtYoutube", $("#txtYoutube").val());
  formData.append("action", "add");

  var table = $("#tableData").DataTable();

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
      $("#btn_add").attr("disabled", true);
    },
    url: "backend/process_contact_info.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (result) {
      snackbar_success("Contact Information added Successfully");
       // location.reload();
      table.ajax.reload();
      $("#add_modal").modal('hide');
    },
    error: function (request, error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
      $("#btn_add").attr("disabled", false);
    },
  });
});

// ADD Testimnials data Table (DONE)
$(document).ready(function () {

  $.fn.dataTableExt.errMode = 'ignore';
  //show data
  var table = $("#tableData").DataTable({
    order: [[0, "desc"]],
    processing: true,
    serverSide: true,
    ajax: "backend/table_contact_info.php",
    columnDefs: [
      {
        targets: -1,
        data: null,
        defaultContent:
          '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-pen"></i></a></div>',
      },
    ],
  });

  table.on( 'draw.dt', function () {
    var PageInfo = $('#tableData').DataTable().page.info();
         table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
            cell.innerHTML = i + 1;
        });
    });

  //Edit Btn click
  $(document).on("click", "#edit_row", function () {

    var data = table.row($(this).parents("tr")).data();
    var formData = new FormData();

    $("#txtEmail1").val(data[1]);
    $("#txtMobile1").val(data[2]);
    $("#txtAddress1").val(data[3]);
    $("#txtMap1").val(data[4]);
    $("#imageURL1").val(data[5]);
    $("#txtFacebook1").val(data[6]);
    $("#txtTwitter1").val(data[7]);
    $("#txtInstagram1").val(data[8]);
    $("#txtYoutube1").val(data[9]);
    $("#edit_id").val(data[0]);

  });

  $(document).on("click", "#delete_row", function () {

    var data = table.row($(this).parents("tr")).data();
    var formData = new FormData();

    $("#delete_id").val(data[0]);

  });

  //Edit modal submit click
  $(document).on("click", "#btn_update", function () {

     // var formData = new FormData();

    if($("#txtImage1").val() != "") {
      var lclImage = document.getElementById("txtImage1");
      lclImage1 = lclImage.files[0];
      formData.append("phPhoto1", lclImage1);
      // formData.append("imageURL1", $("#imageURL1").val());
      $("#txtImage1").val("");
    }

    if ($("#txtEmail1").val().trim().length < 1) {
      snackbar_error("Please Enter Email Id");
      $("#txtEmail1").focus();
      return false;
    }
     if ($("#txtMobile1").val().trim().length < 1) {
        snackbar_error("Please Enter Mobile No");
        $("#txtMobile1").focus();
        return false;
    }
    if ($("#txtAddress1").val().trim().length < 1) {
        snackbar_error("Please Enter Address");
        $("#txtAddress1").focus();
        return false;
    }
     if ($("#txtMap1").val().trim().length < 1) {
        snackbar_error("Please Enter Map Link");
        $("#txtMap1").focus();
        return false;
    }
    var str = $("#txtMap1").val();
    var n = str.search("<iframe");
    if (n == -1) {
        // alert("please enter the correct youtube embed link");
       snackbar_error("please enter the correct Map embed link");
      return false;
    }

    if ($("#txtFacebook1").val().trim().length < 1) {
        snackbar_error("Please Enter Facebook Link");
        $("#txtFacebook1").focus();
        return false;
    }

    var str = $("#txtFacebook1").val();
    var n = str.search("www.facebook.com/");
    if (n == -1) {
        // alert("please enter the correct youtube embed link");
       snackbar_error("please enter the correct Facebook link");
      return false;
    }


    if ($("#txtTwitter1").val().trim().length < 1) {
        snackbar_error("Please Enter Twitter Link");
        $("#txtTwitter1").focus();
        return false;
    }

  var str = $("#txtTwitter1").val();
  var n = str.search("twitter.com/");
  if (n == -1) {
      // alert("please enter the correct youtube embed link");
     snackbar_error("please enter the correct Twitter link");
    return false;
  }

  if ($("#txtInstagram1").val().trim().length < 1) {
      snackbar_error("Please Enter Map Link");
      $("#txtInstagram1").focus();
      return false;
  }

  var str = $("#txtInstagram1").val();
  var n = str.search("www.instagram.com/");
  if (n == -1) {
      // alert("please enter the correct youtube embed link");
     snackbar_error("please enter the correct Instagram link");
    return false;
  }

  if ($("#txtYoutube1").val().trim().length < 1) {
      snackbar_error("Please Enter youtube Link");
      $("#txtYoutube1").focus();
      return false;
  }
  var str = $("#txtYoutube1").val();
  var n = str.search("www.youtube.com/");
  if (n == -1) {
      // alert("please enter the correct youtube embed link");
     snackbar_error("please enter the correct youtube link");
    return false;
  }
  
    
    var formData = new FormData()
    formData.append("txtEmail1", $("#txtEmail1").val());
    formData.append("txtMobile1", $("#txtMobile1").val());
    formData.append("txtAddress1", $("#txtAddress1").val());
    formData.append("txtMap1", $("#txtMap1").val());
    formData.append("txtFacebook1", $("#txtFacebook1").val());
    formData.append("txtTwitter1", $("#txtTwitter1").val());
    formData.append("txtInstagram1", $("#txtInstagram1").val());
    formData.append("txtYoutube1", $("#txtYoutube1").val());
    formData.append("action", "update");
    formData.append("id", $("#edit_id").val());

    var table = $("#tableData").DataTable();

    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_update").attr("disabled", true);
      },
      url: "backend/process_contact_info.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (result) {
        snackbar_success("Contact us Information Updated Succesfully");
        // location.reload();
        table.ajax.reload();
        $("#edit_modal").modal('hide');
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_update").attr("disabled", false);
        
      },
    });
  });

  //Delete work step
  $(document).on("click", "#btn_delete", function () {

    var formData = new FormData();
    formData.append("action", "delete");
    formData.append("id", $("#delete_id").val());

    var table = $("#tableData").DataTable();

    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
      },

      url: "backend/process_contact_info.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function () {
        snackbar_success("Contact information deleted succesfully");
        // location.reload();
        table.ajax.reload();
        $("#delete_modal").modal('hide');
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        // Reset Form
        //$("#view_field_form")[0].reset();
        $(".close").click();
      },
    });
  });
});

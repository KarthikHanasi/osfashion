

$("#btn_search").click(function (e) {
  //verification
  if ($("#selTeacher").val().trim().length < 1) {
    snackbar_error("Please Select Teacher");
    $("#selTeacher").focus();
    return false;
  }

  //append data
  var formData = new FormData();
  formData.append("selTeacher", $("#selTeacher").val());
  formData.append("action", "add");

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
      $("#btn_add").attr("disabled", true);
    },
    url: "backend/process_dashboard.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {

      var lclJSON = JSON.parse(response);

      $("#totalSpanLessons").text(lclJSON.lessons);
      $("#totalSpanVideos").text(lclJSON.videos);
      $("#totalSpanImpQuestions").text(lclJSON.impQuestions);
      $("#totalSpanImpVideos").text(lclJSON.impVideos);
      $("#totalSpanImpNotes").text(lclJSON.impNotes);
      $("#totalSpanImpQuestionPaper").text(lclJSON.impQuestionPaper);
      $("#totalSpanTextbook").text(lclJSON.impTextBoks);
      $("#totalSpanTestTaken").text(lclJSON.testConfig);
      
    },
    error: function (request, error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
      $("#btn_add").attr("disabled", false);
    },
  });
});


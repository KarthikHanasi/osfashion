$(document).ready(function () {
  //show data
  let table = $("#tableData").DataTable({
    order: [[0, "desc"]],
    processing: true,
    serverSide: true,
    ajax: "backend/table_kyc.php",
    columnDefs: [
      {
        targets: -1,
        data: null,
        defaultContent:
          '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="btn btn-success">Verify</a></div>',
      },
    ],
  });

  table.on("draw.dt", function () {
    $("#tableData").DataTable().page.info();
    table
      .column(0, { page: "current" })
      .nodes()
      .each(function (cell, i) {
        cell.innerHTML = i + 1;
      });
  });
});

$("#btn_update_accept").click(function () {
  let formData = new FormData();
  formData.append("aadharStatus", $("#aadharStatus").val());
  formData.append("panStatus", $("#panStatus").val());
  formData.append("bankStatus", $("#bankStatus").val());
  formData.append("action", "update_documents_status");
  formData.append("id", $("#edit_id").val());
  let table = $("#tableData").DataTable();

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
      $("#btn_update_accept").attr("disabled", true);
    },
    url: "backend/process_kyc.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (result) {
      if (result.trim() == "1") {
        snackbar_success("Verfied Successfully");
        table.ajax.reload();
        $("#edit_modal").modal("hide");
      } else {
        snackbar_success("Something went wrong");
      }
    },
    error: function (request, error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
      $("#btn_update_accept").attr("disabled", false);
    },
  });
});

$(document).on("click", "#edit_row", function () {
  let table = $("#tableData").DataTable();
  let data = table.row($(this).parents("tr")).data();

  $("#edit_id").val(data[0]);
  $("#aadharStatus").val(data[5]);
  $("#panStatus").val(data[6]);
  $("#bankStatus").val(data[7]);

  let formData = new FormData();
  formData.append("id", data[0]);
  formData.append("action", "get_kyc_files");

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").hide();
    },
    url: "backend/process_kyc.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {

      let lclJSON = JSON.parse(response);
      let [kycDetails] = lclJSON.kyc_details;
      const aadharFile = kycDetails.aadhar_file || "#";
      const panFile = kycDetails.pan_file || "#";
      const bankFile = kycDetails.bank_file || "#";
      const aadharNumber = kycDetails.aadhar_number || "-";
      const accountName = kycDetails.bank_user_name || "-";
      const accountNumber = kycDetails.bank_number || "-";
      const bankName = kycDetails.bank_name || "-";
      const ifscCode = kycDetails.bank_ifsc_code || "-";
      const panNumber = kycDetails.pan_number || "-";

      if(aadharNumber == "-") {
        $("#aadharStatus").hide();
      }

      if(panNumber == "-") {
        $("#panStatus").hide();
      }

      if(accountName == "-" || accountNumber == "-" || bankName == "-" || ifscCode == "-") {
        $("#bankStatus").hide();
      }


      $("#aadharFile").attr("href", aadharFile);
      $("#panFile").attr("href", panFile);
      $("#bankFile").attr("href", bankFile);
      $("#aadharNumber").text(aadharNumber);
      $("#panNumber").text(panNumber);
      $("#accountName").text(accountName);
      $("#accountNumber").text(accountNumber);
      $("#bankName").text(bankName);
      $("#ifscCode").text(ifscCode);
    }
  });
});


// ADD Testimnials data Table (DONE)
$(document).ready(function () {
    //show data
    let table = $("#tableData").DataTable({
      order: [[0, "desc"]],
      processing: true,
      serverSide: true,
      ajax: "backend/table_order_return_days.php",
      columnDefs: [
        {
          targets: -1,
          data: null,
          defaultContent:
            '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-pen"></i></a></div>',
        },
      ],
    });
  
      table.on( 'draw.dt', function () {
        $('#tableData').DataTable().page.info();
          table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
            cell.innerHTML = i + 1;
        });
      });
  
    //Edit Btn click
    $(document).on("click", "#edit_row", function () {
      let data = table.row($(this).parents("tr")).data();
      $("#txtDays1").val(data[1]);
      $("#edit_id").val(data[0]);
    });
  
    //Edit modal submit click
    $(document).on("click", "#btn_update", function () {
  
      if ($("#txtDays1").val().trim().length < 1) {
        snackbar_error("Please Enter Order Return Days");
        $("#txtDays1").focus();
        return false;
      }
  
      //append data
      let formData = new FormData();
      formData.append("txtDays1", $("#txtDays1").val());
      formData.append("action", "update");
      formData.append("id", $("#edit_id").val());
  
      let table = $("#tableData").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update").attr("disabled", true);
        },
        url: "backend/process_order_return_days.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
          snackbar_success("Order Return Days Updated Successfully");
          table.ajax.reload();
          $("#edit_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update").attr("disabled", false);
        },
      });
    });
  });
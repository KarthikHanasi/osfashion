
// ADD Testimnials data Table (DONE)
$(document).ready(function () {

  $.fn.dataTableExt.errMode = 'ignore';
  //show data
  let table = $("#tableData").DataTable({

    rowCallback: function( row, data ) {

      if ( data[8] == "ORDERED") {
          $('td', row).css('background-color', '#FCB0B0');
      } else if ( data[8] == "CANCELLED"){
          $('td', row).css('background-color', 'yellow');
      } else {
          $('td', row).css('background-color', 'rgb(2 243 127 / 46%)');
      }
    },
    order: [[9, "desc"]],
    processing: true,
    serverSide: true,
    ajax: "backend/table_order.php",
    columnDefs: [
      {
        targets: -1,
        data: null,
        defaultContent:
          '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-eye"></i></a></div>',
      },
    ],
  });

  table.on( 'draw.dt', function () {
    $('#tableData').DataTable().page.info();
         table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
            cell.innerHTML = i + 1;
        });
    });

  //Edit Btn click
  $(document).on("click", "#edit_row", function () {

    let data = table.row($(this).parents("tr")).data();
    let formData = new FormData();

    $("#edit_id").val(data[0]);
    $("#txtOrderID1").val(data[1]);
    $("#txtName1").val(data[2]);
    $("#txtMobileNo1").val(data[3]);
    $("#txtTransactionid1").val(data[5]);
    $("#txtAmount1").val(data[6]);
    $("#txtOrderStatus1").val(data[8]);

    if(data[8] != "DELIVERED") {
      $(".cancel-order").show();
    }

    if(data[8] == "CANCELLED") {
      $(".cancel-order").hide();
    }
    
    formData.append("orderID", data[0]);
    formData.append("action", "get_order_details");

    $.ajax({
      beforeSend: function () {
      },
      url: "backend/process_orders.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {

        $("#tableOrders tr:gt(0)").remove();
        let lclJSON = JSON.parse(response);

        let lclAddress = `${lclJSON[0].ads_address}  ${lclJSON[0].ads_city} ${lclJSON[0].st_name} ${lclJSON[0].ads_pincode}`;

        $("#divAddress").text(lclAddress);
        $(".payment-status").hide();
        $(".delivery-status").hide();
        $("#selPaymentStatus").val('');
        $("#selDeliveryStatus").val('');
        
        if(lclJSON[0].or_payment_status === "PENDING") {
          $(".payment-status").show();
        }

        if(lclJSON[0].os_delivery_status === "ORDERED") {
          $(".delivery-status").show();
        }

        for(let i = 0; i < lclJSON.length; i++) {
          let j = i + 1;
          let totalPrice = Number(lclJSON[i].pp_pd_price) * Number(lclJSON[i].pp_qty);

          let img = "";

          if(lclJSON[i].pd_image.includes('s3')) {
            img = lclJSON[i].pd_image;
          } else {
            img = '"../'+lclJSON[i].pd_image+'"';
          }

          $("#tableOrders").append("<tr><td>"+j+"</td><td><img src="+img+" height='75'></td><td>"+lclJSON[i].pd_name+" (<b>"+lclJSON[i].pd_product_id+")</b></td><td>"+lclJSON[i].sz_name+"</td><td>"+lclJSON[i].co_name+"</td><td>"+lclJSON[i].pp_pd_price+"</td><td>"+lclJSON[i].pp_qty+"</td><td>"+totalPrice+"</td></tr>");
        }

      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {

      },
    });
    
  });

  //Edit modal submit click
  $(document).on("click", "#btn_payment", function () {

    let formData = new FormData();

    if ($("#selPaymentStatus").val().trim().length < 1) {
      snackbar_error("Please Select Payment Status");
      $("#selPaymentStatus").focus();
      return false;
    }

    formData.append("selPaymentStatus", $("#selPaymentStatus").val());
    formData.append("action", "update_payment");
    formData.append("id", $("#edit_id").val());

    let table = $("#tableData").DataTable();
    
    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_payment").attr("disabled", true);
      },
      url: "backend/process_orders.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (result) {
        snackbar_success("Payment Status Updated to SUCCESS");
        table.ajax.reload();
        $("#edit_modal").modal('hide');
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_payment").attr("disabled", false);
      },
    });
  });

  //Update work step
  $(document).on("click", "#btn_delivery", function () {

    let formData = new FormData();

    if ($("#selDeliveryStatus").val().trim().length < 1) {
      snackbar_error("Please Select Delivery Status");
      $("#selDeliveryStatus").focus();
      return false;
    }

    formData.append("selDeliveryStatus", $("#selDeliveryStatus").val());
    formData.append("action", "update_delivery");
    formData.append("id", $("#edit_id").val());

    let table = $("#tableData").DataTable();
    
    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_delivery").attr("disabled", true);
      },
      url: "backend/process_orders.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (result) {
        snackbar_success("Delivery Status Updated to DELIVERED");
        table.ajax.reload();
        $("#edit_modal").modal('hide');
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_delivery").attr("disabled", false);
      },
    });
  });

  $(document).on("click", "#btn_cancel", function () {

    let data = table.row($(this).parents("tr")).data();
    if ($("#selCancel").val().trim().length < 1) {
      snackbar_error("Please Select Cancel Type");
      $("#selCancel").focus();
      return false;
    }
    $('#reasonOrderCancel').modal('show');
  });
    
});

function cancelOrder() {
  let cancelTrue = confirm("Are you sure want to Cancel Order?")

    if(!cancelTrue) {
      return false;
    }

    let formData = new FormData();

    formData.append("selCancel", $("#selCancel").val());
    formData.append("action", "cancel_order");
    formData.append("orderID", $("#edit_id").val());

    let table = $("#tableData").DataTable();
    
    $.ajax({
      beforeSend: function () {
        $(".btn_cancel .spinner-border").show();
        $("#btn_cancel").attr("disabled", true);
      },
      url: "backend/process_orders.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        if(response.trim() == "10") {
          alert("You cannot cancel order, you exceeded 15 days cancel policy");
        } else if(response.trim() == "20") {
          alert("Order is Already Cancelled");
        } else {
          alert("Order Cancellation is Successful, Thank you");
          location.reload();
        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn_cancel .spinner-border").hide();
        $("#btn_cancel").attr("disabled", false);
      },
    });
}


$("#btn_add").click(function (e) {
  //verification
  if ($("#txtImage").val().trim().length < 1) {
      snackbar_error("Please Select Image");
      $("#txtImage").focus();
      return false;
  }

  if ($("#txtTitle").val().trim().length < 1) {
      snackbar_error("Please Enter Title");
      $("#txtTitle").focus();
      return false;
  }

  if ($("#txtContent").val().trim().length < 1) {
      snackbar_error("Please Enter Content");
      $("#txtContent").focus();
      return false;
  }
  if ($("#txtAuthor").val().trim().length < 1) {
      snackbar_error("Please Enter Author Name");
      $("#txtAuthor").focus();
      return false;
  }

  //append data
  var d = new Date();
  var date = d.getDate();

  var d = new Date();
  var month = d.getMonth()+1;

  var d = new Date();
  var year = d.getFullYear();

  var formData = new FormData();
  var lclImage = document.getElementById("txtImage");
  lclImage1 = lclImage.files[0];
  formData.append("imageBlog", lclImage1);
  formData.append("date", date);
  formData.append("month", month);
  formData.append("year", year);
  formData.append("txtTitle", $("#txtTitle").val());
  formData.append("txtContent", $("#txtContent").val());
  formData.append("txtAuthor", $("#txtAuthor").val());
  formData.append("action", "add");

  var table = $("#tableData").DataTable();

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
      $("#btn_add").attr("disabled", true);
    },
    url: "backend/process_payments.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (result) {
      snackbar_success("Blog Added Successfully");
      table.ajax.reload();
      $("#add_modal").modal('hide');
    },
    error: function (request, error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
      $("#btn_add").attr("disabled", false);
    },
  });
});

// ADD Testimnials data Table (DONE)
$(document).ready(function () {

  $.fn.dataTableExt.errMode = 'ignore';
  //show data
  var table = $("#tableData").DataTable({
    order: [[0, "desc"]],
    processing: true,
    serverSide: true,
    ajax: "backend/table_payments.php",
    columnDefs: [
      {
        targets: -1,
        data: null,
        defaultContent:
          '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-pen"></i></a><a href="javascript:void(0);" title="Delete" data-toggle="modal" data-target="#delete_modal" class="text-danger" id="delete_row"> <i class="far fa-trash-alt"></i></a></div>',
      },
    ],
  });

  table.on( 'draw.dt', function () {
    var PageInfo = $('#tableData').DataTable().page.info();
         table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
            cell.innerHTML = i + 1;
        });
    });

  //Edit Btn click
  $(document).on("click", "#edit_row", function () {

    var data = table.row($(this).parents("tr")).data();
    var formData = new FormData();

    $("#imageURL1").val(data[1]);
    $("#txtTitle1").val(data[2]);
    $("#txtContent1").val(data[3]);
    $("#txtAuthor1").val(data[4]);
    $("#edit_id").val(data[0]);
    $("#showImage").attr("src", '../'+data[1]);
    
  });

  $(document).on("click", "#delete_row", function () {

    var data = table.row($(this).parents("tr")).data();
    var formData = new FormData();

    $("#delete_id").val(data[0]);

  });

  //Edit modal submit click
  $(document).on("click", "#btn_update", function () {

    var formData = new FormData();

    if($("#txtImage1").val() != "") {
      var lclImage = document.getElementById("txtImage1");
      lclImage1 = lclImage.files[0];
      formData.append("imageBlog1", lclImage1);
      $("#imageURL1").val("");
    }

    if ($("#txtTitle1").val().trim().length < 1) {
        snackbar_error("Please Enter Title");
        $("#txtTitle1").focus();
        return false;
    }

    if ($("#txtContent1").val().trim().length < 1) {
      snackbar_error("Please Enter Content");
      $("#txtContent1").focus();
      return false;
    }

    if ($("#txtAuthor1").val().trim().length < 1) {
      snackbar_error("Please Enter Content");
      $("#txtAuthor1").focus();
      return false;
    }
    
    // formData.append("imageURL1", $("#imageURL1").val());
     // formData.append("imageBlog", lclImage1);
    formData.append("imageURL1", $("#imageURL1").val());
    formData.append("txtTitle1", $("#txtTitle1").val());
    formData.append("txtContent1", $("#txtContent1").val());
    formData.append("txtAuthor1", $("#txtAuthor1").val());
    formData.append("action", "update");
    formData.append("id", $("#edit_id").val());

    var table = $("#tableData").DataTable();
    
    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_update").attr("disabled", true);
      },
      url: "backend/process_payments.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (result) {
        snackbar_success("Blog Updated Succesfully");
        // location.reload();
        table.ajax.reload();
        $("#edit_modal").modal('hide');
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_update").attr("disabled", false);
      },
    });
  });

  //Delete work step
  $(document).on("click", "#btn_delete", function () {

    var formData = new FormData();
    formData.append("action", "delete");
    formData.append("id", $("#delete_id").val());

    var table = $("#tableData").DataTable();

    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
      },

      url: "backend/process_payments.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function () {
        snackbar_success("Blog deleted succesfully");
        // location.reload();
        table.ajax.reload();
        $("#delete_modal").modal('hide');
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $(".close").click();
      },
    });
  });
});
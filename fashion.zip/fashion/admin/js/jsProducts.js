
$("#btn_add").click(function (e) {

  //append data
  let formData = new FormData();

  if ($("#selCategory").val().trim().length < 1) {
      snackbar_error("Please Select Category");
      $("#selCategory").focus();
      return false;
  }

  if ($("#selSubCategory").val().trim().length < 1) {
    snackbar_error("Please Select Sub Category");
    $("#selSubCategory").focus();
    return false;
  }


  if ($("#txtImage").val().trim().length < 1) {
    snackbar_error("Please Select Image");
    $("#txtImage").focus();
    return false;
  }

  if(!$("#txtSubImage1").val().trim().length < 1) {
    let lclSubImage1 = document.getElementById("txtSubImage1");
    lclSubImage1 = lclSubImage1.files[0];
    formData.append("subImage1", lclSubImage1);
    $("#txtSubImageText1").val("");
  }

  if(!$("#txtSubImage2").val().trim().length < 1) {
    let lclSubImage2 = document.getElementById("txtSubImage2");
    lclSubImage2 = lclSubImage2.files[0];
    formData.append("subImage2", lclSubImage2);
    $("#txtSubImageText2").val("");
  }

  if(!$("#txtSubImage3").val().trim().length < 1) {
    let lclSubImage3 = document.getElementById("txtSubImage3");
    lclSubImage3 = lclSubImage3.files[0];
    formData.append("subImage3", lclSubImage3);
    $("#txtSubImageText3").val("");
  }

  if(!$("#txtSubImage4").val().trim().length < 1) {
    let lclSubImage4 = document.getElementById("txtSubImage4");
    lclSubImage4 = lclSubImage4.files[0];
    formData.append("subImage4", lclSubImage4);
    $("#txtSubImageText4").val("");
  }
  
  if ($("#txtName").val().trim().length < 1) {
    snackbar_error("Please Enter Product Name");
    $("#txtName").focus();
    return false;
  }

  if ($("#txtProductID").val().trim().length < 1) {
    snackbar_error("Please Enter Product ID");
    $("#txtProductID").focus();
    return false;
  }

  const color = [];
  const size = [];
  const sizeStockData = [];

  $("input[name='color[]']:checked").each( function () {
    color.push($(this).val());
  });

  $("input[name='size[]']:checked").each( function () {
    size.push($(this).val());
    sizeStockData.push($("#sizeStock"+$(this).val()).val());
  });

  console.log(sizeStockData);

  if ($("#txtShortDescription").val().trim().length < 1) {
      snackbar_error("Please Enter Short Description");
      $("#txtShortDescription").focus();
      return false;
  }

  if ($("#txtLongDescription").val().trim().length < 1) {
      snackbar_error("Please Enter Long Description");
      $("#txtLongDescription").focus();
      return false;
  }

  if ($("#txtPrice").val().trim().length < 1) {
      snackbar_error("Please Enter Price");
      $("#txtPrice").focus();
      return false;
  }

  if ($("#txtStock").val().trim().length < 1) {
      snackbar_error("Please Enter Stock");
      $("#txtStock").focus();
      return false;
  }

    if ($("#txtDiscount").val().trim().length < 1) {
      snackbar_error("Please Enter Discount");
      $("#txtDiscount").focus();
      return false;
    }

    if ($("#txtBV").val().trim().length < 1) {
      snackbar_error("Please Enter BV");
      $("#txtBV").focus();
      return false;
    }

    // if ($("#txtPV").val().trim().length < 1) {
    //   snackbar_error("Please Enter PV");
    //   $("#txtPV").focus();
    //   return false;
    // }
    // return false;
  let lclImage = document.getElementById("txtImage");
  lclImage1 = lclImage.files[0];
  formData.append("phPhoto", lclImage1);
  
  formData.append("txtSubImageText1", $("#txtSubImageText1").val());
  formData.append("txtSubImageText2", $("#txtSubImageText2").val());
  formData.append("txtSubImageText3", $("#txtSubImageText3").val());
  formData.append("txtSubImageText4", $("#txtSubImageText4").val());

  formData.append("selCategory", $("#selCategory").val());
  formData.append("selSubCategory", $("#selSubCategory").val());
  formData.append("txtName", $("#txtName").val());
  formData.append("txtProductID", $("#txtProductID").val().trim());
  formData.append("color", color);
  formData.append("size", size);
  formData.append("sizeStock", sizeStockData);
  formData.append("txtShortDescription", $("#txtShortDescription").val());
  formData.append("txtLongDescription", $("#txtLongDescription").val());
  formData.append("txtPrice", $("#txtPrice").val());
  formData.append("txtQuantity", $("#txtQuantity").val());
  formData.append("txtStock", $("#txtStock").val());
  formData.append("txtDiscount", $("#txtDiscount").val());
  formData.append("txtDiscountPrice", $("#txtDiscountPrice").val());
  formData.append("txtBV", $("#txtBV").val());
  formData.append("txtPV", $("#txtPV").val());

  let adminLogin = localStorage.getItem("admin-login");
  formData.append("loggedInBy", adminLogin);
  
  formData.append("action", "add");

  let table = $("#tableData").DataTable();

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
      $("#btn_add").attr("disabled", true);
    },
    url: "backend/process_products.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (res) {

      if(res == "10") {
        snackbar_error("Product ID already present");
      } else {
        snackbar_success("Product Added Successfully");
        $('#myform')[0].reset();
        table.ajax.reload();
        location.reload();
        $("#add_modal").modal('hide');
      }
      
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
      $("#btn_add").attr("disabled", false);
    },
  });
});

// ADD Product data Table (DONE)
$(document).ready(function () {

  $.fn.dataTableExt.errMode = 'ignore';
  //show data
  let table = $("#tableData").DataTable({

    rowCallback: function( row, data, index ) {

      if ( data[10] == 1) {
          $('td', row).css('background-color', '#FCB0B0');
      } else {
          $('td', row).css('background-color', 'rgb(2 243 127 / 46%)');
      }
    },
    order: [[0, "desc"]],
    processing: true,
    serverSide: true,
    ajax: "backend/table_products.php",
    columnDefs: [
      {
        targets: -1,
        data: null,
        defaultContent:
          '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-pen"></i></a><a href="javascript:void(0);" title="Enable/Disable" data-toggle="modal" data-target="#delete_modal" class="text-danger" id="delete_row"> <i class="fa fa-ban"></i></a></div>',
      },
    ],
  });

  table.on( 'draw.dt', function () {
    $('#tableData').DataTable().page.info();
         table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
            cell.innerHTML = i + 1;
        });
    });

  //Edit Btn click
  $(document).on("click", "#edit_row", function () {

    let data = table.row($(this).parents("tr")).data();

    $("#selCategory1 option").filter(function() {
      return $(this).text() == data[1];
    }).prop("selected", true);

    $("#selSubCategory1 option").filter(function() {
      return $(this).text() == data[2];
    }).prop("selected", true);

    $("#txtName1").val(data[3]);
    $("#txtPrice1").val(data[5]);
    $("#txtStock1").val(data[6]);
    $("#txtDiscount1").val(data[7]);
    $("#txtBV1").val(data[8]);
    $("#txtPV1").val(data[9]);
    $("#edit_id").val(data[0]);

    // get color and size from master
    let formData = new FormData();
    formData.append("id", data[0]);
    formData.append("sub_category", data[2]);
    formData.append("action", "getColorSize");

    $.ajax({
      url: "backend/process_products.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {
        let jsonRes = JSON.parse(res);
        let color = jsonRes.product[0].pd_color.split(",");
        let saveSize = [];
        let sizeArray;
        for(let s = 0; s < jsonRes.productSize.length; s++) {
          saveSize.push(jsonRes.productSize[s].ps_sz_id);
        }
        saveSize = saveSize.toString();
        
        let size = saveSize.split(",");

        $("#txtShortDescription1").text(jsonRes.product[0].pd_short_desc);
        $("#txtLongDescription1").text(jsonRes.product[0].pd_long_desc);

        $("#imageURL1").val(jsonRes.product[0].pd_image);
        $("#txtProductID1").val(jsonRes.product[0].pd_product_id);
        $("#txtDiscountPrice1").val(jsonRes.product[0].pd_discount_price);

        if(jsonRes.product[0].pd_sub_image1 != "") {
          $("#txtSubImageText11").val(jsonRes.product[0].pd_sub_image1);
        } else {
          $("#txtSubImageText11").val("noImage1");
        }

        if(jsonRes.product[0].pd_sub_image2 != "") {
          $("#txtSubImageText22").val(jsonRes.product[0].pd_sub_image2);
        } else {
          $("#txtSubImageText22").val("noImage1");
        }

        if(jsonRes.product[0].pd_sub_image3 != "") {
          $("#txtSubImageText33").val(jsonRes.product[0].pd_sub_image3);
        } else {
          $("#txtSubImageText33").val("noImage1");
        }

        if(jsonRes.product[0].pd_sub_image4 != "") {
          $("#txtSubImageText44").val(jsonRes.product[0].pd_sub_image4);
        } else {
          $("#txtSubImageText44").val("noImage1");
        }

        $("#color1").empty();
        $("#size1").empty();
        for(let i = 0; i < jsonRes.color.length; i++) {
          if(color.includes(jsonRes.color[i].co_id)) {
            $("#color1").append('<table><tr><td style="width: 100px;"> '+jsonRes.color[i].co_name+' </td><td style="width: 100px;"><input type="checkbox" value="'+jsonRes.color[i].co_id+'" name="color1[]" checked></td></tr></table>');
          } else {
            $("#color1").append('<table><tr><td style="width: 100px;"> '+jsonRes.color[i].co_name+' </td><td style="width: 100px;"><input type="checkbox" value="'+jsonRes.color[i].co_id+'" name="color1[]"></td></tr></table>');
          }
        }

        for(let i = 0; i < jsonRes.size.length; i++) {
          if(size.includes(jsonRes.size[i].sz_id)) {
            $("#size1").append('<table><tr><td style="width: 100px;"> '+jsonRes.size[i].sz_name+' </td><td style="width: 100px;"><input type="checkbox" value="'+jsonRes.productSize[i].sz_id+'" name="size1[]" checked></td><td><input type="text" id="sizeStock1'+jsonRes.productSize[i].sz_id+'" style="border: 1px solid black !important;" value="'+jsonRes.productSize[i].ps_stock+'"></td></tr></table>');
          } else {
            $("#size1").append('<table><tr><td style="width: 100px;"> '+jsonRes.size[i].sz_name+' </td><td style="width: 100px;"><input type="checkbox" value="'+jsonRes.size[i].sz_id+'" name="size1[]"></td><td><input type="text" id="sizeStock1'+jsonRes.size[i].sz_id+'" style="border: 1px solid black !important;"></td></tr></table>');
          }
        }
      }
    });

  });

  $(document).on("click", "#delete_row", function () {

    let data = table.row($(this).parents("tr")).data();
    $("#delete_id").val(data[0]);

  });

  //Edit modal submit click
  $(document).on("click", "#btn_update", function () {

    let formData = new FormData();

    if($("#txtImage1").val() != "") {
      let lclImage = document.getElementById("txtImage1");
      lclImage1 = lclImage.files[0];
      formData.append("phPhoto1", lclImage1);
      $("#imageURL1").val("");
    }

    if ($("#selCategory1").val().trim().length < 1) {
      snackbar_error("Please Select Category");
      $("#selCategory1").focus();
      return false;
    }

    if ($("#selSubCategory1").val().trim().length < 1) {
      snackbar_error("Please Select Sub Category");
      $("#selSubCategory1").focus();
      return false;
    }

    if($("#txtSubImage11").val() != "") {
      let lclSubImage1 = document.getElementById("txtSubImage11");
      lclSubImage1 = lclSubImage1.files[0];
      formData.append("subImage11", lclSubImage1);
      $("#txtSubImageText11").val("");
    }
  
    if($("#txtSubImage22").val() != "") {
      let lclSubImage2 = document.getElementById("txtSubImage22");
      lclSubImage2 = lclSubImage2.files[0];
      formData.append("subImage22", lclSubImage2);
      $("#txtSubImageText22").val("");
    }
  
    if($("#txtSubImage33").val() != "") {
      let lclSubImage3 = document.getElementById("txtSubImage33");
      lclSubImage3 = lclSubImage3.files[0];
      formData.append("subImage33", lclSubImage3);
      $("#txtSubImageText33").val("");
    }
  
    if($("#txtSubImage44").val() != "") {
      let lclSubImage4 = document.getElementById("txtSubImage44");
      lclSubImage4 = lclSubImage4.files[0];
      formData.append("subImage44", lclSubImage4);
      $("#txtSubImageText44").val("");
    }
    
    if ($("#txtName1").val().trim().length < 1) {
      snackbar_error("Please Enter Product Name");
      $("#txtName1").focus();
      return false;
    }

    const color = [];
    const size = [];
    const sizeStockData = [];

    $("input[name='color1[]']:checked").each( function () {
      color.push($(this).val());
    });

    $("input[name='size1[]']:checked").each( function () {
      size.push($(this).val());
      sizeStockData.push($("#sizeStock1"+$(this).val()).val());
    });

    console.log(sizeStockData);

    // return false;

    // if(!color.length) {
    //   snackbar_error("Please Select atleast 1 color");
    //   return false;
    // }

    // if(!size.length) {
    //   snackbar_error("Please Select atleast 1 size");
    //   return false;
    // }

    if ($("#txtShortDescription1").val().trim().length < 1) {
        snackbar_error("Please Enter Short Description");
        $("#txtShortDescription1").focus();
        return false;
    }

    if ($("#txtLongDescription1").val().trim().length < 1) {
        snackbar_error("Please Enter Long Description");
        $("#txtLongDescription1").focus();
        return false;
    }

    if ($("#txtPrice1").val().trim().length < 1) {
        snackbar_error("Please Enter Price");
        $("#txtPrice1").focus();
        return false;
    }

    if ($("#txtStock1").val().trim().length < 1) {
        snackbar_error("Please Enter Stock");
        $("#txtStock1").focus();
        return false;
    }

    if ($("#txtDiscount1").val().trim().length < 1) {
        snackbar_error("Please Enter Discount");
        $("#txtDiscount1").focus();
        return false;
    }

    if ($("#txtBV1").val().trim().length < 1) {
      snackbar_error("Please Enter BV");
      $("#txtBV1").focus();
      return false;
    }

    // if ($("#txtPV1").val().trim().length < 1) {
    //   snackbar_error("Please Enter PV");
    //   $("#txtPV1").focus();
    //   return false;
    // }

    
    formData.append("imageURL1", $("#imageURL1").val());

    formData.append("txtSubImageText11", $("#txtSubImageText11").val());
    formData.append("txtSubImageText22", $("#txtSubImageText22").val());
    formData.append("txtSubImageText33", $("#txtSubImageText33").val());
    formData.append("txtSubImageText44", $("#txtSubImageText44").val());

    formData.append("selCategory1", $("#selCategory1").val());
    formData.append("selSubCategory1", $("#selSubCategory1").val());
    formData.append("txtName1", $("#txtName1").val());
    formData.append("txtProductID1", $("#txtProductID1").val().trim());
    formData.append("color", color);
    formData.append("size", size);
    formData.append("sizeStock", sizeStockData);
    formData.append("txtShortDescription1", $("#txtShortDescription1").val());
    formData.append("txtLongDescription1", $("#txtLongDescription1").val());
    formData.append("txtPrice1", $("#txtPrice1").val());
    formData.append("txtQuantity1", $("#txtQuantity1").val());
    formData.append("txtStock1", $("#txtStock1").val());
    formData.append("txtDiscount1", $("#txtDiscount1").val());
    formData.append("txtDiscountPrice1", $("#txtDiscountPrice1").val());
    formData.append("txtBV1", $("#txtBV1").val());
    formData.append("txtPV1", $("#txtPV1").val());

    formData.append("action", "update");
    formData.append("id", $("#edit_id").val());

    let table = $("#tableData").DataTable();

    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_update").attr("disabled", true);
      },
      url: "backend/process_products.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {
        snackbar_success("Product Updated Succesfully");
        location.reload();
        table.ajax.reload();
        $("#edit_modal").modal('hide');
      },
      error: function (error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_update").attr("disabled", false);
      },
    });
  });

  //Delete work step
  $(document).on("click", "#btn_enable", function () {

    let formData = new FormData();
    formData.append("action", "enable");
    formData.append("id", $("#delete_id").val());

    let table = $("#tableData").DataTable();

    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
      },

      url: "backend/process_products.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function () {
        snackbar_success("Product Enabled succesfully");
        table.ajax.reload();
        $("#delete_modal").modal('hide');
      },
      error: function (error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $(".close").click();
      },
    });
  });

  $(document).on("click", "#btn_disable", function () {

    let formData = new FormData();
    formData.append("action", "disable");
    formData.append("id", $("#delete_id").val());

    let table = $("#tableData").DataTable();

    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
      },

      url: "backend/process_products.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function () {
        snackbar_success("Product disabled succesfully");
        table.ajax.reload();
        $("#delete_modal").modal('hide');
      },
      error: function (error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $(".close").click();
      },
    });
  });
});


$("#selCategory").change(function() {
  let formData = new FormData();
  formData.append("action", "getSubCategory");
  formData.append("selCategory", $("#selCategory").val());

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
    },

    url: "backend/process_products.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      
      let jsonRes = JSON.parse(response);

      $("#selSubCategory").empty('');
      $("#selSubCategory").append('<option value="">Please select sub category</option>');
      for(let i = 0; i < jsonRes.length; i++) {
        $("#selSubCategory").append('<option value="'+jsonRes[i].sub_id+'">'+jsonRes[i].sub_category_name+'</option>');        
      }
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
    },
  });
});

$("#selSubCategory").change(function() {
  let formData = new FormData();
  formData.append("action", "get_size_sub_category");
  formData.append("selSubCategory", $("#selSubCategory").val());

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
    },

    url: "backend/process_products.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      
      let jsonRes = JSON.parse(response);

      $("#size").empty();
      for(let i = 0; i < jsonRes.size.length; i++) {
        $("#size").append('<tr><td> '+jsonRes.size[i].sz_name+' </td><td style="width: 100px;"><input type="checkbox" value="'+jsonRes.size[i].sz_id+'" name="size[]"></td><td><input type="text" id="sizeStock'+jsonRes.size[i].sz_id+'" style="border: 1px solid black !important;"></td></tr>');
      }
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
    },
  });
});

$("#selCategory1").change(function(){
  let formData = new FormData();
  formData.append("action", "getSubCategory");
  formData.append("selCategory", $("#selCategory1").val());

  $.ajax({
    beforeSend: function () {
      $(".btn .spinner-border").show();
    },

    url: "backend/process_products.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      
      let jsonRes = JSON.parse(response);

      $("#selSubCategory1").empty('');
      $("#selSubCategory1").append('<option value="">Please select sub category</option>');
      for(let i = 0; i < jsonRes.length; i++) {
        $("#selSubCategory1").append('<option value="'+jsonRes[i].sub_id+'">'+jsonRes[i].sub_category_name+'</option>');        
      }
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $(".btn .spinner-border").hide();
    },
  });
});

$("#newAdd").click(function() {
    $("#txtSubImageText1").val('noSubImage1');
    $("#txtSubImageText2").val('noSubImage1');
    $("#txtSubImageText3").val('noSubImage1');
    $("#txtSubImageText4").val('noSubImage1');
});

$("#txtDiscount").keyup(function() {
  if($("#txtPrice").val() == "") {
    snackbar_error("Please enter price");
    $("#txtDiscount").val('');
  } else {
    let newPrice = Number(($("#txtDiscount").val()*$("#txtPrice").val())/100);
    let discountPrice = Number($("#txtPrice").val()) - newPrice;
    $("#txtDiscountPrice").val(discountPrice.toFixed(2));
  }
});

$("#txtPrice").keyup(function() {
  $("#txtDiscount").val('');
  $("#txtDiscountPrice").val('');
});

// on update
$("#txtDiscount1").keyup(function() {
  if($("#txtPrice1").val() == "") {
    snackbar_error("Please enter price");
    $("#txtDiscount1").val('');
  } else {
    let newPrice = Number(($("#txtDiscount1").val()*$("#txtPrice1").val())/100);
    let discountPrice = Number($("#txtPrice1").val()) - newPrice;
    $("#txtDiscountPrice1").val(discountPrice.toFixed(2));
  }
});

$("#txtPrice1").keyup(function() {
  $("#txtDiscount1").val('');
  $("#txtDiscountPrice1").val('');
});
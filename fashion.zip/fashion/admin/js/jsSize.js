

$("#btn_add").click(function (e) {
    //verification
    if ($("#txtName").val().trim().length < 1) {
      snackbar_error("Please Enter Size");
      $("#txtName").focus();
      return false;
    }

    if ($("#txtSequence").val().trim().length < 1) {
      snackbar_error("Please Enter Sequence");
      $("#txtSequence").focus();
      return false;
    }
  
    //append data
    let formData = new FormData();
    formData.append("txtName", $("#txtName").val());
    formData.append("txtSequence", $("#txtSequence").val());

    let adminLogin = localStorage.getItem("admin-login");
    formData.append("loggedInBy", adminLogin);
    formData.append("action", "add");
  
    let table = $("#tableData").DataTable();
  
    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_add").attr("disabled", true);
      },
      url: "backend/process_size.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {
         if(res.trim() == "10") {
          snackbar_error("Size already Exist, Please Check and Add");
        } else {
          snackbar_success("Size Added Successfully");
          // location.reload();
          $('#myform')[0].reset();
          table.ajax.reload();
          $("#add_modal").modal('hide');
        }
      },
      error: function (error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_add").attr("disabled", false);
      },
    });
  });
  
  
  $(document).ready(function () {
  
    //show data
    let table = $("#tableData").DataTable({
      order: [[0, "desc"]],
      processing: true,
      serverSide: true,
      ajax: "backend/table_size.php",
      columnDefs: [
        {
          targets: [-1],
          data: null,
          defaultContent:
            '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-pen"></i></a><a href="javascript:void(0);" title="Delete" data-toggle="modal" data-target="#delete_modal" class="text-danger" id="delete_row"> <i class="far fa-trash-alt"></i></a></div>',
        },
      ],
    });
  
    table.on( 'draw.dt', function () {
      $('#tableData').DataTable().page.info();
           table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
              cell.innerHTML = i + 1;
          });
      });
  
    //Edit Btn click
    $(document).on("click", "#edit_row", function () {
  
      let data = table.row($(this).parents("tr")).data();
      $("#txtName1").val(data[1]);
      $("#txtSequence1").val(data[2]);
      $("#edit_id").val(data[0]);
      setTimeout(function (){
        $('#txtName1').focus();
      }, 1000);
  
    });
  
    $(document).on("click", "#delete_row", function () {
      let data = table.row($(this).parents("tr")).data();
      $("#delete_id").val(data[0]);
  
    });
  
    //Edit modal submit click
    $(document).on("click", "#btn_update", function () {
  
      if ($("#txtName1").val().trim().length < 1) {
        snackbar_error("Please Enter Size");
        $("#txtName1").focus();
        return false;
      }

      if ($("#txtSequence1").val().trim().length < 1) {
        snackbar_error("Please Enter Sequence");
        $("#txtSequence1").focus();
        return false;
      }
      
      let formData = new FormData()
      formData.append("txtName1", $("#txtName1").val());
      formData.append("txtSequence1", $("#txtSequence1").val());
      formData.append("action", "update");
      formData.append("id", $("#edit_id").val());
  
      let table = $("#tableData").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update").attr("disabled", true);
        },
        url: "backend/process_size.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
            if(result.trim() == "10") {
              snackbar_error("Size already Exist, Please Check and Add");
            } else {
              snackbar_success("Size Updated Successfully");
              table.ajax.reload();
              $("#edit_modal").modal('hide');
            }
        },
        error: function (error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update").attr("disabled", false);
        },
      });
    });
  
    //Delete work step
    $(document).on("click", "#btn_delete", function () {
  
      let formData = new FormData();
      formData.append("action", "delete");
      formData.append("id", $("#delete_id").val());
  
      let table = $("#tableData").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
        },
  
        url: "backend/process_size.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
          snackbar_success("Size deleted succesfully");
          // location.reload();
          table.ajax.reload();
          $("#delete_modal").modal('hide');
        },
        error: function (error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $(".close").click();
        },
      });
    });
  });
  

  $("#addNew").click(function() {
    setTimeout(function (){
      $('#txtName').focus();
    }, 500);
  });
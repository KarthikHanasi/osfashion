

$("#btn_add").click(function (e) {
    //verification
    if ($("#txtCategoryName").val().trim().length < 1) {
      snackbar_error("Please Select Category Name");
      $("#txtCategoryName").focus();
      return false;
    }

    if ($("#txtSubCategoryName").val().trim().length < 1) {
        snackbar_error("Please Select Sub Category Name");
        $("#txtSubCategoryName").focus();
        return false;
    }

    const size = [];

    $("input[name='size[]']:checked").each( function () {
      size.push($(this).val());
    });
  
    //append data
    let formData = new FormData();
    formData.append("txtCategoryName", $("#txtCategoryName").val());
    formData.append("txtSubCategoryName", $("#txtSubCategoryName").val());
    formData.append("size", size);

    let adminLogin = localStorage.getItem("admin-login");
    formData.append("loggedInBy", adminLogin);
    
    formData.append("action", "add");
  
    let table = $("#tableData").DataTable();
  
    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_add").attr("disabled", true);
      },
      url: "backend/process_sub_categories.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (result) {
         if(result.trim() == "10") {
          snackbar_error("Sub Category already Exist, Please Check and Add");
        } else {
          snackbar_success("Sub Category Added Successfully");
          // location.reload();
          $('#myform')[0].reset();
          table.ajax.reload();
          $("#add_modal").modal('hide');
        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_add").attr("disabled", false);
      },
    });
  });
  
  // ADD Testimnials data Table (DONE)
  $(document).ready(function () {
  
    //show data
    let table = $("#tableData").DataTable({
      order: [[0, "desc"]],
      processing: true,
      serverSide: true,
      ajax: "backend/table_sub_categories.php",
      columnDefs: [
        {
          targets: -1,
          data: null,
          defaultContent:
            '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-pen"></i></a><a href="javascript:void(0);" title="Delete" data-toggle="modal" data-target="#delete_modal" class="text-danger" id="delete_row"> <i class="far fa-trash-alt"></i></a></div>',
        },
      ],
    });
  
    table.on( 'draw.dt', function () {
      $('#tableData').DataTable().page.info();
           table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
              cell.innerHTML = i + 1;
          });
      });
  
    //Edit Btn click
    $(document).on("click", "#edit_row", function () {
  
      let data = table.row($(this).parents("tr")).data();
      $("#txtCategoryName1 option").filter(function() {
        return $(this).text() == data[1];
      }).prop("selected", true);
      $("#txtSubCategoryName1").val(data[2]);
      $("#edit_id").val(data[0]);

      let formData = new FormData();
      formData.append("id", data[0]);
      formData.append("action", "getSize");

      $.ajax({
        url: "backend/process_sub_categories.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
          let jsonRes = JSON.parse(res);
          let size = "";
          if(jsonRes.sub_category[0].sub_size_id) {
            size = jsonRes.sub_category[0].sub_size_id.split(",");
          } else {
            size = [];
          }
          
        
          $("#size").empty();

          for(let i = 0; i < jsonRes.size.length; i++) {
            if(size.includes(jsonRes.size[i].sz_id)) {
              $("#size").append('<td style="width: 100px;"> '+jsonRes.size[i].sz_name+' </td><td style="width: 100px;"><input type="checkbox" value="'+jsonRes.size[i].sz_id+'" name="size1[]" checked></td>');
            } else {
              $("#size").append('<td style="width: 100px;"> '+jsonRes.size[i].sz_name+' </td><td style="width: 100px;"><input type="checkbox" value="'+jsonRes.size[i].sz_id+'" name="size1[]"></td>');
            }
          }
        }
      });
  
    });
  
    $(document).on("click", "#delete_row", function () {
  
      let data = table.row($(this).parents("tr")).data();
      $("#delete_id").val(data[0]);
  
    });
  
    //Edit modal submit click
    $(document).on("click", "#btn_update", function () {
  
    if ($("#txtCategoryName1").val().trim().length < 1) {
        snackbar_error("Please Select Category Name");
        $("#txtCategoryName1").focus();
        return false;
    }
      
    if ($("#txtSubCategoryName1").val().trim().length < 1) {
        snackbar_error("Please Select Sub Category Name");
        $("#txtSubCategoryName1").focus();
        return false;
    }

    const size = [];

    $("input[name='size1[]']:checked").each( function () {
      size.push($(this).val());
    });
      
      let formData = new FormData();
      formData.append("txtCategoryName1", $("#txtCategoryName1").val());
      formData.append("txtSubCategoryName1", $("#txtSubCategoryName1").val());
      formData.append("size1", size);
      formData.append("action", "update");
      formData.append("id", $("#edit_id").val());
  
      let table = $("#tableData").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update").attr("disabled", true);
        },
        url: "backend/process_sub_categories.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
         if(result.trim() == "10") {
          snackbar_error("Sub Category already Exist, Please Check and Add");
        } else {
          snackbar_success("Sub Category Updated Successfully");
          // location.reload();
          table.ajax.reload();
          $("#edit_modal").modal('hide');
        }
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update").attr("disabled", false);
        },
      });
    });
  
    //Delete work step
    $(document).on("click", "#btn_delete", function () {
  
      let formData = new FormData();
      formData.append("action", "delete");
      formData.append("id", $("#delete_id").val());
  
      let table = $("#tableData").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
        },
  
        url: "backend/process_sub_categories.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
          snackbar_success("Sub Category deleted succesfully");
          // location.reload();
          table.ajax.reload();
          $("#delete_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $(".close").click();
        },
      });
    });
  });
  
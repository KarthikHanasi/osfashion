
// ADD Testimnials data Table (DONE)
$(document).ready(function () {

    $.fn.dataTableExt.errMode = 'ignore';
    //show data
    let table = $("#tableData").DataTable({
  
      rowCallback: function( row, data ) {
  
        if ( data[6] == "N") {
            $('td', row).css('background-color', '#FCB0B0');  
        } else {
            $('td', row).css('background-color', 'rgb(2 243 127 / 46%)');
        }
      },
      order: [[8, "desc"]],
      processing: true,
      serverSide: true,
      ajax: "backend/table_users.php",
      columnDefs: [
        {
          targets: -1,
          data: null,
          defaultContent:
          '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="wallet_row" title="Update Wallet" data-toggle="modal" data-target="#wallet_modal" class="text-primary"> <i class="fas fa-pen"></i></a><a href="javascript:void(0);" id="user_history" title="User History" data-toggle="modal" data-target="#history" class="text-primary"> <i class="fas fa-history"></i></a><a href="javascript:void(0);" id="edit_row" title="View" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-eye"></i></a></div>',
        },
      ],
    });
  
    table.on( 'draw.dt', function () {
      $('#tableData').DataTable().page.info();
           table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
              cell.innerHTML = i + 1;
          });
      });
  
    //Edit Btn click
    $(document).on("click", "#edit_row", function () {
  
      let data = table.row($(this).parents("tr")).data();
      let formData = new FormData();
  
      $("#edit_id").val(data[0]);
      $("#txtName1").val(data[1]);
      $("#txtMobileNo1").val(data[2]);
      $("#txtEmail1").val(data[3]);
      $("#txtReferral1").val(data[5]);
      $("#txtWallet1").val(data[7]);
      
      formData.append("main_id", data[0]);
      formData.append("action", "get_user_heirarchy_details");
  
      $.ajax({
        beforeSend: function () {
        },
        url: "backend/process_users.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
          let lclJSON = JSON.parse(response);
          const data = {"items": lclJSON}

          const buildTree = (main_id) => (item) => {
            const children = data.items.filter((child) => child.main_id === item.employee_id);
            return {
              ...item,
              ...(children.length > 0 && { children: children.map(buildTree(item.employee_id)) }),
            };
          };
          
          const nestedData = {
            items: data.items.filter((item) => !item.main_id).map(buildTree(undefined)),
          };

          const {items} = nestedData 
          const [data1] = items;
          // console.log(data1)

          $(function() {
    
            $.mockjax({
            url: '/orgchart/initdata',
            responseTime: 1000,
            contentType: 'application/json',
            responseText: data1
            });
    
            $('#chart-container').orgchart({
            'data' : '/orgchart/initdata',
            'nodeContent': 'title'
            });
    
        });

        },
        error: function (error) {
          console.error(error);
        },
        complete: function () {
  
        },
      });
      
    });

    $(document).on("click", "#wallet_row", function () {
      let data = table.row($(this).parents("tr")).data();
      $("#txtName2").val(data[1]);
      $("#txtWallet2").val(data[7]);
      $("#txtWalletOriginal").val(data[7]);
      $("#wallet_id").val(data[0]);
      setTimeout(function () {
        $('#selType').focus();
      }, 1000);
  
    });

    $(document).on("click", "#btn_update_wallet", function () {
  
      let formData = new FormData();
  
      if ($("#selType").val().trim().length < 1) {
        snackbar_error("Please Select Type");
        $("#selType").focus();
        return false;
      }
      
      if ($("#txtAmount2").val().trim().length < 1) {
        snackbar_error("Please Enter Amount");
        $("#txtAmount2").focus();
        return false;
      }

      if ($("#txtAmount2").val() <= 0) {
        snackbar_error("Please Enter Amount greater than 0");
        $("#txtAmount2").focus();
        return false;
      }

      formData.append("selType", $("#selType").val());
      formData.append("txtWalletOriginal", $("#txtWalletOriginal").val());
      formData.append("txtAmount2", $("#txtAmount2").val());
      formData.append("action", "update_wallet");
      formData.append("id", $("#wallet_id").val());
      let adminLogin = localStorage.getItem("admin-login");
      formData.append("loggedInBy", adminLogin);
  
      let table = $("#tableData").DataTable();
      
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update_wallet").attr("disabled", true);
        },
        url: "backend/process_users.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
          snackbar_success("Wallet Updated Successfully");
          table.ajax.reload();
          $('#myform')[0].reset();
          $("#wallet_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update_wallet").attr("disabled", false);
        },
      });
    });

    $(document).on("click", "#user_history", function () {
      let table = $("#tableData").DataTable();
      let data = table.row($(this).parents("tr")).data();
      let formData = new FormData();
      formData.append("action", "user_history");
      formData.append("user_id", data[0]);
      $("#divProfile").html('');
      $("#divOrders").html('');
      $("#chart-container1").empty();
      $("#divCreditsTable").html('');
      $("#withdrawalsDetails").html('');
      $("#memberDetails").html('');
      
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update_wallet").attr("disabled", true);
        },
        url: "backend/process_users.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
          let lclJSON = JSON.parse(res);
          let email = lclJSON.profiles[0].us_email == null ? "" : lclJSON.profiles[0].us_email;
          let occupation = lclJSON.profiles[0].us_designation == null ? "" : lclJSON.profiles[0].us_designation;
          let dob = lclJSON.profiles[0].us_dob == '0000-00-00' ? "" : lclJSON.profiles[0].us_dob;
          let blood_group = lclJSON.profiles[0].us_blood_group == null ? "" : lclJSON.profiles[0].us_blood_group;
          let refBy = "";

          if(lclJSON.details2.length) {
            refBy = lclJSON.details2[0].us_name == undefined ? "" : lclJSON.details2[0].us_name;
          }

          $("#divProfile").html(`<div style="width: 100%;"><h3>Profile</h3> </div> <table class="table"><tr><td>Name : </td><td><b>${lclJSON.profiles[0].us_name}</b></td></tr> <tr><td> Mobile Number : </td><td><b>${lclJSON.profiles[0].us_mobile}</b></td></tr> <tr><td> Email : </td><td><b>${email}</b></td></tr> <tr><td> Referral Code : </td><td><b>${lclJSON.profiles[0].us_referral_code}</b></td></tr>   <tr><td>Referred By</td> <td><b>${refBy} </td></tr> <tr><td>Level</td><td><b>${lclJSON.profiles[0].us_level}</b></td></tr> <tr><td>Wallet</td><td><b>${lclJSON.profiles[0].us_wallet}</td> <tr><td>Occupation</td><td>${occupation}</b></td></tr>  <tr><td>Date of Birth</td><td>${dob}</td> <tr><td>Blood Group</td><td>${blood_group}</b></td>  <tr><td>BV</td><td><b>${lclJSON.profiles[0].us_bv}</b></td> <tr><td>Rank</td><td><b>${lclJSON.profiles[0].us_rank}</b></td> </tr> <tr><td>Total Coins</td><td><b>${lclJSON.profiles[0].us_coins}</td> <tr><td>Total Coins Used</td><td><b>${lclJSON.profiles[0].us_coins_usage}</b></td></tr></table>`);

          for(let i = 0; i < lclJSON.orders.length; i++) {

            let lclAddress = `${lclJSON.orders[i].ads_address}  ${lclJSON.orders[i].ads_city} ${lclJSON.orders[i].st_name} ${lclJSON.orders[i].ads_pincode}`;

            $("#divOrdersTable").append(`<tr><th>Slno</th><th>Order ID</th><th>Name</th><th>Mobile Number</th><th>Amount</th><th>Address</th><th></th></tr>`);
            $("#divOrdersTable").append(`<tr><td>${i+1}</td><td>${lclJSON.orders[i].or_readable_id}</td><td>${lclJSON.orders[i].or_name}</td><td>${lclJSON.orders[i].or_mobile}</td><td>${lclJSON.orders[i].or_total_amount}</td><td>${lclAddress}</td><td></td></tr>`);

            let totalPrice = Number(lclJSON.orders[i].pp_pd_price) * Number(lclJSON.orders[i].pp_qty);

            if(lclJSON.orders[i].pd_image.includes('s3')) {
              img = lclJSON.orders[i].pd_image;
            } else {
              img = '"../'+lclJSON.orders[i].pd_image+'"';
            }

            $("#divOrdersTable").append(`<tr><th>Image</th><th>Name</th><th>Size</th><th>Color</th><th>Price</th><th>QTY</th><th>Total</th></tr>`);
            $("#divOrdersTable").append(`<tr><td><img src="${img}" height='75'></td><td>${lclJSON.orders[i].pd_name}</td><td>${lclJSON.orders[i].sz_name}</td><td>${lclJSON.orders[i].co_name}</td><td>${lclJSON.orders[i].pp_pd_price}</td><td>${lclJSON.orders[i].pp_qty}</td><td>${totalPrice}</td><td></td></tr>`);

            $("#divOrdersTable").append('<tr style="background: white;"><td style="height: 50px;"></td><td></td><td></td><td></td><td></td><td></td></tr>');
          }

            // network
            const data = {"items": lclJSON.network}

            const buildTree = (main_id) => (item) => {
              const children = data.items.filter((child) => child.main_id === item.employee_id);
              return {
                ...item,
                ...(children.length > 0 && { children: children.map(buildTree(item.employee_id)) }),
              };
            };
            
            const nestedData = {
              items: data.items.filter((item) => !item.main_id).map(buildTree(undefined)),
            };

            const {items} = nestedData 
            const [data1] = items;

            $(function() {
      
              $.mockjax({
              url: '/orgchart/initdata',
              responseTime: 1000,
              contentType: 'application/json',
              responseText: data1
              });
      
              $('#chart-container1').orgchart({
              'data' : '/orgchart/initdata',
              'nodeContent': 'title'
              });
      
          });

          for(let i = 0; i < lclJSON.credits.length; i++) {

            let lclDate = (lclJSON.credits[i].ach_created_date).substring(0,10);
            let lclLevel = (lclJSON.credits[i].ach_level == 0) ? "R" : lclJSON.credits[i].ach_level;
            
            $("#divCreditsTable").append('<tr><td class="order-title first-row">'+lclJSON.credits[i].us_name+' ('+lclJSON.credits[i].us_rank+')</td><td class="order-title first-row">'+lclJSON.credits[i].ach_amount+'</td><td class="order-title first-row">'+lclJSON.credits[i].ach_bv+'</td><td class="order-title first-row">'+lclJSON.credits[i].ach_percentage+'</td><td class="order-title first-row">'+lclLevel+'</td><td class="order-title first-row"><h5 style="width: 120px; font-size: 14px;">'+formatDate(lclDate)+'</h5></td></tr>');
          }

          if(lclJSON.kyc.length) {
            // kyc details
            let [kycDetails] = lclJSON.kyc;
            const aadharFile = kycDetails.aadhar_file || "#";
            const panFile = kycDetails.pan_file || "#";
            const bankFile = kycDetails.bank_file || "#";
            const aadharNumber = kycDetails.aadhar_number || "-";
            const accountName = kycDetails.bank_user_name || "-";
            const accountNumber = kycDetails.bank_number || "-";
            const bankName = kycDetails.bank_name || "-";
            const ifscCode = kycDetails.bank_ifsc_code || "-";
            const panNumber = kycDetails.pan_number || "-";

            $("#aadharStatus").text(kycDetails.aadhar_status);
            $("#panStatus").text(kycDetails.pan_status);
            $("#bankStatus").text(kycDetails.bank_status);

            $("#aadharFile").attr("href", aadharFile);
            $("#panFile").attr("href", panFile);
            $("#bankFile").attr("href", bankFile);
            $("#aadharNumber").text(aadharNumber);
            $("#panNumber").text(panNumber);
            $("#accountName").text(accountName);
            $("#accountNumber").text(accountNumber);
            $("#bankName").text(bankName);
            $("#ifscCode").text(ifscCode);
          }

          // with drawals
          if(lclJSON.withdrawalsDetails.length) {
            for(let i = 0; i < lclJSON.withdrawalsDetails.length; i++) {
              j = i + 1;
              $("#withdrawalsDetails").append("<tr><td>"+j+"</td><td>"+lclJSON.withdrawalsDetails[i].us_name+"</td><td>"+lclJSON.withdrawalsDetails[i].us_mobile+"</td><td>"+lclJSON.withdrawalsDetails[i].wt_amount+"</td><td style='width: 100px'>"+formatDate(lclJSON.withdrawalsDetails[i].wt_payment_date)+"</td><td>"+lclJSON.withdrawalsDetails[i].wt_transaction_id+"</td><td>"+lclJSON.withdrawalsDetails[i].bank_user_name+"</td><td>"+lclJSON.withdrawalsDetails[i].bank_number+"</td></tr>");
  
            }
          } else {
            $("#withdrawalsDetails").append("<tr><td>No Records Found ...</td></tr>");
          }

          if(lclJSON.memberDetails.length) {
            for(let i = 0; i < lclJSON.memberDetails.length; i++) {
              $("#memberDetails").append("<tr><td>Yes</td><td>"+lclJSON.memberDetails[0].pl_name+"</td><td>"+lclJSON.memberDetails[0].pl_amount+"</td></tr>");
            }
          } else {
            $("#memberDetails").append("<tr><td>Not a Member ...</td></tr>");
          }

          if(lclJSON.walletHistory.length) {
            for(let i = 0; i < lclJSON.walletHistory.length; i++) {
              $("#walletHistory").append("<tr><td>"+(i+1)+"</td><td>"+lclJSON.walletHistory[i].us_name+"</td><td>"+lclJSON.walletHistory[i].uwt_type+"</td><td>"+lclJSON.walletHistory[i].uwt_prev_wallet+"</td><td>"+lclJSON.walletHistory[i].uwt_amount+"</td><td>"+lclJSON.walletHistory[i].uwt_new_wallet+"</td><td>"+lclJSON.walletHistory[i].uwt_updated_by+"</td><td>"+lclJSON.walletHistory[i].uwt_created_date+"</td></tr>");
            }
          } else {
            $("#walletHistory").append("<tr><td>No Results Found ...</td></tr>");
          }
          
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update_wallet").attr("disabled", false);
        },
      });
    });
  });

  function formatDate (input) {
    let datePart = input.match(/\d+/g),
    year = datePart[0].substring(), // get only two digits
    month = datePart[1], day = datePart[2];

    return `${day}-${month}-${year}`;
  }

  function myfun(refId) {
    let formData = new FormData();
    formData.append("refId", refId);
    formData.append("action", "get_mynetwork_refid");
  
    $.ajax({
      url: "backend/process_users.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        let lclJSON = JSON.parse(response);
        let res = "";
        let email = lclJSON.details[0].us_email;
        if (email) {
          res = email;
        }
  
        $("#mlmDetails").html(
          '<div class="container"><div class="row"><div class="photo"><div class="col-"><img class="profile rounded" src="../img/myprofile.png" alt="profile"><div class="mt-2"><span class="in" for=""><b>'+
          lclJSON.details[0].us_rank +'</b></div></div></div><div class="col"><span class="info"><b>Name : </b>' +lclJSON.details[0].us_name +'</span><br><span class="info"><b>Age : </b>22</span><br><span class="info"><b>Ref Code : </b>' + lclJSON.details[0].us_referral_code +'</span><br><span class="info"><b>Ref By : </b>' + lclJSON.details2[0].us_name +'</span><br><span class="info"><b>Gender : </b></span><br><span class="info" ><b>Email : </b>' + res +
            "</span><br/><span class='info'><b>Mobile  :  </b> "+lclJSON.details[0].us_mobile+"</span></div></div></div>"
        );
      },
    });
    $("#exampleModal").modal("show");
  }

  $("#userProfile").click(function() {
    $(".profile").show();
    $(".orders").hide();
    $(".network").hide();
    $(".credits").hide();
    $(".kyc").hide();
    $(".withdrawals").hide();
    $(".members").hide();
    $(".wallet_history").hide();
  });

  $("#userOrder").click(function() {
    $(".profile").hide();
    $(".orders").show();
    $(".network").hide();
    $(".credits").hide();
    $(".kyc").hide();
    $(".withdrawals").hide();
    $(".members").hide();
    $(".wallet_history").hide();
  });

  $("#userNetwork").click(function() {
    $(".profile").hide();
    $(".orders").hide();
    $(".network").show();
    $(".credits").hide();
    $(".kyc").hide();
    $(".withdrawals").hide();
    $(".members").hide();
    $(".wallet_history").hide();
  });

  $("#userCredit").click(function() {
    $(".profile").hide();
    $(".orders").hide();
    $(".network").hide();
    $(".credits").show();
    $(".kyc").hide();
    $(".withdrawals").hide();
    $(".members").hide();
    $(".wallet_history").hide();
  });

  $("#userKYC").click(function() {
    $(".profile").hide();
    $(".orders").hide();
    $(".network").hide();
    $(".credits").hide();
    $(".kyc").show();
    $(".withdrawals").hide();
    $(".members").hide();
    $(".wallet_history").hide();
  });

  $("#userWithdrawal").click(function() {
    $(".profile").hide();
    $(".orders").hide();
    $(".network").hide();
    $(".credits").hide();
    $(".kyc").hide();
    $(".withdrawals").show();
    $(".members").hide();
    $(".wallet_history").hide();
  });

  $("#userMember").click(function() {
    $(".profile").hide();
    $(".orders").hide();
    $(".network").hide();
    $(".credits").hide();
    $(".kyc").hide();
    $(".withdrawals").hide();
    $(".members").show();
    $(".wallet_history").hide();
  });

  $("#userWalletHistory").click(function() {
    $(".profile").hide();
    $(".orders").hide();
    $(".network").hide();
    $(".credits").hide();
    $(".kyc").hide();
    $(".withdrawals").hide();
    $(".members").hide();
    $(".wallet_history").show();
  });


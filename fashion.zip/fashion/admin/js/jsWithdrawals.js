
  
  $("#btn_add").click(function (e) {
    //verification
    if ($("#selUsers").val().trim().length < 1) {
      snackbar_error("Please Select User");
      $("#selUsers").focus();
      return false;
    }
  
    if ($("#selKYC").val().trim().length < 1) {
      snackbar_error("Please Select KYC");
      $("#selKYC").focus();
      return false;
    }
  
    if ($("#txtAmount").val().trim().length < 1) {
      snackbar_error("Please Enter Amount");
      $("#txtAmount").focus();
      return false;
    }
  
    if ($("#txtTransactionID").val().trim().length < 1) {
      snackbar_error("Please Transaction ID");
      $("#txtTransactionID").focus();
      return false;
    }
  
    if ($("#txtDate").val().trim().length < 1) {
      snackbar_error("Please Select Payment Date");
      $("#txtDate").focus();
      return false;
    }
  
    //append data
    let formData = new FormData();
    formData.append("selUsers", $("#selUsers").val());
    formData.append("selKYC", $("#selKYC").val());
    formData.append("txtAmount", $("#txtAmount").val());
    formData.append("txtTransactionID", $("#txtTransactionID").val());
    formData.append("txtDate", $("#txtDate").val());
  
    let adminLogin = localStorage.getItem("admin-login");
    formData.append("loggedInBy", adminLogin);
  
    formData.append("action", "add");
  
    let table = $("#tableData").DataTable();
  
    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_add").attr("disabled", true);
      },
      url: "backend/process_withdrawal.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (result) {
          snackbar_success("Withdrawal Successful");
          table.ajax.reload();
          $("#add_modal").modal('hide');
        
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_add").attr("disabled", false);
      },
    });
  });
  // var sl_no = 0;
  // ADD Testimnials data Table (DONE)
  $(document).ready(function () {
  
    $.fn.dataTableExt.errMode = 'ignore';
    //show data
    let table = $("#tableData").DataTable({
      order: [[0, "desc"]],
      processing: true,
      serverSide: true,
      ajax: "backend/table_withdrawal.php",
  
    //   columnDefs: [
      
    //     {
    //       targets: -1,
    //       data: null,
    //       defaultContent:
    //         '<div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-toggle="modal" data-target="#edit_modal" class="text-primary"> <i class="fas fa-pen"></i></a><a href="javascript:void(0);" title="Delete" data-toggle="modal" data-target="#delete_modal" class="text-danger" id="delete_row"> <i class="far fa-trash-alt"></i></a></div>',
    //     },
    //   ],
  
    });
  
    table.on( 'draw.dt', function () {
      $('#tableData').DataTable().page.info();
           table.column(0, { page: 'current' }).nodes().each( function (cell, i) {
              cell.innerHTML = i + 1;
          });
      });
  
    //Edit Btn click
    $(document).on("click", "#edit_row", function () {
  
      let data = table.row($(this).parents("tr")).data();
  
      $("#txtName1").val(data[1]);
      $("#txtEmail1").val(data[2]);
      $("#txtMobileNo1").val(data[3]);
      $("#txtPassword1").val(data[4]);
      $("#selRole1").val(data[5]);
      $("#edit_id").val(data[0]);
  
    });
  
    $(document).on("click", "#delete_row", function () {
      let data = table.row($(this).parents("tr")).data();
      $("#delete_id").val(data[0]);
    });
  
    $(document).on("click", "#add_user", function () {
  
      $("#txtName").val('');
      $("#txtEmail").val('');
      $("#txtMobileNo").val('');
      $("#txtPassword").val('');
      $("#selRole").val('');
      $("#selMedium").val('');
      $("#txtName").focus('');
  
    });
  });
  

  $("#selUsers").change(function() {
        let formData = new FormData();
        formData.append("user_id", $("#selUsers").val());
        formData.append("action", "get_user_kyc");
    
        $.ajax({
            url: "backend/process_withdrawal.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (res) {

                let lclJSON = JSON.parse(res);
                if(lclJSON.kyc_details.length != 0) {
                    $("#selKYC").html("<option value="+lclJSON.kyc_details[0].id+">"+lclJSON.kyc_details[0].bank_user_name+"-"+lclJSON.kyc_details[0].bank_number+"</option>");
                } else {
                    $("#selKYC").html("<option value=''></option>");
                    alert("User Not Filled KYC");
                }
                
            }
        });
  });
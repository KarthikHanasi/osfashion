<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Orders</title>
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link href="css/styles.css" rel="stylesheet" />
    <link href="plugins/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous"/>
    <script src="plugins/js/font-awesome-all.min.js" crossorigin="anonymous"></script>

    <style>
        hr {
            margin-top: 1rem;
            margin-bottom: 1rem;
            border: 0;
            border-top: 1px solid rgba(0, 0, 0, 1);
        }
    </style>

</head>
<input type="text" hidden id = "date" >
<input type="text" hidden id = "month" >
<input type="text" hidden id = "year" >
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand" href="#">OsFashion</a><button class="btn btn-link btn-sm order-1 order-lg-0"
            id="sidebarToggle" href="#">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="backend/logout.php">Logout</a>
                </div>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
             <?php
                if($_SESSION['role'] == "Admin") {
                    include_once('include/admin_nav.php');
                } else {
                    include_once('include/teacher_nav.php');
                }

            ?>
        </div>
        <div id="layoutSidenav_content">
            <div class="container-fluid pt-3">
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active" id="date-time"></li>
                    Order Details<li class="user-name"></li>
                </ol>

                <div class="row">
                    <div class="col-12">
                        <form>
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="row">
                                        <!-- <div class="col-12 text-right mb-4">
                                            <button type="button" class="btn btn-success" data-toggle="modal"
                                                data-target="#add_modal">
                                                Add Blogs
                                            </button>
                                        </div> -->
                                        <div class="col-12">
                                            <div class="card mb-4">
                                                <div class="card-body">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered" id="tableData" width="100%"
                                                            cellspacing="0">
                                                            <thead>
                                                                <tr>
                                                                    <th>Sl No</th>
                                                                    <th>Order ID</th>
                                                                    <th>Name</th>
                                                                    <th>Mobile</th>
                                                                    <th>Address</th>
                                                                    <th>Transaction</th>
                                                                    <th>Amount</th>
                                                                    <th>Payment Type</th>
                                                                    <th>Status</th>
                                                                    <th>Order Date</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                           
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php include_once('include/footer.php'); ?>
        </div>
    </div>

    <!-- SNACKBAR/TOAST -->

    <div id="snackbar-success">success</div>
    <div id="snackbar-error">error</div>

    <!-- SNACKBAR/TOAST -->

    <!-- Loader -->
    <div class="se-pre-con"></div>
    <!-- Loader -->

    <!-- The Modal -->
    <div class="modal fade pb-5" id="edit_modal">
        <div class="modal-dialog" style="width: 80%;">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Order Details</h4>
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="#">
                        <input type="hidden" id="edit_id">
                        <div class="row">

                            <div class="col-md-12">
                                <h4>Customer Details</h4>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Order ID <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtOrderID1" readonly>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtName1" readonly>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Mobile Number <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtMobileNo1" readonly>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Transaction ID <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtTransactionid1" readonly>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Amount <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtAmount1" readonly>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Order Status <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtOrderStatus1" readonly>
                                </div>
                            </div>

                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Address <span class="text-danger">*</span></label>
                                    <div id="divAddress">

                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <h4>Order Details</h4>
                            </div>

                            <div class="col-md-12">
                                <table class="table" id="tableOrders">
                                    <tr>
                                        <th>sl no</th>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Size</th>
                                        <th>Color</th>
                                        <th>Price</th>
                                        <th>QTY</th>
                                        <th>Total</th>
                                    </tr>
                                </table>
                            </div>

                            <div class="col-sm-4 payment-status" style="display: none;">
                                <label>Payment Status</label>
                                <select class="form-control" id="selPaymentStatus">
                                    <option value="">Update Payment Status</option>
                                    <option value="SUCCESS">SUCCESS</option>
                                </select>
                            </div>

                            <div class="col-8 payment-status" style="margin-top: 33px; display: none;">
                                <button type="button" class="btn btn-success" id="btn_payment">
                                    <span class="spinner-border spinner-border-sm"></span> Update
                                </button>
                            </div>

                            <div class="col-sm-4 delivery-status" style="display: none;">
                                <label>Delivery Status</label>
                                <select class="form-control" id="selDeliveryStatus">
                                    <option value="">Update Delivery Status</option>
                                    <option value="DELIVERED">DELIVERED</option>
                                </select>
                            </div>
                            
                            <div class="col-8 delivery-status" style="margin-top: 33px; display: none;">
                                <button type="button" class="btn btn-success" id="btn_delivery">
                                    <span class="spinner-border spinner-border-sm"></span> Update
                                </button>
                            </div>

                            <div class="col-sm-4 cancel-order" style="display: none;">
                                <label>Cancel Order</label>
                                <select class="form-control" id="selCancel">
                                    <option value="">Please Select Cancel Order</option>
                                    <option value="CANCELED">CANCEL</option>
                                </select>
                            </div>
                            
                            <div class="col-8 cancel-order" style="margin-top: 33px; display: none;">
                                <button type="button" class="btn btn-success btn_cancel" id="btn_cancel">
                                    <span class="spinner-border spinner-border-sm"></span> Update
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- EDIT WORK -->


    <!-- Delete Field -->

    <!-- The Modal -->
    <div class="modal fade" id="delete_modal">
        <div class="modal-dialog" style="width: 60%">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <p class="text-center">
                        Are you sure you want to delete?
                    </p>
                    <input type="hidden" id="delete_id">
                    <div class="row">
                        <div class="col-6 text-right">
                            <button type="button" class="btn btn-success" id="btn_delete">Yes</button>
                        </div>
                        <div class="col-6 text-left">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">
                                No
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="reasonOrderCancel" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="overflow: scroll !important;">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Reason for Order Cancel</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="overflow-y: auto !important;">
                <label>Reason for Cancel</label>
                <textarea id="txtReason" class="form-control"></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" onclick="cancelOrder();">Submit</button>
            </div>
            </div>
        </div>
    </div>

    <!-- Delete Field -->

    <script src="plugins/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jsOrders.js"></script>

</body>

</html>
<?php
    session_start();
    include_once('../conn/conn.php');
    $db = new DatabaseClass();
    $con = $db->getCon();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Users</title>
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <link href="css/styles.css" rel="stylesheet" />
    <link href="plugins/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous"/>
    <script src="plugins/js/font-awesome-all.min.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="css/jquery.orgchart.css">
    <link rel="stylesheet" href="css/style1.css">

    <style>
        hr {
            margin-top: 1rem;
            margin-bottom: 1rem;
            border: 0;
            border-top: 1px solid rgba(0, 0, 0, 1);
        }

        .lower-btn{
            margin-top:4%;
            width:40%;
        }
        .lower-btn a{
            width:180px;
        }
        .buttons{
            width:80%;
        }
        .btn{
            height: 38px;
            width: 180px;
            font-weight:bold;
        }
    </style>

</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand" href="#">OsFashion</a><button class="btn btn-link btn-sm order-1 order-lg-0"
            id="sidebarToggle" href="#">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="backend/logout.php">Logout</a>
                </div>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
             <?php
                if($_SESSION['role'] == "Admin") {
                    include_once('include/admin_nav.php');
                } else {
                    include_once('include/teacher_nav.php');
                }

            ?>
        </div>
        <div id="layoutSidenav_content">
            <div class="container-fluid pt-3">
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active" id="date-time"></li>
                    Users Details<li class="user-name"></li>
                </ol>

                <div class="row">
                    <div class="col-12">
                        <form>
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="row">
                                       
                                        <div class="col-12">
                                            <div class="card mb-4">
                                                <div class="card-body">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered" id="tableData" width="100%"
                                                            cellspacing="0">
                                                            <thead>
                                                                <tr>
                                                                    <th>Sl No</th>
                                                                    <th>Name</th>
                                                                    <th>Mobile</th>
                                                                    <th>Email</th>
                                                                    <th>Verified User</th>
                                                                    <th>Referral Code</th>
                                                                    <th>is Active</th>
                                                                    <th>Wallet</th>
                                                                    <th>Date</th>
                                                                    <th>Password</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                           
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php include_once('include/footer.php'); ?>
        </div>
    </div>

    <!-- SNACKBAR/TOAST -->

    <div id="snackbar-success">success</div>
    <div id="snackbar-error">error</div>

    <!-- SNACKBAR/TOAST -->

    <!-- Loader -->
    <div class="se-pre-con"></div>
    <!-- Loader -->

    <!-- ADD WORK  -->

    <!-- EDIT WORK  -->

    <!-- The Modal -->
    <div class="modal fade" id="edit_modal" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" style="width: 80%;">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Tree View Details</h4>
                    <button type="button" class="close close1" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">

                
                    <form action="#">
                        <input type="hidden" id="edit_id">
                        <div class="row">

                            <div class="col-md-12">
                                <h4>User Details</h4>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtName1" readonly>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Mobile Number <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtMobileNo1" readonly>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Email <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtEmail1" readonly>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Referral Code <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtReferral1" readonly>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Wallet <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtWallet1" readonly>
                                </div>
                            </div>

                            <div id="chart-container"></div>
                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="wallet_modal" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" style="width: 40%;">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">User Wallet Update</h4>
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                
                    <form action="#" id="myform">
                        <input type="hidden" id="wallet_id">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtName2" readonly>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Type <span class="text-danger">*</span></label>
                                    <select id="selType" class="form-control">
                                        <option value="">Please Select Type</option>
                                        <option value="Credit">Credit (add)</option>
                                        <option value="Debit">Debit (deduct)</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Total Wallet <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtWallet2" readonly>
                                    <input type="hidden" class="form-control" id="txtWalletOriginal" readonly>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Amount <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="txtAmount2">
                                </div>
                            </div>

                            <div class="col-12 text-center mt-3">
                                <button type="button" class="btn btn-success" id="btn_update_wallet">
                                    <span class="spinner-border spinner-border-sm"></span> Update
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- EDIT WORK -->


    <!-- Delete Field -->

    <!-- The Modal -->
    <div class="modal fade" id="delete_modal">
        <div class="modal-dialog" style="width: 60%">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <p class="text-center">
                        Are you sure you want to delete?
                    </p>
                    <input type="hidden" id="delete_id">
                    <div class="row">
                        <div class="col-6 text-right">
                            <button type="button" class="btn btn-success" id="btn_delete">Yes</button>
                        </div>
                        <div class="col-6 text-left">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">
                                No
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" style="width: 40%;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
            <div class="container ">
                <div class="row" id="mlmDetails">
                <!-- <img src="img/logo.png"> -->

                  <div class="photo">

                  <div class="col-">
                    <!-- <img class="profile rounded" src="img/about-1.jpg"  alt="profile"> -->
                    <img class ="profile rounded" src="../img/myprofile.png" alt="profile">
     
                    <div class="mt-2">

                    <span class="in" for=""><b>Designation</b></label>
                    </div>

                    </div>
                  </div>
                  <div class="col ">
                    <span class="info"><b>Name  : </b></span>
                    <br/>
                    <span class="info"><b>Age  : </b></span>
                    <br/>

                    <span class="info"><b>Ref Code  :  </b></span>

                    <br/>
                    <span class="info"><b>Ref By  :  </b></span>
                    <br/>


                    <span class="info"><b>Gender  :  </b></span>
                    <br/>
                    <span class="info"><b>Email  :  </b></span>
                    <br/>
                    <span class="info"><b>Mobile  :  </b></span>
                  </div>
                </div>
        </div>
      </div>
      <div class="modal-footer">
      </div></div></div>
</div>

<div class="modal fade" id="history" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" style="width: 90%; height:80%;">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">History</h4>
                    <button type="button" class="close close1" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <!-- Modal body -->
                    <div class="modal-body">
                        <div class="buttons row mx-auto">
                            <div class="col-sm mb-3">
                                <a href="#" class="btn btn-warning text-light" id="userProfile">Profile</a>
                            </div>

                            <div class="col-sm mb-3">
                                <a href="#" class="btn btn-warning text-light" id="userOrder">Order</a>
                            </div>

                            <div class="col-sm mb-3">
                                <a href="#" class="btn btn-warning text-light" id="userNetwork">Network</a>
                            </div>

                            <div class="col-sm mb-3">
                                <a href="#" class="btn btn-warning text-light" id="userCredit">Credit</a>
                            </div>
                            <div class="col-sm mb-3">
                                <a href="#" class="btn btn-warning text-light" id="userKYC">KYC</a>
                            </div>

                            <div class="col-sm mb-3">
                                <a href="#" class="btn btn-warning text-light" id="userWithdrawal">Withdrawal</a>
                            </div>

                            <div class="col-sm mb-3">
                                <a href="#" class="btn btn-warning text-light" id="userMember">Member</a>
                            </div>

                            <div class="col-sm mb-3">
                                <a href="#" class="btn btn-warning text-light" id="userWalletHistory">Wallet History</a>
                            </div>

                        </div>
                        <div class="container profile">
                            <div class="row" id="divProfile">
                            </div>
                        </div>

                        <div class="container orders" style="display: none;">
                            <div class="row">
                                <h3>Orders</h3>
                                <table class="table" id="divOrdersTable">

                                </table>
                            </div>
                        </div>

                        <div class="container network" style="display: none;">
                            <div class="row">
                                <h3 style="width: 100%;">Network</h3>
                                <div id="chart-container1"></div>
                            </div>
                        </div>

                        <div class="container credits" style="display: none;">
                            <div class="row">
                                <h3 style="width: 100%;">Credits</h3>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Credit From</th>
                                            <th>Amount</th>
                                            <th>BV</th>
                                            <th>%</th>
                                            <th>Level</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody id="divCreditsTable">
                                    
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="container kyc" style="display: none;">
                                <div class="row">
                                    <h3 style="width: 100%;">KYC</h3>
                                    <div class="col-md-3 form-group">
                                    <label><b>Aadhar Details</b><span class="text-danger">*</span></label>
                                </div>

                                <div class="col-md-3 form-group">
                                    <a href="" style="text-decoration:underline" id="aadharFile" download>Aadhar</a>
                                </div>

                                <div class="col-md-3 form-group">
                                    <p id="aadharNumber"></p>
                                </div>

                                <div class="col-md-3 form-group">
                                    <p id="aadharStatus"></p>
                                </div>

                                <div class="col-md-3 form-group">
                                    <label><b>Pan Details</b><span class="text-danger">*</span></label>
                                </div>

                                <div class="col-md-3 form-group">
                                    <a href="" style="text-decoration:underline" id="panFile">Pan</a>
                                </div>

                                <div class="col-md-3 form-group">
                                    <p  id="panNumber"></p>
                                </div>

                                <div class="col-md-3 form-group">
                                    <p id="panStatus"></p>
                                </div>

                                <div class="col-md-3 form-group">
                                    <label><b>Bank Account Details</b><span class="text-danger">*</span></label>
                                </div>

                                <div class="col-md-3 form-group">
                                    <a href="" style="text-decoration:underline" id="bankFile">Bank</a>
                                </div>

                                <div class="col-md-3 form-group">
                                    Account Name <b><p id="accountName"></p></b>
                                    Account Number <b><p id="accountNumber"></p></b>
                                    Bank Name <b><p id="bankName"></p></b>
                                    IFSC Code <b><p id="ifscCode"></p></b>
                                </div>

                                <div class="col-md-3 form-group">
                                    <p id="bankStatus"></p>
                                </div>
                            </div>
                        </div>

                        <div class="container withdrawals" style="display: none;">
                            <h3 style="width: 100%;">Withdrawals</h3>
                            <table id="" class="table">
                                <thead>
                                    <tr>
                                        <th>Sl.No</th>
                                        <th>Name</th>
                                        <th>Mobile</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>Transaction ID</th>
                                        <th>A/C Name</th>
                                        <th>A/C Number</th>
                                        
                                    </tr>
                                </thead>
                                <tbody id="withdrawalsDetails">
                                
                                </tbody>
                            </table>
                        </div>

                        <div class="container members" style="display: none;">
                            <h3 style="width: 100%;">Member Details</h3>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>is Member?</th>
                                        <th>Member Plan Name</th>
                                        <th>Member Plan Amount</th>
                                    </tr>
                                </thead>

                                <tbody id="memberDetails">
                                
                                </tbody>
                            </table>
                        </div>

                        <div class="container wallet_history" style="display: none;">
                            <h3 style="width: 100%;">Wallet History</h3>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Name</th>
                                        <th>Type</th>
                                        <th>Prev Wallet</th>
                                        <th>Amount</th>
                                        <th>New Wallet</th>
                                        <th>Update By</th>
                                        <th>Date & Time</th>
                                    </tr>
                                </thead>

                                <tbody id="walletHistory">
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <!-- Delete Field -->

    <script src="plugins/js/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="plugins/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="js/main.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-mockjax/2.6.0/jquery.mockjax.min.js" integrity="sha512-XfnoLXUxtEYGVB+xpqJ8PIfAzz0oD6T4wX4BRFs/MLQxCI+DvQpgfAc3ydt3V7ZTyjaHwrtC/yTG508P1PBjXQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-mockjax/2.6.0/jquery.mockjax.js" integrity="sha512-ue/3zG3k88JRl94SfqJpn+iuWf20pPfk1e+BLqCFFrJvjtRtZP2IUjfUhUUjNVn52NK2b/uUNkic5q0oNRKwtQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript" src="js/jquery.orgchart.js"></script>
    <script src="js/jsUsers.js"></script>

    <script>
        $(".close1").click(function() {
            location.reload();
        });
    </script>

</body>

</html>
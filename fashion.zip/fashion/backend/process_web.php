<?php

	$expire = 365*24*36000; // We choose a one year duration

	ini_set('session.gc_maxlifetime', $expire);

	session_start(); //We start the session 

	setcookie(session_name(),session_id(),time()+$expire); 
	// error_reporting(0);
	include_once('../conn/conn.php');
	include_once('../admin/backend/generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();
	switch ($action) {

		case 'get_all_products':
			getAllProducts($params, $con);
			break;

		case 'get_home_category_details':
			getHomeCategoryDetails($params, $con);
			break;

		case 'get_home_women_details':
			getHomeWomensDetails($params, $con);
			break;

		case 'get_home_men_details':
			getHomeMensDetails($params, $con);
			break;

		case 'get_home_all_details':
			getHomeAllDetails($params, $con);
			break;

		case 'get_shop_all_products':
			getShopDetails($params, $con);
			break;

		case 'get_category_shop_details':
			getCategoryShopDetails($params, $con);
			break;

		case 'get_sub_category_shop_details':
			getSubCategoryShopDetails($params, $con);
			break;

		case 'get_single_product_details':
			getSingleProductDetails($params, $con);
			break;

		case 'add_cart':
			addCart($params, $con, $UUID);
			break;

		case 'get_cart_details':
			getCartDetails($params, $con);
			break;

		case 'delete_cart':
			deleteCart($params, $con);
			break;

		case 'delete_cart1':
			deleteCart1($params, $con);
			break;

		case 'update_cart':
			updateCart($params, $con);
			break;

		case 'update_session_cart':
			updateSessionCart($params, $con);
			break;

		case 'register':
			register($params, $con, $UUID);
			break;

		case 'verify_mobile':
			verifyMobile($params, $con, $UUID);
			break;

		case 'login':
			login($params, $con, $UUID);
			break;

		case 'contact':
			insertContact($params, $con);
			break;

		case 'get_collection_details':
			getCollectionDetails($params, $con);
			break;

		case 'place_order':
			placeOrder($params, $con, $UUID);
			break;

		case 'get_search_details':
			getSearchDetails($params, $con);
			break;

		case 'verify_otp':
			verifyOTP($params, $con);
			break;

		case 'resend_otp':
			resendOTP($params, $con);
			break;

		case 'update_password':
			updatePassword($params, $con);
			break;

		case 'forgot_password':
			forgotPassword($params, $con, $UUID);
			break;

		case 'notification':
			saveNotification($params, $con);
			break;

		case 'check_shipping_charges':
			checkShippingCharges($params, $con);
			break;

		case 'get_orders_details':
			getOrderDetails($params, $con);
			break;

		case 'get_my_products_details':
			getMyProductDetails($params, $con);
			break;

		case 'get_checkout_details':
			getCheckoutDetails($params, $con);
			break;

		case 'update_payment':
			updatePayment($params, $con);
			break;

		case 'get_profile':
			getProfile($params, $con);
			break;

		case 'update_profile':
			updateProfile($params, $con);
			break;

		case 'add_new_address':
			addNewAddress($params, $con, $UUID);
			break;

		case 'update_new_address':
			updateNewAddress($params, $con, $UUID);
			break;

		case 'delete_address':
			deleteAddress($params, $con);
			break;

		case 'get_collection_cart_details':
			getCollectionCartDetails($params, $con);
			break;

		case 'add_review':
			addReview($params, $con, $UUID);
			break;

		case 'get_review':
			getReview($params, $con);
			break;

	}

	function register($params, $con, $UUID) {

		if($params['txtReferralCode'] == "") {
			$lclResCount1 = 1;
		} else {
			$lclQueryExist1 = "SELECT count(*) FROM users WHERE us_referral_code = '".$params['txtReferralCode']."'";
    		$lclResultExist1 = $con->query($lclQueryExist1);
    		$lclResCount1 = $lclResultExist1->fetchColumn();
		}

		if($lclResCount1 == 0) {
    		echo "20";

    	} else {

			$lclQueryExist2 = "SELECT count(*) FROM users WHERE us_mobile = '".$params['txtMobileNo']."'";
			$lclResultExist2 = $con->query($lclQueryExist2);
			$lclResCount2 = $lclResultExist2->fetchColumn();

			if($lclResCount2 == 1) {
				echo "10";

			} else {

				$lclQuery1 = "SELECT us_id FROM users WHERE us_referral_code = '".$params['txtReferralCode']."'";
				$lclResult1 = $con->query($lclQuery1);

				if($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {

					$lclQueryExist2 = "SELECT count(*) FROM temp_registration WHERE tmp_mobile = '".$params['txtMobileNo']."'";
    				$lclResultExist2 = $con->query($lclQueryExist2);
    				$lclResCount2 = $lclResultExist2->fetchColumn();

					if($lclResCount2 > 0) {

						$lclUpdate = "UPDATE temp_registration SET tmp_name = '".$params['txtName']."',
											tmp_referral_user_id = '".$row1['us_id']."',
											tmp_password = '".$params['txtPassword']."'
									WHERE tmp_mobile = '".$params['txtMobileNo']."'";
						$con->query($lclUpdate);
						$_SESSION['reg_mobile'] = $params['txtMobileNo'];

					} else {
						$lclQuery = $con->prepare("INSERT INTO temp_registration (tmp_id, tmp_name, tmp_mobile, tmp_referral_user_id, tmp_password) VALUES(:tmp_id, :tmp_name, :tmp_mobile, :tmp_referral_user_id, :tmp_password)");

						$lclQuery->bindParam(':tmp_id', $UUID);
						$lclQuery->bindParam(':tmp_name', $params['txtName']);
						$lclQuery->bindParam(':tmp_mobile', $params['txtMobileNo']);
						$lclQuery->bindParam(':tmp_referral_user_id', $row1['us_id']);
						$lclQuery->bindParam(':tmp_password', $params['txtPassword']);
						$lclResult = $lclQuery->execute();
						$_SESSION['reg_mobile'] = $params['txtMobileNo'];
					}
					

				} else {

					$lclQueryExist2 = "SELECT count(*) FROM temp_registration WHERE tmp_mobile = '".$params['txtMobileNo']."'";
    				$lclResultExist2 = $con->query($lclQueryExist2);
    				$lclResCount2 = $lclResultExist2->fetchColumn();
					$lclRefUserID = 'abcdef-123456-abcdef-123456';
					if($lclResCount2 > 0) {
						$lclUpdate = "UPDATE temp_registration SET tmp_name = '".$params['txtName']."',
											tmp_referral_user_id = '".$lclRefUserID."',
											tmp_password = '".$params['txtPassword']."'
									WHERE tmp_mobile = '".$params['txtMobileNo']."'";
						$con->query($lclUpdate);
						$_SESSION['reg_mobile'] = $params['txtMobileNo'];
					} else {
						
						$lclQuery = $con->prepare("INSERT INTO temp_registration (tmp_id, tmp_name, tmp_mobile, tmp_referral_user_id, tmp_password) VALUES(:tmp_id, :tmp_name, :tmp_mobile, :tmp_referral_user_id, :tmp_password)");

						$lclQuery->bindParam(':tmp_id', $UUID);
						$lclQuery->bindParam(':tmp_name', $params['txtName']);
						$lclQuery->bindParam(':tmp_mobile', $params['txtMobileNo']);
						$lclQuery->bindParam(':tmp_referral_user_id', $lclRefUserID);
						$lclQuery->bindParam(':tmp_password', $params['txtPassword']);
						$lclResult = $lclQuery->execute();
						$_SESSION['reg_mobile'] = $params['txtMobileNo'];
					}
					
				}

				$username = "osfashionetwork@gmail.com";
				$apikey = "5aa722b394c14f799fb01cc6caa69375";
				//Multiple mobiles numbers separated by comma
				$mobileNumber = $params['txtMobileNo'];
				$senderId = "OSFSNN";
				$message = "Dear client , Your One Time Password is ".$params['otp']." .One Step Fashion Network OSFSNN PEARLL";
				$smstype = "TRANS";
				$postData = array(
					'apikey' => $apikey,
					'numbers' => $mobileNumber ,
					'message' => $message ,
					'sender' => $senderId,
					'smstype' => $smstype,
				);
				$url="http://sms.pearlsms.com/public/sms/send?";

				// init the resource
				$ch = curl_init();
				curl_setopt_array($ch, array(
					CURLOPT_URL => $url,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_POST => true,
					CURLOPT_POSTFIELDS => $postData
				));

				//Ignore SSL certificate verification
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

				//get response
				$output = curl_exec($ch);

				//Print error if any
				if(curl_errno($ch)) {
					echo 'error:' . curl_error($ch);
				}

				curl_close($ch);

				$lclQuery = "SELECT count(*) FROM verify_otp WHERE vo_mobile = '".$params['txtMobileNo']."'";
				$lclResult = $con->query($lclQuery);
				$lclResCount = $lclResult->fetchColumn();

				if($lclResCount > 0) {
					$lclUpdate = "UPDATE verify_otp SET vo_otp = '".$params['otp']."'
					WHERE vo_mobile = '".$params['txtMobileNo']."'";
					$lclRes = $con->query($lclUpdate);
				} else {
					
					$lclQuery1 = $con->prepare("INSERT INTO verify_otp (vo_id, vo_mobile, vo_otp) VALUES(:vo_id, :vo_mobile, :vo_otp)");

					$lclQuery1->bindParam(':vo_id', $UUID);
					$lclQuery1->bindParam(':vo_mobile', $params['txtMobileNo']);
					$lclQuery1->bindParam(':vo_otp', $params['otp']);

					$lclResult = $lclQuery1->execute();
				}

				// send whats app message
				$ch = curl_init();
				$accessToken = 'EAAJEMf5ULI8BAAupYtQjJwyFD0AyrTYoMuObkNmUyp56PsdphgJddDcnk92kuHgL6dqvM8p7z1O5j4KE1CCOZA8QepFPv95N7t4z1bUmjFJt0WfzkMLg4MWC9GCUpmsDtb4gn4l0sprfcq0UYvHEKBJZBClmlGaFXKwJwZBv3vr6fwkWSp1rgciacZCTl4IZD';

				$messageData1 = array(
					'messaging_product' => "whatsapp",
					'to' => '91'.$params['txtMobileNo'],
					'type' => "template",
					'template' => array("name"=> "marketing2",'language'=>array("code"=>"en_US"))
				);
				
				curl_setopt($ch, CURLOPT_URL,"https://graph.facebook.com/v16.0/100492896388925/messages");
				curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Bearer $accessToken"));
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($messageData1));
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$server_output = curl_exec($ch);
				curl_close($ch);
				// verifyMobile($params, $con, $UUID=guidv4());
			}
		}
	}

	function verifyMobile($params, $con, $UUID) {
		$lclQuery1 = "SELECT * FROM verify_otp WHERE vo_mobile = '".$_SESSION['reg_mobile']."' AND vo_otp = '".$params['txtOTP']."'";
		$lclResult1 = $con->query($lclQuery1);

		if($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {

			$lclQuery = "SELECT * FROM temp_registration WHERE tmp_mobile = '".$_SESSION['reg_mobile']."'";
    		$lclResult = $con->query($lclQuery);
			if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
				$lclQuery = $con->prepare("INSERT INTO users (us_id, us_name, us_mobile, us_referred_user_id, us_password) VALUES(:us_id, :us_name, :us_mobile, :us_referred_user_id, :us_password)");

				$lclQuery->bindParam(':us_id', $UUID);
				$lclQuery->bindParam(':us_name', $row["tmp_name"]);
				$lclQuery->bindParam(':us_referred_user_id', $row["tmp_referral_user_id"]);
				$lclQuery->bindParam(':us_mobile', $row["tmp_mobile"]);
				$lclQuery->bindParam(':us_password', $row["	tmp_password"]);
				$lclResult = $lclQuery->execute();

				$lclQuery4 = "DELETE FROM temp_registration WHERE tmp_mobile = '".$row["tmp_mobile"]."'";
				$con->query($lclQuery4);
				echo "1";
			}

		} else {
			echo "10";
		}
	}

	function login($params, $con, $UUID) {

		$lclQueryExist = "SELECT count(*) FROM users WHERE us_mobile = '".$params['txtMobileNo']."' AND us_password = '".$params['txtPassword']."'";
    	$lclResultExist = $con->query($lclQueryExist);

    	$lclResCount = $lclResultExist->fetchColumn();

		if($lclResCount == 1) {

			$lclQuery = "SELECT * FROM users WHERE us_mobile = '".$params['txtMobileNo']."'";
    		$lclResult = $con->query($lclQuery);

			if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
				$_SESSION['name'] = $row['us_name']; 
				$_SESSION['mobile'] = $row['us_mobile'];
				$_SESSION['email'] = $row['us_email'];
				$_SESSION['id'] = $row['us_id'];
				$_SESSION['referral_code'] = $row['us_referral_code'];

			}

			if(isset($_SESSION['pd_cart_name'])) {

                for($i = 0; $i < count($_SESSION['pd_cart_name']); $i++) {
				
					$lclQuery1 = "SELECT * FROM cart WHERE ct_pd_id = '".$_SESSION['pd_cart_id'][$i]."' AND ct_us_id = '".$row['us_id']."'";
					$lclResult1 = $con->query($lclQuery1);
						
					if($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
						$lclQuery2 = "UPDATE cart SET ct_qty = ct_qty + ".$_SESSION['pd_cart_quantity'][$i]."
						WHERE ct_pd_id = '".$_SESSION['pd_cart_id'][$i]."' AND ct_us_id = '".$row['us_id']."'";
						$con->query($lclQuery2);
					} else {

						$sql = $con->prepare("INSERT INTO cart (ct_id, ct_us_id, ct_pd_id, ct_qty, ct_color, ct_size) VALUES(:ct_id, :ct_us_id, :ct_pd_id, :ct_qty, :ct_color, :ct_size)");
						$sql->bindParam(':ct_id', $UUID);
						$sql->bindParam(':ct_us_id', $row['us_id']);
						$sql->bindParam(':ct_pd_id', $_SESSION['pd_cart_id'][$i]);
						$sql->bindParam(':ct_qty', $_SESSION['pd_cart_quantity'][$i]);
						$sql->bindParam(':ct_color', $_SESSION['pd_cart_color'][$i]);
						$sql->bindParam(':ct_size', $_SESSION['pd_cart_size'][$i]);
						
						$lclResult = $sql->execute();
					}
		        }

		        unset($_SESSION['pd_cart_id']);
		        unset($_SESSION['pd_cart_name']);
		        unset($_SESSION['pd_cart_price']);
		        unset($_SESSION['pd_cart_total_price']);
		        unset($_SESSION['pd_cart_quantity']);
		        unset($_SESSION['pd_cart_color']);
		        unset($_SESSION['pd_cart_size']);
		        unset($_SESSION['pd_cart_image']);
				
		    }

	        echo "1";

	    } else {
	       	echo "10";
	    }
	}

	function insertContact($params, $con) {

		$sql = $con->prepare("INSERT INTO contact (ct_name, ct_email, ct_mobile_no, ct_subject, ct_message) VALUES(:ct_name, :ct_email, :ct_mobile_no, :ct_subject, :ct_message)");
		$sql->bindParam(':ct_name', $params['txtName']);
		$sql->bindParam(':ct_email', $params['txtEmail']);
		$sql->bindParam(':ct_mobile_no', $params['txtMobileNo']);
		$sql->bindParam(':ct_subject', $params["txtSubject"]);
		$sql->bindParam(':ct_message', $params["txtMessage"]);
		$lclResult = $sql->execute();
		echo "1";
	}

	function getAllProducts($params, $con) {
		$products = array();
		$lclQuery = "SELECT * FROM products WHERE pd_status = 0";
		$lclResult = $con->query($lclQuery);
			
		while($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
			$products[] = $row;
		}

		echo json_encode(array("products" => $products));
	}

	function getHomeCategoryDetails($params, $con) {

		// $mens = array();
		// $lclQuery1 = "SELECT * FROM products
		// LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		// WHERE pd_status = 0 AND pd_category_name = '6ed8b1be-8179-49bd-80ed-0c405536d0c4' LIMIT 10";
		// $lclResult1 = $con->query($lclQuery1);
			
		// while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
		// 	$mens[] = $row1;
		// }

		// $womens = array();
		// $lclQuery2 = "SELECT * FROM products
		// LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		// WHERE pd_status = 0 AND pd_category_name = '4c2a9252-76d9-4829-bc6a-f235a3f0b488' LIMIT 10";
		// $lclResult2 = $con->query($lclQuery2);
			
		// while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
		// 	$womens[] = $row2;
		// }

		// $kids = array();
		// $lclQuery3 = "SELECT * FROM products WHERE pd_status = 0 AND pd_category_name = '012ca51e-740f-499d-934b-f1aa269b5571' LIMIT 10";
		// $lclResult3 = $con->query($lclQuery3);
			
		// while($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
		// 	$kids[] = $row3;
		// }

		// $allProducts = array();
		// $lclQuery4 = "SELECT * FROM products
		// LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		// WHERE pd_status = 0 LIMIT 28";
		// $lclResult4 = $con->query($lclQuery4);
			
		// while($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
		// 	$allProducts[] = $row4;
		// }

		$category = array();
		$lclQuery5 = "SELECT * FROM categories ORDER BY ca_sequence ASC";
		$lclResult5 = $con->query($lclQuery5);
			
		while($row5 = $lclResult5->fetch(PDO::FETCH_ASSOC)) {
			$category[] = $row5;
		}

		echo json_encode(array("category" => $category));

	}

	function getHomeWomensDetails($params, $con) {
		$womens = array();
		$lclQuery2 = "SELECT pd_id, pd_name, pd_price, pd_image, pd_category_name, pd_discount, pd_discount_price, pd_stock, ca_name FROM products
		LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		WHERE pd_status = 0 AND pd_category_name = '4c2a9252-76d9-4829-bc6a-f235a3f0b488' LIMIT 6";
		$lclResult2 = $con->query($lclQuery2);

		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$womens[] = $row2;
		}

		echo json_encode(array("womens" => $womens));
	}

	function getHomeMensDetails($params, $con) {
		$mens = array();
		$lclQuery1 = "SELECT pd_id, pd_name, pd_price, pd_image, pd_category_name, pd_discount, pd_discount_price, pd_stock, ca_name FROM products
		LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		WHERE pd_status = 0 AND pd_category_name = 'fc057831-e89a-4087-8271-9be6ec4fe304' LIMIT 6";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$mens[] = $row1;
		}

		echo json_encode(array("mens" => $mens));
	}

	function getHomeAllDetails($params, $con) {
		$allProducts = array();
		$lclQuery4 = "SELECT pd_id, pd_name, pd_price, pd_image, pd_category_name, pd_discount, pd_discount_price, pd_stock, ca_name FROM products
		LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		WHERE pd_status = 0 ORDER BY pd_created_at DESC LIMIT 80";
		$lclResult4 = $con->query($lclQuery4);
			
		while($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
			$allProducts[] = $row4;
		}

		echo json_encode(array("allProducts" => $allProducts));
	}

	function getShopDetails($params, $con) {

		$products = array();
		$lclQuery1 = "SELECT * FROM products
		LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		WHERE pd_status = 0 ORDER BY pd_created_at DESC";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$products[] = $row1;
		}

		$category = array();
		$lclQuery2 = "SELECT * FROM categories ORDER BY ca_sequence ASC";
		$lclResult2 = $con->query($lclQuery2);
			
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$category[] = $row2;
		}

		echo json_encode(array("products" => $products, "category" => $category));

	}

	function getCategoryShopDetails($params, $con) {

		$products = array();
		$lclQuery1 = "SELECT * FROM products
		LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		WHERE pd_status = 0 AND pd_category_name = '".$params["category"]."' ORDER BY pd_created_at DESC";
		$lclResult1 = $con->query($lclQuery1);
		
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$products[] = $row1;
		}

		$subCategory = array();
		$lclQuery2 = "SELECT * FROM sub_category WHERE sub_ca_id = '".$params["category"]."'";
		$lclResult2 = $con->query($lclQuery2);

		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$subCategory[] = $row2;
		}

		echo json_encode(array("products" => $products, "subCategory" => $subCategory));
	}

	function getSubCategoryShopDetails($params, $con) {

		$products = array();
		$lclQuery1 = "SELECT * FROM products
		LEFT JOIN sub_category ON sub_category.sub_id = products.pd_sub_category_name
		WHERE pd_status = 0 AND pd_sub_category_name = '".$params["subcategory"]."'";
		$lclResult1 = $con->query($lclQuery1);
		
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$products[] = $row1;
		}

		echo json_encode(array("products" => $products));
	}

	function getSingleProductDetails($params, $con) {
		$color = array();
		$lclQuery1 = "SELECT co_id, co_name, co_code FROM color";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$color[] = $row1;
		}

		$size = array();
		$lclQuery2 = "SELECT sz_id, sz_name FROM size ORDER BY sz_sequence ASC";
		$lclResult2 = $con->query($lclQuery2);
			
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$size[] = $row2;
		}

		$products = array();
		$lclQuery3 = "SELECT * FROM products
		LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		WHERE pd_id = '".$params['id']."'";
		$lclResult3 = $con->query($lclQuery3);
			
		while($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$products[] = $row3;
		}

		$categoryName = $products[0]['pd_category_name'];
		$subCategoryName = $products[0]['pd_sub_category_name'];

		$similarProducts = array();
		$lclQuery4 = "SELECT * FROM products WHERE (pd_category_name = '".$categoryName."' OR pd_sub_category_name = '".$subCategoryName."') AND pd_id !=  '".$params['id']."' AND pd_status = 0";
		$lclResult4 = $con->query($lclQuery4);
			
		while($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
			$similarProducts[] = $row4;
		}

		$category = array();
		$lclQuery5 = "SELECT ca_id, ca_name FROM categories";
		$lclResult5 = $con->query($lclQuery5);
			
		while($row5 = $lclResult5->fetch(PDO::FETCH_ASSOC)) {
			$category[] = $row5;
		}

		$productSize = array();
		$lclQuery6 = "SELECT * FROM product_size WHERE ps_pd_id = '".$params['id']."' AND ps_stock > 0";
		$lclResult6 = $con->query($lclQuery6);
			
		while($row6 = $lclResult6->fetch(PDO::FETCH_ASSOC)) {
			$productSize[] = $row6;
		}


		echo json_encode(array("color" => $color, "size" => $size, "products" => $products, "similarProducts" => $similarProducts, "category" => $category, "productSize" => $productSize));
	}
	

	function getPurchaseDetails($params, $con) {

		$vegFruits = array();
		$lclQuery1 = "SELECT * FROM products WHERE pd_status = 0 AND (pd_category_name = 'Vegitables' OR pd_category_name = 'Fruits')";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$vegFruits[] = $row1;
		}

		$foodGrainsDryFruits = array();
		$lclQuery2 = "SELECT * FROM products WHERE pd_status = 0 AND (pd_category_name = 'Dry Fruits' OR pd_category_name = 'Food Grains')";
		$lclResult2 = $con->query($lclQuery2);
			
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$foodGrainsDryFruits[] = $row2;
		}

		$bestProducts = array();
		$lclQuery3 = "SELECT * FROM products WHERE pd_status = 0 ORDER BY RAND() LIMIT 5";
		$lclResult3 = $con->query($lclQuery3);
			
		while($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$bestProducts[] = $row3;
		}

		$saleProducts = array();
		$lclQuery4 = "SELECT * FROM products WHERE pd_status = 0 AND (pd_category_name = 'Vegitables' OR pd_category_name = 'F') ORDER BY pd_id DESC LIMIT 5";
		$lclResult4 = $con->query($lclQuery4);
			
		while($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
			$saleProducts[] = $row4;
		}

		$newProducts = array();
		$lclQuery5 = "SELECT * FROM products WHERE pd_status = 0 AND (pd_category_name = 'Dry Fruits' OR pd_category_name = 'Food Grains') ORDER BY RAND() LIMIT 5";
		$lclResult5 = $con->query($lclQuery5);
			
		while($row5 = $lclResult5->fetch(PDO::FETCH_ASSOC)) {
			$newProducts[] = $row5;
		}

		$naturalLocal = array();
		$lclQuery6 = "SELECT * FROM products WHERE pd_status = 0 LIMIT 15";
		$lclResult6 = $con->query($lclQuery6);
			
		while($row6 = $lclResult6->fetch(PDO::FETCH_ASSOC)) {
			$naturalLocal[] = $row6;
		}

		echo json_encode(array("vegFruits" => $vegFruits, "foodGrainsDryFruits" => $foodGrainsDryFruits, "bestProducts" => $bestProducts, "saleProducts" => $saleProducts, "newProducts" => $newProducts, "naturalLocal" => $naturalLocal));

	}

	function getCollectionDetails($params, $con) {

		$productList = array();
		$lclQuery1 = "SELECT * FROM products WHERE pd_status = 0 LIMIT 5";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$productList[] = $row1;
		}

		$categoryList = array();
		$lclQuery2 = "SELECT * FROM products WHERE pd_status = 0 AND pd_category_name = '".$params["txtCategory"]."' LIMIT 20";
		$lclResult2 = $con->query($lclQuery2);
			
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$categoryList[] = $row2;
		}

		echo json_encode(array("productList" => $productList, "categoryList" => $categoryList));
	}

	function getSearchDetails($params, $con) {

		$products = array();
		$lclQuery1 = "SELECT * FROM products
		LEFT JOIN categories ON categories.ca_id = products.pd_category_name
		WHERE pd_status = 0 AND pd_name LIKE '%".$params["searchVal"]."%'";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$products[] = $row1;
		}

		$category = array();
		$lclQuery2 = "SELECT ca_id, ca_name FROM categories";
		$lclResult2 = $con->query($lclQuery2);
			
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$category[] = $row2;
		}

		echo json_encode(array("products" => $products, "category" => $category));
	}


	function addCart($params, $con, $UUID) {
		if(!isset($_SESSION['mobile'])) {

			if(!isset($_SESSION['pd_cart_name'])) {
				$_SESSION['pd_cart_id'] = array();
				$_SESSION['pd_cart_name'] = array();
				$_SESSION['pd_cart_price'] = array();
				$_SESSION['pd_cart_quantity'] = array();
				$_SESSION['pd_cart_color'] = array();
				$_SESSION['pd_cart_size'] = array();
				$_SESSION['pd_cart_image'] = array();
				$_SESSION['pd_cart_total_price'] = array();
			}

			$lclQuery = "SELECT * FROM products WHERE pd_id = '".$params['product_id']."'";
			$lclResult = $con->query($lclQuery);
				
			if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
				
				$lclProductID = $row['pd_id'];
				$lclProductName = $row['pd_name'];
				$lclProductPrice = $row['pd_discount_price'];
				$lclProductQty = $row['pd_quantity'];
				$lclColor = $row['pd_color'];
				$lclProductImage = $row['pd_image'];
				$lclTotalPrice = $params['quantity'] * $lclProductPrice;

				array_push($_SESSION['pd_cart_id'], $lclProductID);
				array_push($_SESSION['pd_cart_name'], $lclProductName);
				array_push($_SESSION['pd_cart_price'], $lclProductPrice);
				array_push($_SESSION['pd_cart_quantity'], $params['quantity']);
				array_push($_SESSION['pd_cart_color'], $lclColor);
				array_push($_SESSION['pd_cart_size'], $params['size']);
				array_push($_SESSION['pd_cart_image'], $lclProductImage);
				array_push($_SESSION['pd_cart_total_price'], $lclTotalPrice);

	            echo "1";
			}

		} else {

			$lclQuery1 = "SELECT * FROM cart WHERE ct_pd_id = '".$params['product_id']."' AND ct_us_id = '".$_SESSION['id']."' AND ct_color = '".$params['color']."' AND ct_size = '".$params['size']."'";
			$lclResult1 = $con->query($lclQuery1);
				
			if($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
				$lclQuery2 = "UPDATE cart SET ct_qty = ct_qty + ".$params['quantity']."
				WHERE ct_pd_id = '".$params['product_id']."' AND ct_us_id = '".$_SESSION['id']."'";
				$con->query($lclQuery2);
				echo "1";

			} else {
				$lclQuery = "SELECT * FROM products WHERE pd_id = '".$params['product_id']."'";
				$lclResult = $con->query($lclQuery);

					
				if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
					$lclProductID = $row['pd_id'];

					$sql = $con->prepare("INSERT INTO cart (ct_id, ct_us_id, ct_pd_id, ct_qty, ct_color, ct_size) VALUES(:ct_id, :ct_us_id, :ct_pd_id, :ct_qty, :ct_color, :ct_size)");
					$sql->bindParam(':ct_id', $UUID);
					$sql->bindParam(':ct_us_id', $_SESSION['id']);
					$sql->bindParam(':ct_pd_id', $lclProductID);
					$sql->bindParam(':ct_qty', $params['quantity']);
					$sql->bindParam(':ct_color', $params['color']);
					$sql->bindParam(':ct_size', $params['size']);

					$lclResult = $sql->execute();
					echo "1";
				}
			}

			
		}

	}

	function getCartDetails($params, $con) {
		$cartDetails = array();
		if(isset($_SESSION['id'])) {
			$lclQuery1 = "SELECT * FROM cart
			LEFT JOIN users ON users.us_id = cart.ct_us_id
			LEFT JOIN products ON products.pd_id = cart.ct_pd_id
			WHERE ct_us_id = '".$_SESSION['id']."'";
			$lclResult1 = $con->query($lclQuery1);
				
			while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
				$cartDetails[] = $row1;
			}

			echo json_encode(array("cartDetails" => $cartDetails, "isLogin" => 1));

		} else if(isset($_SESSION['pd_cart_name'])) {
			for($i = 0; $i < count($_SESSION['pd_cart_name']); $i++) {

				$obj = (object) [
					'pd_cart_image' => $_SESSION['pd_cart_image'][$i],
					'pd_cart_name' => $_SESSION['pd_cart_name'][$i],
					'pd_cart_price' => $_SESSION['pd_cart_price'][$i],
					'pd_cart_quantity' => $_SESSION['pd_cart_quantity'][$i],
					'pd_cart_total_price' => $_SESSION['pd_cart_total_price'][$i]
				];
				$cartDetails[] = $obj;
			}

			echo json_encode(array("cartDetails" => $cartDetails, "isLogin" => 0));
		}
		
	}

	function deleteCart($params, $con) {

		$lclQuery = "DELETE FROM cart WHERE ct_id = '".$params['cartID']."'";
		$lclQuery = $con->query($lclQuery);
		echo "1";

	}

	function deleteCart1($params, $con) {

		unset($_SESSION['pd_cart_name'][$params['txtIndex']]);
		unset($_SESSION['pd_cart_price'][$params['txtIndex']]);
		unset($_SESSION['pd_cart_quantity'][$params['txtIndex']]);
		unset($_SESSION['pd_cart_color'][$params['txtIndex']]);
		unset($_SESSION['pd_cart_size'][$params['txtIndex']]);
		unset($_SESSION['pd_cart_total_price'][$params['txtIndex']]);
		unset($_SESSION['pd_cart_image'][$params['txtIndex']]);
		
		$_SESSION['pd_cart_name'] = array_values($_SESSION['pd_cart_name']);
		$_SESSION['pd_cart_price'] = array_values($_SESSION['pd_cart_price']);
		$_SESSION['pd_cart_quantity'] = array_values($_SESSION['pd_cart_quantity']);
		$_SESSION['pd_cart_color'] = array_values($_SESSION['pd_cart_color']);
		$_SESSION['pd_cart_size'] = array_values($_SESSION['pd_cart_size']);
		$_SESSION['pd_cart_total_price'] = array_values($_SESSION['pd_cart_total_price']);
		$_SESSION['pd_cart_image'] = array_values($_SESSION['pd_cart_image']);
		echo "1";

	}

	function updateCart($params, $con) {

		$sql = "SELECT * FROM cart 
		LEFT JOIN products ON products.pd_id = cart.ct_pd_id 
		WHERE ct_id = '".$params['cartID']."'";
		$res = $con->query($sql);
		$lclTotalAmount = 0;
		$lclAmount = 0;
		if($params['checkInput'] == 0) {

			if($row = $res->fetch(PDO::FETCH_ASSOC)) {
				$lclAmount = $row['pd_discount_price'];
				$lclQTY = $row['ct_qty'] - 1;
				$lclTotalAmount = $lclAmount * $lclQTY;
			}

			$lclQuery = "UPDATE cart SET ct_qty = ct_qty - 1
				WHERE ct_id = '".$params['cartID']."'";
			$lclResult = $con->query($lclQuery);

			echo -$lclAmount;

		} else {

			if($row = $res->fetch(PDO::FETCH_ASSOC)) {
				$lclAmount = $row['pd_discount_price'];
				$lclQTY = $row['ct_qty'] + 1;

				$lclTotalAmount = $lclAmount * $lclQTY;
			}
			$lclQuery = "UPDATE cart SET ct_qty = ct_qty + 1
				WHERE ct_id = '".$params['cartID']."'";
			$lclResult = $con->query($lclQuery);

			echo $lclAmount;
		}
		
	}

	function updateSessionCart($params) {
		if($params['checkInput'] == 0) {
			$_SESSION['pd_cart_quantity'][$params['cartID']] = $_SESSION['pd_cart_quantity'][$params['cartID']] - 1;
			$_SESSION['pd_cart_total_price'][$params['cartID']] = $_SESSION['pd_cart_price'][$params['cartID']] * $_SESSION['pd_cart_quantity'][$params['cartID']];
		} else {
			$_SESSION['pd_cart_quantity'][$params['cartID']] = $_SESSION['pd_cart_quantity'][$params['cartID']] + 1;
			$_SESSION['pd_cart_total_price'][$params['cartID']] = $_SESSION['pd_cart_price'][$params['cartID']] * $_SESSION['pd_cart_quantity'][$params['cartID']];
		}

		echo array_sum($_SESSION['pd_cart_total_price']);
		
	}

	function verifyOTP($params, $con) {

		$lclQueryExist1 = "SELECT count(*) FROM verify_otp WHERE vo_mobile = '".$_SESSION['otp-mobile']."' AND vo_otp = '".$params['txtOTP']."'";
    	$lclResultExist1 = $con->query($lclQueryExist1);
    	$lclResCount1 = $lclResultExist1->fetchColumn();

    	if($lclResCount1 > 0) {
			echo "1";
    	} else {
	        echo "10";
		}
	}

	function forgotPassword($params, $con, $UUID) {

		$user = "SELECT count(*) FROM users WHERE us_mobile = '".$params['txtMobileNo']."'";
		$userResult = $con->query($user);
    	$userResCount = $userResult->fetchColumn();

		if($userResCount > 0) {
			$lclQuery = "SELECT count(*) FROM verify_otp WHERE vo_mobile = '".$params['txtMobileNo']."'";
			$lclResult = $con->query($lclQuery);
			$lclResCount = $lclResult->fetchColumn();

			$_SESSION['otp-mobile'] = $params['txtMobileNo'];

			$username = "osfashionetwork@gmail.com";
			$apikey = "5aa722b394c14f799fb01cc6caa69375";
			$mobileNumber = $params['txtMobileNo'];
			$senderId = "OSFSNN";
			$message = "Dear client , Your One Time Password is ".$params['otp']." .One Step Fashion Network OSFSNN PEARLL";
			$smstype = "TRANS";
			$postData = array(
				'apikey' => $apikey,
				'numbers' => $mobileNumber ,
				'message' => $message ,
				'sender' => $senderId ,
				'smstype' => $smstype,
				
			);
			$url="http://sms.pearlsms.com/public/sms/send?";

			// init the resource
			$ch = curl_init();
			curl_setopt_array($ch, array(
				CURLOPT_URL => $url,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_POST => true,
				CURLOPT_POSTFIELDS => $postData
			));

			//Ignore SSL certificate verification
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

			//get response
			$output = curl_exec($ch);

			//Print error if any
			if(curl_errno($ch)) {
				echo 'error:' . curl_error($ch);
			}

			curl_close($ch);
			
			if($lclResCount > 0) {
				$lclUpdate = "UPDATE verify_otp SET vo_otp = '".$params['otp']."'
				WHERE vo_mobile = '".$params['txtMobileNo']."'";
				$lclRes = $con->query($lclUpdate);
			} else {
				
				$lclQuery1 = $con->prepare("INSERT INTO verify_otp (vo_id, vo_mobile, vo_otp) VALUES(:vo_id, :vo_mobile, :vo_otp)");

				$lclQuery1->bindParam(':vo_id', $UUID);
				$lclQuery1->bindParam(':vo_mobile', $params['txtMobileNo']);
				$lclQuery1->bindParam(':vo_otp', $params['otp']);

				$lclResult = $lclQuery1->execute();
			}

			echo "1";
		} else {
			echo "10";
		}
			
	}

	function resendOTP($params, $con) {

		$lclOTP = mt_rand(100000, 999999);

		$username = "osfashionetwork@gmail.com";
		$apikey = "5aa722b394c14f799fb01cc6caa69375";
		$mobileNumber = $_SESSION['otp-mobile'];
		$senderId = "OSFSNN";
		$message = "Dear client , Your One Time Password is ".$lclOTP." .One Step Fashion Network OSFSNN PEARLL";
		$smstype = "TRANS";
		$postData = array(
			'apikey' => $apikey,
			'numbers' => $mobileNumber ,
			'message' => $message ,
			'sender' => $senderId ,
			'smstype' => $smstype,
			
		);
		$url="http://sms.pearlsms.com/public/sms/send?";

		// init the resource
		$ch = curl_init();
		curl_setopt_array($ch, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $postData
		));

		//Ignore SSL certificate verification
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

		//get response
		$output = curl_exec($ch);

		//Print error if any
		if(curl_errno($ch)) {
			echo 'error:' . curl_error($ch);
		}

		curl_close($ch);
		$lclUpdate = "UPDATE verify_otp SET vo_otp = '".$lclOTP."'
		WHERE vo_mobile = '".$_SESSION['otp-mobile']."'";
		$lclRes = $con->query($lclUpdate);
		echo "1";

	}

	function updatePassword($params, $con) {
		$lclUpdate = "UPDATE users SET us_password = '".$params['txtPassword']."'
		WHERE us_mobile = '".$_SESSION['otp-mobile']."'";
		$lclRes = $con->query($lclUpdate);
		echo "1";
	}

	function saveNotification($params, $con) {
		$lclQueryExist1 = "SELECT count(*) FROM notification WHERE nt_email = '".$params['txtEmailNotification']."'";
    	$lclResultExist1 = $con->query($lclQueryExist1);
    	$lclResCount1 = $lclResultExist1->fetchColumn();

    	if($lclResCount1 == 1) {
    		echo "10";

    	} else {

			$lclQuery = $con->prepare("INSERT INTO notification (nt_email) VALUES(:nt_email)");
			$lclQuery->bindParam(':nt_email', $params['txtEmailNotification']);
			$lclResult = $lclQuery->execute();
			echo "1";
		}
	}

	function checkShippingCharges($params, $con) {

		$lclQuery = "SELECT * FROM area WHERE ar_name = '".$params['selArea']."'";
		$lclResult = $con->query($lclQuery);
			
		if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
			$lclDistance = $row['ar_distance'];
		}

		$lclQuery = "SELECT * FROM shipping_charges WHERE sc_distance_from = ".$lclDistance."";
		$lclResult = $con->query($lclQuery);
			
		if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
			echo $lclAmount = $row['sc_amount'];
		} else {
			echo "40";
		}
	}

	function getOrderDetails($params, $con) {
		if(isset($_SESSION['id'])) {
			$orderDetails = array();
			$lclQuery1 = "SELECT * FROM orders
			LEFT JOIN address ON orders.or_address_id = address.ads_id
			WHERE or_us_id = '".$_SESSION['id']."' ORDER BY or_created_date DESC";
			$lclResult1 = $con->query($lclQuery1);
				
			while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
				$orderDetails[] = $row1;
			}

			echo json_encode(array("orderDetails" => $orderDetails));

		} else {
			echo 10;
		}
	}

	function getMyProductDetails($params, $con) {

		$productDetails = array();
		$lclQuery1 = "SELECT * FROM purchased_products
		LEFT JOIN products ON purchased_products.pp_pd_id = products.pd_id
		WHERE pp_od_id = '".$params['orderID']."'";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$productDetails[] = $row1;
		}

		$orderDetails = array();
		$lclQuery2 = "SELECT * FROM orders
		LEFT JOIN address ON orders.or_address_id = address.ads_id
		LEFT JOIN state ON state.st_id = address.ads_state
		WHERE or_id = '".$params['orderID']."'";
		$lclResult2 = $con->query($lclQuery2);

		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$orderDetails[] = $row2;
		}

		echo json_encode(array("productDetails" => $productDetails, "orderDetails" => $orderDetails));
	}

	function getCheckoutDetails($params, $con) {
		
		$singleProducts = array();
		$lclQuery1 = "SELECT * FROM products WHERE pd_id = '".$params['product_id']."'";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$singleProducts[] = $row1;
		}

		$cartProducts = array();
		$lclQuery2 = "SELECT * FROM cart
		LEFT JOIN users ON cart.ct_us_id = users.us_id
		LEFT JOIN products ON cart.ct_pd_id = products.pd_id
		WHERE ct_us_id = '".$_SESSION['id']."'";
		$lclResult2 = $con->query($lclQuery2);
			
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$cartProducts[] = $row2;
		}

		$userAddress = array();
		$lclQuery3 = "SELECT * FROM address 
		LEFT JOIN state ON ads_state = st_id 
		WHERE ads_us_id = '" . $_SESSION['id'] . "' AND ads_active = 'Y'";
		$lclResult3 = $con->query($lclQuery3);

		while ($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$userAddress[] = $row3;
		}

		$userInfo = array();
		$lclQuery4 = "SELECT * FROM users WHERE us_id = '".$_SESSION['id']."'";
		$lclResult4 = $con->query($lclQuery4);
			
		while($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
			$userInfo[] = $row4;
		}

		$shippingCharges = array();
		$lclQuery5 = "SELECT * FROM shipping_charges";
		$lclResult5 = $con->query($lclQuery5);
			
		while($row5 = $lclResult5->fetch(PDO::FETCH_ASSOC)) {
			$shippingCharges[] = $row5;
		}

		$member = array();
		$lclQuery6 = "SELECT count(*) FROM users_plans WHERE up_us_id = '".$_SESSION['id']."'";
		$lclResult6 = $con->query($lclQuery6);
		$lclIsMember = $lclResult6->fetchColumn();
		
		$member = ($lclIsMember == 0) ? 0 : $lclIsMember;

		$checkHistory = "SELECT count(*) FROM member_coin_history WHERE mch_user_id = '".$_SESSION['id']."'";
		$checkHistoryRes = $con->query($checkHistory);
		$checkHistoryCount = $checkHistoryRes->fetchColumn();

		$coinUsage = ($checkHistoryCount >= 2) ? 0 : 1;

		echo json_encode(array("singleProducts" => $singleProducts, "cartProducts" => $cartProducts, "userAddress" => $userAddress, "userInfo" => $userInfo, "shippingCharges" => $shippingCharges, "member" => $member, "coinUsage" => $coinUsage));
	}

	function updatePayment($params, $con) {
		$lclUpdate = "UPDATE orders
		SET or_payment_status = 'SUCCESS',
			or_transaction_no = '".$params['transaction_id']."'
		WHERE or_us_id = '".$_SESSION['id']."' AND or_payment_status = 'PENDING' AND or_payment_type = 'Online'";
		$lclRes = $con->query($lclUpdate);
	}

	function getProfile($params, $con) {

		if (isset($_SESSION['id'])) {
			$userInfo = array();
			$lclQuery4 = "SELECT * FROM users WHERE us_id = '" . $_SESSION['id'] . "'";
			$lclResult4 = $con->query($lclQuery4);

			while ($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
				$userInfo[] = $row4;
			}

			$userAddress = array();
			$lclQuery3 = "SELECT * FROM address LEFT JOIN state ON ads_state = st_id WHERE ads_us_id = '" . $_SESSION['id'] . "'  AND ads_active = 'Y' ORDER BY ads_created_date desc";
			$lclResult3 = $con->query($lclQuery3);

			while ($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
				$userAddress[] = $row3;
			}

			$recursiveTopToBottomQuery = "WITH RECURSIVE company_hierarchy AS (
				SELECT    us_id,
							us_bv,
							us_name,
							us_mobile,
							us_referred_user_id,
						0 AS hierarchy_level
				FROM users
				WHERE us_id = '".$_SESSION['id']."'
				UNION ALL
				SELECT    u.us_id,
							u.us_bv,
							u.us_name,
							u.us_mobile,
							u.us_referred_user_id,
						hierarchy_level + 1
				FROM users u, company_hierarchy ch
				WHERE u.us_referred_user_id = ch.us_id
				)
				
				SELECT  
						SUM(ch.us_bv) AS empBV,
						ch.us_id AS employee_id,
						hierarchy_level
				FROM company_hierarchy ch
				LEFT JOIN users u
				ON ch.us_referred_user_id = u.us_id";

			$recursiveTopToBottomResult = $con->query($recursiveTopToBottomQuery);
			$totalBV = 0;
			if($recursiveTopToBottomRow = $recursiveTopToBottomResult->fetch(PDO::FETCH_ASSOC)) {
				$totalBV = $recursiveTopToBottomRow['empBV'];
			}

			echo json_encode(array("userInfo" => $userInfo, "userAddress" => $userAddress, "totalBV" => $totalBV));
		} else {
			echo 10;
		}
	}

	function updateProfile($params, $con) {
		$lclUpdate = "UPDATE users
		SET us_name = '".$params['txtName']."',
			us_email = '".$params['txtEmailID']."',
			us_blood_group = '".$params['selBloodGroup']."',
			us_designation = '".$params['txtDesignation']."'
		WHERE us_id = '".$_SESSION['id']."'";
		$lclRes = $con->query($lclUpdate);
		echo "1";
	}

	function addNewAddress($params, $con, $UUID) {
		
		$lclQuery1 = $con->prepare("INSERT INTO address (ads_id, ads_us_id, ads_fullName, ads_mobile_number,ads_address, ads_address2, ads_city, ads_state, ads_pincode) VALUES(:ads_id, :ads_us_id, :ads_fullName, :ads_mobile_number, :ads_address, :ads_address2, :ads_city, :ads_state, :ads_pincode)");
		$lclQuery1->bindParam(':ads_id', $UUID);
		$lclQuery1->bindParam(':ads_us_id', $_SESSION['id']);
		$lclQuery1->bindParam(':ads_fullName', $params['txtFullName']);
		$lclQuery1->bindParam(':ads_mobile_number', $params['txtMobileNo1']);
		$lclQuery1->bindParam(':ads_address', $params['txtAddress']);
		$lclQuery1->bindParam(':ads_address2', $params['txtAddress2']);
		$lclQuery1->bindParam(':ads_city', $params['txtCity']);
		$lclQuery1->bindParam(':ads_state', $params['txtState']);
		$lclQuery1->bindParam(':ads_pincode', $params['txtPincode']);


		$lclResult = $lclQuery1->execute();

		$userAddress = array();
		$lclQuery3 = "SELECT * FROM address LEFT JOIN state ON ads_state = st_id WHERE ads_us_id = '" . $_SESSION['id'] . "' AND ads_active = 'Y' ORDER BY ads_created_date desc";
		$lclResult3 = $con->query($lclQuery3);

		while ($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$userAddress[] = $row3;
		}

		echo json_encode(array("userAddress" => $userAddress));

	}


	function updateNewAddress($params, $con) {

		$lclQuery = $con->prepare("UPDATE address SET 
								ads_fullName = :ads_fullName,
								ads_mobile_number = :ads_mobile_number,
								ads_address = :ads_address,
								ads_address2 = :ads_address2,	
								ads_city = :ads_city,
								ads_state = :ads_state,
								ads_pincode = :ads_pincode
								WHERE ads_id = :ads_id");

		$lclQuery->bindParam(':ads_fullName', $params['txtFullName']);
		$lclQuery->bindParam(':ads_mobile_number', $params['txtMobileNo1']);
		$lclQuery->bindParam(':ads_address', $params['txtAddress']);
		$lclQuery->bindParam(':ads_address2', $params['txtAddress2']);
		$lclQuery->bindParam(':ads_city', $params['txtCity']);
		$lclQuery->bindParam(':ads_state', $params["txtState"]);
		$lclQuery->bindParam(':ads_pincode', $params["txtPincode"]);
		$lclQuery->bindParam(':ads_id', $params["txtId"]);
		$lclResult = $lclQuery->execute();
		
		$userAddress = array();
		$lclQuery3 = "SELECT * FROM address LEFT JOIN state ON ads_state = st_id WHERE ads_us_id = '" . $_SESSION['id'] . "'  AND ads_active = 'Y' ORDER BY ads_created_date desc";
		$lclResult3 = $con->query($lclQuery3);

		while ($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$userAddress[] = $row3;
		}

		echo json_encode(array("userAddress" => $userAddress));
	}

	function deleteAddress($params, $con) {
		$active = 'N';
		$lclQuery = $con->prepare("UPDATE address SET 
		ads_active = :ads_active
		WHERE ads_id = :ads_id");

		$lclQuery->bindParam(':ads_active', $active);
		$lclQuery->bindParam(':ads_id', $params['addressID']);

		$lclQuery->execute();

		$userAddress = array();
		$lclQuery3 = "SELECT * FROM address LEFT JOIN state ON ads_state = st_id WHERE ads_us_id = '" . $_SESSION['id'] . "' AND ads_active = 'Y' ORDER BY ads_created_date desc";
		$lclResult3 = $con->query($lclQuery3);

		while ($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$userAddress[] = $row3;
		}

		echo json_encode(array("userAddress" => $userAddress));
	}

	function getCollectionCartDetails($params, $con) {
		if(isset($_SESSION['id'])) {
			$cartDetails = array();
			$lclQuery1 = "SELECT * FROM cart
			LEFT JOIN users ON users.us_id = cart.ct_us_id
			LEFT JOIN products ON products.pd_id = cart.ct_pd_id
			WHERE ct_us_id = '".$_SESSION['id']."'";
			$lclResult1 = $con->query($lclQuery1);
				
			while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
				$cartDetails[] = $row1;
			}

			$category = array();
			$lclQuery2 = "SELECT ca_id, ca_name FROM categories";
			$lclResult2 = $con->query($lclQuery2);
				
			while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
				$category[] = $row2;
			}

			$users = array();
			$lclQuery3 = "SELECT us_name FROM users WHERE us_id = '".$_SESSION['id']."'";
			$lclResult3 = $con->query($lclQuery3);
				
			while($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
				$users[] = $row3;
			}

			echo json_encode(array("cartDetails" => $cartDetails, "category" => $category, "users" => $users, "isLogin" => 1));
		} else {
			$category = array();
			$lclQuery2 = "SELECT * FROM categories";
			$lclResult2 = $con->query($lclQuery2);
				
			while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
				$category[] = $row2;
			}

			echo json_encode(array("category" => $category, "isLogin" => 0));
		}
	}

	function addReview($params, $con, $UUID){
		if(isset($_SESSION['id'])) {
			$lclQueryExist1 = "SELECT count(*) FROM reviews WHERE rv_us_id = '".$_SESSION['id']."' AND rv_pd_id = '".$params['productId']."'";
			$lclResultExist1 = $con->query($lclQueryExist1);
			$lclResCount1 = $lclResultExist1->fetchColumn();

			if($lclResCount1 == 1) {
				echo "11";
			} else {
				$lclQuery = $con->prepare("INSERT INTO reviews (rv_id, rv_us_id, rv_pd_id, rv_rating, rv_name, rv_email, rv_review) VALUES(:rv_id,:rv_us_id, :rv_pd_id, :rv_rating, :rv_name, :rv_email, :rv_review)");
				$lclQuery->bindParam(':rv_id', $UUID);
				$lclQuery->bindParam(':rv_us_id', $_SESSION['id']);
				$lclQuery->bindParam(':rv_pd_id', $params['productId']);
				$lclQuery->bindParam(':rv_rating', $params['rating']);
				$lclQuery->bindParam(':rv_name', $params['txtName']);
				$lclQuery->bindParam(':rv_email', $params['txtEmail']);
				$lclQuery->bindParam(':rv_review', $params['comment']);
				$lclResult = $lclQuery->execute();
				echo "1";
			}
		}else{
			echo 10;
		}
	}

	function getReview($params, $con) {
		$reviews = array();
		$lclQuery = "SELECT * FROM reviews WHERE  rv_pd_id = '".$params['productId']."' AND rv_status = 0";
		$lclQuery1 = "SELECT COUNT(*) FROM reviews WHERE rv_pd_id = '".$params['productId']."' AND rv_status = 0";

		$lclResult = $con->query($lclQuery);
		$lclResult1 = $con->query($lclQuery1);
		$lclReviewCount = $lclResult1->fetchColumn();


		while($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
			$reviews[] = $row;
		}
		echo json_encode(array("reviews" => $reviews, "count" => $lclReviewCount));
	}
?>
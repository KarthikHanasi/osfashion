<?php
	session_start();
	// error_reporting(0);
	include_once('../conn/conn.php');
	include_once('../admin/backend/generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();

	require '../admin/backend/vendor/autoload.php';
	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;

	switch ($action) {

		case 'get_plans':
			getPlans($params, $con);
			break;

        case 'new_member':
			newMember($params, $con, $UUID);
			break;

		case 'add_aadhar':
			addAadhar($params, $con, $UUID);
			break;
	
		case 'add_pan':
			addPan($params, $con, $UUID);
			break;
	
		case 'add_bank':
			addBank($params, $con, $UUID);
			break;
	
		case 'get_kyc_details':
			getKycDetails($params, $con);
			break;

		case 'get_user_details':
			getUserDetails($params, $con);
			break;
	
		case 'get_user_heirarchy_details':
			getUserHeirarchyDetails($params, $con);
			break;
        
    }

    function getPlans($params, $con) {
		$planDetails = array();
		$lclQuery1 = "SELECT * FROM plans ORDER BY pl_amount ASC";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$planDetails[] = $row1;
		}

		echo json_encode(array("planDetails" => $planDetails));
	}

	function newMember($params, $con, $UUID) {
		if(!isset($_SESSION['id'])) {
			echo "20";
		} else {
			$lclQueryExist1 = "SELECT count(*) FROM users_plans WHERE up_us_id = '".$_SESSION['id']."'";
			$lclResultExist1 = $con->query($lclQueryExist1);
			$lclResCount1 = $lclResultExist1->fetchColumn();

			if($lclResCount1 < 1) {
				$lclQuery = $con->prepare("INSERT INTO users_plans (up_id, up_us_id, up_pl_id) VALUES(:up_id, :up_us_id, :up_pl_id)");
				$lclQuery->bindParam(':up_id', $UUID);
				$lclQuery->bindParam(':up_us_id', $_SESSION['id']);
				$lclQuery->bindParam(':up_pl_id', $params['planID']);
				$lclResult = $lclQuery->execute();

				$lclQuery1 = "SELECT * FROM plans WHERE pl_id = '".$params['planID']."'";
				$lclResult1 = $con->query($lclQuery1);

				if($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
					$lclTotalCoins = $row1['pl_amount'] * 2;
					$lclRefCode = substr($UUID, 0, 6);
					$_SESSION['referral_code'] = $lclRefCode;
					$lclUpdate = "UPDATE users
					SET us_coins = us_coins + ".$lclTotalCoins.",
					us_coins_usage = us_coins_usage + ".$lclTotalCoins.",
					us_referral_code = '".$lclRefCode."'
					WHERE us_id = '".$_SESSION['id']."'";
					$lclRes = $con->query($lclUpdate);
					
					$userDetails = "SELECT * FROM users WHERE us_id = '".$_SESSION['id']."' AND us_referred_user_id IS NOT NULL";
					$lclResult = $con->query($userDetails);
	
					if($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {

						// check top level user with only one above level
						$recursiveQuery = "WITH RECURSIVE company_hierarchy AS (
							SELECT   us_id,
									  us_name,
									  us_mobile,
									  us_referred_user_id,
								   1 AS hierarchy_level
							FROM users
							WHERE us_id = '".$_SESSION['id']."'
							UNION ALL
							SELECT    u.us_id,
									  u.us_name,
									  u.us_mobile,
									  u.us_referred_user_id,
								  hierarchy_level + 1
							FROM users u, company_hierarchy ch
							WHERE u.us_id = ch.us_referred_user_id
						  )
						   
						  SELECT ch.us_name AS employee_name,
								 ch.us_mobile AS employee_mobile,
								 u.us_id AS main_id,
								 u.us_name AS main_name,
								 u.us_mobile AS main_mobile,
								 hierarchy_level
						  FROM company_hierarchy ch
						  LEFT JOIN users u
						  ON ch.us_referred_user_id = u.us_id
						  ORDER BY ch.hierarchy_level ASC LIMIT 1";
			
						$recursiveResult = $con->query($recursiveQuery);
						
						while($recursiveRow = $recursiveResult->fetch(PDO::FETCH_ASSOC)) {

							if($recursiveRow['main_id'] != "") {
								$levelUUID = guidv4();
								$lclQuery = $con->prepare("INSERT INTO level_information (li_id, li_main_user_id, li_user_id, li_level_count) VALUES(:li_id, :li_main_user_id, :li_user_id, :li_level_count)");
		
								$lclQuery->bindParam(':li_id', $levelUUID);
								$lclQuery->bindParam(':li_main_user_id', $recursiveRow['main_id']);
								$lclQuery->bindParam(':li_user_id', $_SESSION['id']);
								$lclQuery->bindParam(':li_level_count', $recursiveRow['hierarchy_level']);
								$lclResult = $lclQuery->execute();

								// history of credits
								$achType = 'coin_credits';
								$amountHistoryUUID = guidv4();
								$addingAmount = ($row1['pl_amount'] * $row1['pl_percentage'])/100;
								$insertAmountHistory = $con->prepare("INSERT INTO amount_credit_history (ach_id, ach_us_id, ach_main_id, ach_percentage, ach_level, ach_amount, ach_type) VALUES(:ach_id, :ach_us_id, :ach_main_id, :ach_percentage, :ach_level, :ach_amount, :ach_type)");

								$insertAmountHistory->bindParam(':ach_id', $amountHistoryUUID);
								$insertAmountHistory->bindParam(':ach_us_id', $_SESSION['id']);
								$insertAmountHistory->bindParam(':ach_main_id', $recursiveRow['main_id']);
								$insertAmountHistory->bindParam(':ach_percentage', $row1['pl_percentage']);
								$insertAmountHistory->bindParam(':ach_level', $recursiveRow['hierarchy_level']);
								$insertAmountHistory->bindParam(':ach_amount', $addingAmount);
								$insertAmountHistory->bindParam(':ach_type', $achType);
								$insertAmountHistory->execute();

								$lclUpdate = "UPDATE users
								SET us_coins = us_coins + ".$addingAmount.",
								us_coins_usage = us_coins_usage + ".$addingAmount."
								WHERE us_id = '".$recursiveRow['main_id']."'";
								$lclRes = $con->query($lclUpdate);
							}

							$mainUser = "SELECT * FROM users WHERE us_id = '".$recursiveRow['main_id']."'";
							$mainUserResult = $con->query($mainUser);

							if($mainRow = $mainUserResult->fetch(PDO::FETCH_ASSOC)) {
								$newLevel = $mainRow['us_level'] + 1;
								$lclCheckLevelComplete = "SELECT count(*) FROM level_information WHERE li_main_user_id = '".$recursiveRow['main_id']."' AND li_level_count = '".$newLevel."' AND li_status = 'CREATED'";
								$lclCheckLevelCompleteRes = $con->query($lclCheckLevelComplete);
								$lclCheckLevelCompleteCount = $lclCheckLevelCompleteRes->fetchColumn();

								$lvlCount = "SELECT * FROM levels_count WHERE lvl_level = ".$recursiveRow['hierarchy_level']."";
								$lvlCountRes = $con->query($lvlCount);

								if($lvlRow = $lvlCountRes->fetch(PDO::FETCH_ASSOC)) {
									if($lclCheckLevelCompleteCount == $lvlRow['lvl_level_count']) {

										// if Level Completed then execute this
										$lclUpdate = "UPDATE users SET us_level = us_level + 1
										WHERE us_id = '".$recursiveRow['main_id']."'";
										$con->query($lclUpdate);
									
									}

								}

							}
					}
				}

			}

				echo "1";
			} else {
				echo "10";
			}
		}
	}

	function addAadhar($params, $con, $UUID) {
	if (isset($_SESSION['id'])) {
		$data = file_get_contents($_FILES["uploadAadharFile"]["tmp_name"]);
		$base64 = 'data:image/png;base64,' . base64_encode($data);
		$base64_str = substr($base64, strpos($base64, ",") + 1);
		$image = base64_decode($base64_str);

		$s3Client = new S3Client([
			'version' => '2006-03-01',
			'region' => "us-east-1",
			'credentials' => [
				'key' => 'AKIAQI3REVFIUJ7P6ZX3',
				'secret' => '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'
			]
		]);

		$bucket = 'multimediastorage124243-dev';
		$key1 = "Aadhar" . $_SESSION['id'] . ".png";

		try {
			$result1 = $s3Client->putObject([
				'Bucket' => $bucket,
				'Key' => $key1,
				'Body' => $image,
				'ACL' => 'public-read', // make file 'public'
			]);
			// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
			$imageURL = $result1->get('ObjectURL');
		} catch (Aws\S3\Exception\S3Exception $e) {
			echo "There was an error uploading the file.\n";
			echo $e->getMessage();
		}
		$lclQuery = "SELECT * FROM  kyc WHERE user_id = '" . $_SESSION['id'] . "' AND is_active = 'Y'";
		$lclResult = $con->query($lclQuery);

		if ($lclResult->rowCount() > 0) {
			$lclQuery = $con->prepare("UPDATE kyc SET 
							  aadhar_number = :aadhar_number,
							  aadhar_file = :aadhar_file
							  WHERE user_id = :user_id");


			$lclQuery->bindParam(':aadhar_number', $params['txtAadharNumber']);
			$lclQuery->bindParam(':aadhar_file', $imageURL);
			$lclQuery->bindParam(':user_id', $_SESSION['id']);
			$lclResult = $lclQuery->execute();
			echo "1";
		} else {
			$sql = $con->prepare("INSERT INTO kyc (id, aadhar_number, aadhar_file, user_id) VALUES(:id, :aadhar_number, :aadhar_file, :user_id)");
			$sql->bindParam(':id', $UUID);
			$sql->bindParam(':aadhar_number', $params['txtAadharNumber']);
			$sql->bindParam(':aadhar_file', $imageURL);
			$sql->bindParam(':user_id', $_SESSION['id']);
			$lclResult = $sql->execute();
			echo "1";
		}
	}
}

function addBank($params, $con, $UUID)
{
	if (isset($_SESSION['id'])) {
		$data = file_get_contents($_FILES["uploadBankFile"]["tmp_name"]);
		$base64 = 'data:image/png;base64,' . base64_encode($data);
		$base64_str = substr($base64, strpos($base64, ",") + 1);
		$image = base64_decode($base64_str);

		$s3Client = new S3Client([
			'version' => '2006-03-01',
			'region' => "us-east-1",
			'credentials' => [
				'key' => 'AKIAQI3REVFIUJ7P6ZX3',
				'secret' => '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'
			]
		]);

		$bucket = 'multimediastorage124243-dev';
		$key1 = "bank" . $_SESSION['id'] . ".png";

		try {
			$result1 = $s3Client->putObject([
				'Bucket' => $bucket,
				'Key' => $key1,
				'Body' => $image,
				'ACL' => 'public-read', // make file 'public'
			]);
			// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
			$imageURL = $result1->get('ObjectURL');
		} catch (Aws\S3\Exception\S3Exception $e) {
			echo "There was an error uploading the file.\n";
			echo $e->getMessage();
		}
		$lclQuery = "SELECT * FROM  kyc WHERE user_id = '" . $_SESSION['id'] . "' AND is_active = 'Y'";
		$lclResult = $con->query($lclQuery);

		if ($lclResult->rowCount() > 0) {
			$lclQuery = $con->prepare("UPDATE kyc SET 
							  bank_number = :bank_number,
							  bank_name = :bank_name,
							  bank_user_name = :bank_user_name,
							  bank_ifsc_code = :bank_ifsc_code,
							  bank_file = :bank_file
							  WHERE user_id = :user_id");

			$lclQuery->bindParam(':bank_number', $params['txtBankNumber']);
			$lclQuery->bindParam(':bank_name', $params['txtBankName']);
			$lclQuery->bindParam(':bank_user_name', $params['txtBankUserName']);
			$lclQuery->bindParam(':bank_ifsc_code', $params['txtBankIfsc']);
			$lclQuery->bindParam(':bank_file', $imageURL);
			$lclQuery->bindParam(':user_id', $_SESSION['id']);
			$lclResult = $lclQuery->execute();
			echo "1";
		} else {
			$sql = $con->prepare("INSERT INTO kyc (id, bank_number, bank_name, bank_user_name, bank_ifsc_code, bank_file, user_id) VALUES(:id, :bank_number, :bank_name, :bank_user_name, :bank_ifsc_code, :bank_file, :user_id)");
			$sql->bindParam(':id', $UUID);
			$sql->bindParam(':bank_number', $params['txtBankNumber']);
			$sql->bindParam(':bank_name', $params['txtBankName']);
			$sql->bindParam(':bank_user_name', $params['txtBankUserName']);
			$sql->bindParam(':bank_ifsc_code', $params['txtBankIfsc']);
			$sql->bindParam(':bank_file', $imageURL);
			$sql->bindParam(':user_id', $_SESSION['id']);
			$lclResult = $sql->execute();
			echo "1";
		}
	}
}


function addPan($params, $con, $UUID) {
	if (isset($_SESSION['id'])) {
		$data = file_get_contents($_FILES["uploadPanFile"]["tmp_name"]);
		$base64 = 'data:image/png;base64,' . base64_encode($data);
		$base64_str = substr($base64, strpos($base64, ",") + 1);
		$image = base64_decode($base64_str);

		$s3Client = new S3Client([
			'version' => '2006-03-01',
			'region' => "us-east-1",
			'credentials' => [
				'key' => 'AKIAQI3REVFIUJ7P6ZX3',
				'secret' => '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'
			]
		]);

		$bucket = 'multimediastorage124243-dev';
		$key1 = "Pan" . $_SESSION['id'] . ".png";

		try {
			$result1 = $s3Client->putObject([
				'Bucket' => $bucket,
				'Key' => $key1,
				'Body' => $image,
				'ACL' => 'public-read', // make file 'public'
			]);
			// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
			$imageURL = $result1->get('ObjectURL');
		} catch (Aws\S3\Exception\S3Exception $e) {
			echo "There was an error uploading the file.\n";
			echo $e->getMessage();
		}
		$lclQuery = "SELECT * FROM  kyc WHERE user_id = '" . $_SESSION['id'] . "' AND is_active = 'Y'";
		$lclResult = $con->query($lclQuery);

		if ($lclResult->rowCount() > 0) {
			$lclQuery = $con->prepare("UPDATE kyc SET 
							  pan_number = :pan_number,
							  pan_file = :pan_file
							  WHERE user_id = :user_id");

			$lclQuery->bindParam(':pan_number', $params['txtPanNumber']);
			$lclQuery->bindParam(':pan_file', $imageURL);
			$lclQuery->bindParam(':user_id', $_SESSION['id']);
			$lclResult = $lclQuery->execute();
			echo "1";
		} else {
			$sql = $con->prepare("INSERT INTO kyc (id,pan_number, pan_file, user_id) VALUES(:id,:pan_number, :pan_file, :user_id)");
			$sql->bindParam(':id', $UUID);
			$sql->bindParam(':pan_number', $params['txtPanNumber']);
			$sql->bindParam(':pan_file', $imageURL);
			$sql->bindParam(':user_id', $_SESSION['id']);
			$lclResult = $sql->execute();
			echo "1";
		}
	}
}

function getKycDetails($params, $con) {
	if (isset($_SESSION['id'])) {
		$kyc_details = array();
		$lclQuery = "SELECT * FROM  kyc WHERE user_id = '" . $_SESSION['id'] . "' AND is_active = 'Y'";
		$lclResult = $con->query($lclQuery);
		while ($row = $lclResult->fetch(PDO::FETCH_ASSOC)) {
			$kyc_details[] = $row;
		}
		echo json_encode(array("kyc_details" => $kyc_details));
	} else {
		return 10;
	}
}


function getUserDetails($params, $con)
{

	if (isset($_SESSION['id'])) {
		$userInfo = array();
		$lclQuery4 = "SELECT * FROM users WHERE us_id = '" . $params['txtId'] . "'";
		$lclResult4 = $con->query($lclQuery4);

		while ($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
			$userInfo[] = $row4;
		}

		$userAddress = array();
		$lclQuery3 = "SELECT * FROM address LEFT JOIN state ON ads_state = st_id WHERE ads_us_id = '" . $params['txtId'] . "'  AND ads_active = 'Y' ORDER BY ads_created_date desc";
		$lclResult3 = $con->query($lclQuery3);

		while ($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$userAddress[] = $row3;
		}

		echo json_encode(array("userInfo" => $userInfo, "userAddress" => $userAddress));
	} else {
		echo 10;
	}
}


function getUserHeirarchyDetails($params, $con)
{

	$treeView = array();

	$recursiveTopToBottomQuery = "WITH RECURSIVE company_hierarchy AS (
		SELECT    us_id,
					us_name,
					us_mobile,
					us_referred_user_id,
					us_referral_code,
				0 AS hierarchy_level
		FROM users
		WHERE us_id = '" . $params['txtId'] . "'
		UNION ALL
		SELECT    u.us_id,
					u.us_name,
					u.us_mobile,
					u.us_referred_user_id,
					u.us_referral_code,
				hierarchy_level + 1
		FROM users u, company_hierarchy ch
		WHERE u.us_referred_user_id = ch.us_id
		)
		
		SELECT  ch.us_id AS employee_id,
				ch.us_name AS name,
				ch.us_referral_code AS title,
				ch.us_mobile AS employee_mobile,
				u.us_id AS main_id,
				u.us_name AS main_name,
				u.us_mobile AS main_mobile,
				hierarchy_level
		FROM company_hierarchy ch
		LEFT JOIN users u
		ON ch.us_referred_user_id = u.us_id
		ORDER BY ch.hierarchy_level, ch.us_id;";

	$recursiveTopToBottomResult = $con->query($recursiveTopToBottomQuery);
	$count = 0;
	while ($recursiveTopToBottomRow = $recursiveTopToBottomResult->fetch(PDO::FETCH_ASSOC)) {
		if ($count == 0) {

			$recursiveTopToBottomRow['main_id'] = null;
			$recursiveTopToBottomRow['main_name'] = null;
			$recursiveTopToBottomRow['main_mobile'] = null;
			$treeView[] = $recursiveTopToBottomRow;
		} else {
			$treeView[] = $recursiveTopToBottomRow;
		}
		$count++;

	}

	echo json_encode($treeView);
}
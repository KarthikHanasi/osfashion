<?php
	session_start();
	// error_reporting(0);
	include_once('../conn/conn.php');
	include_once('../admin/backend/generate_uuid.php');
	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();
	require '../admin/backend/vendor/autoload.php';
	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;

	switch ($action) {

		case 'get_company_compliance':
			getCompanyCompliance($params, $con);
			break;

        case 'get_networking_business_plans':
			getNetworkingBusinessPlans($params, $con, $UUID);
			break;

		case 'get_business_ranks_history':
			getBusinessRanksDetails($params, $con);
			break;

		case 'return_order':
			returnOrder($params, $con, $UUID);
			break;

		case 'get_mynetwork_refid':
			getMyNetworkRefID($params, $con);
			break;

		case 'get_withdrawals':
			getWithdrawals($params, $con);
			break;

		case 'search_my_withdrawals':
			searchMyWithdrawals($params, $con);
			break;

		case 'get_id_card':
			getIdCard($params, $con);
			break;
	
		case 'upload_image':
			uploadImage($params, $con);
			break;
	
		case 'get_image':
			getImage($params, $con);
			break;

		case 'contact':
			saveContact($params, $con, $UUID);
			break;
        
    }

    function getCompanyCompliance($params, $con) {
		$details = array();
		$lclQuery1 = "SELECT * FROM company_compliance";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$details[] = $row1;
		}

		echo json_encode(array("details" => $details));
	}

    function getNetworkingBusinessPlans($params, $con) {
		$details = array();
		$lclQuery1 = "SELECT * FROM network_business_plan";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$details[] = $row1;
		}

		echo json_encode(array("details" => $details));
	}
	
	function getBusinessRanksDetails($params, $con) {
		$creditHistoryArray = array();
		$creditHistory = "SELECT * FROM amount_credit_history
		LEFT JOIN users ON users.us_id = amount_credit_history.ach_us_id
		LEFT JOIN rank_history ON rank_history.rh_us_id = users.us_id
		LEFT JOIN business_ranks ON business_ranks.br_id = rank_history.rh_br_id
		WHERE (ach_main_id = '".$_SESSION['id']."') AND ach_type = 'business_rank' ORDER BY amount_credit_history.ach_created_date ASC";
		$creditHistoryResult = $con->query($creditHistory);

		while($creditHistoryRow = $creditHistoryResult->fetch(PDO::FETCH_ASSOC)) {
			$creditHistoryArray[] = $creditHistoryRow;
		}

		echo json_encode(array("creditHistoryArray" => $creditHistoryArray));
	}


	function returnOrder($params, $con, $UUID) {

		$orderUser = "SELECT * FROM purchased_products WHERE pp_id = '".$params['productID']."' AND pp_order_status != 'RETURNED'";
		$orderUserResult = $con->query($orderUser);

		if($orderUserRow = $orderUserResult->fetch(PDO::FETCH_ASSOC)) {

			$sql = "SELECT *, pd_name as name, pd_product_id as sku, pp_qty as qty, pp_pd_price as price FROM purchased_products
					LEFT JOIN orders ON orders.or_id = purchased_products.pp_od_id
					LEFT JOIN address ON address.ads_id = orders.or_address_id
					LEFT JOIN state ON state.st_id = address.ads_state
					LEFT JOIN products ON products.pd_id = purchased_products.pp_pd_id
					WHERE pp_id = '".$params['productID']."'";
			$result = $con->query($sql);

			if($orderReturnUserRow = $result->fetch(PDO::FETCH_ASSOC)) {

				$lclRegDate = new DateTime(date('Y-m-d', strtotime($orderReturnUserRow['pp_created_at'])));
				$lclOrderDate = new DateTime(date('Y-m-d'));
				$abs_diff = $lclOrderDate->diff($lclRegDate)->format("%a");
				// echo $abs_diff;
				$orderReturnDays = "SELECT * FROM order_return_days";
				$orderReturnDaysResult = $con->query($orderReturnDays);

				if($orderReturnDaysRow = $orderReturnDaysResult->fetch(PDO::FETCH_ASSOC)) {
					$returnDays = $orderReturnDaysRow['ord_days'];
				}

				if($abs_diff <= $returnDays) {

					$returnReason = $con->prepare("INSERT INTO return_reason (rt_id, rt_pd_id, rt_us_id, rt_reason) VALUES(:rt_id, :rt_pd_id, :rt_us_id, :rt_reason)");

					$returnReason->bindParam(':rt_id', $UUID);
					$returnReason->bindParam(':rt_pd_id', $params['productID']);
					$returnReason->bindParam(':rt_us_id', $_SESSION['id']);
					$returnReason->bindParam(':rt_reason', $params['txtReason']);
					$returnReason->execute();


					$apiToken = "SELECT * FROM delivery_api_token";
					$apiTokenRes = $con->query($apiToken);

					if($apiTokenRow = $apiTokenRes->fetch(PDO::FETCH_ASSOC)) {
						$datetime_1 = $apiTokenRow['dlt_updated_at'];
						$datetime_2 = date('Y-m-d H:i:s');
						
						$from_time = strtotime($datetime_1); 
						$to_time = strtotime($datetime_2); 
						$diff_minutes = round(abs($from_time - $to_time) / 60, 2);

						$token = $apiTokenRow['dlt_token'];

						if($diff_minutes > 160) {
							$curl = curl_init();

							curl_setopt_array($curl, array(
							CURLOPT_URL => 'https://api.nimbuspost.com/v1/users/login',
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_ENCODING => '',
							CURLOPT_MAXREDIRS => 10,
							CURLOPT_TIMEOUT => 0,
							CURLOPT_FOLLOWLOCATION => true,
							CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
							CURLOPT_CUSTOMREQUEST => 'POST',
							CURLOPT_POSTFIELDS =>'{
								"email" : "'.$apiTokenRow['dlt_email'].'",
								"password" : "'.$apiTokenRow['dlt_password'].'"
							}',
								CURLOPT_HTTPHEADER => array(
									'content-type: application/json'
								),
							));

							$response = curl_exec($curl);

							curl_close($curl);
							$res = (array)($response);
							$a = $destination_array = explode('"', $res[0]);
							$token = $a[5];

							$lclUpdate = "UPDATE delivery_api_token SET dlt_token = '".$token."',
																		dlt_updated_at = '".date('Y-m-d H:i:s')."'";
							$con->query($lclUpdate);

						}

					}

					$obj = '{
						"order_number": "'.$orderReturnUserRow['or_readable_id'].'",
						"shipping_charges": "'.$orderReturnUserRow['or_shipping_charges'].'",
						"discount": 0,
						"cod_charges": 0,
						"payment_type": "reverse",
						"order_amount": "'.$orderReturnUserRow['or_sub_total'].'",
						"request_auto_pickup" : "yes",
						"consignee": {
							"name": "'.$orderReturnUserRow['ads_fullName'].'",
							"address": "'.$orderReturnUserRow['ads_address'].'",
							"address_2": "",
							"city": "'.$orderReturnUserRow['ads_city'].'",
							"state": "'.$orderReturnUserRow['st_name'].'",
							"pincode": "'.$orderReturnUserRow['ads_pincode'].'",
							"phone": "'.$orderReturnUserRow['ads_mobile_number'].'"
						},
		
						"pickup": {
							"warehouse_name": "Os Fashion",
							"name" : "Os Fashion",
							"address": "OS Fashion, 2nd floor, Bharti Sankul, Above RBL bank, club road",
							"address_2": "",
							"city": "Belagavi",
							"state": "Karnataka",
							"pincode": "590001",
							"phone": "9845301177"
						},
						"order_items": [
							{
								"name": "'.$orderReturnUserRow['name'].'",
								"qty": "'.$orderReturnUserRow['qty'].'",
								"price": "'.$orderReturnUserRow['price'].'",
								"sku": "'.$orderReturnUserRow['sku'].'"
							}
						],
		
						"courier_id" : "93",
						  "is_insurance" : "0",
						  "tags" : ""
					}';
		
					
					$curl = curl_init();
					curl_setopt_array($curl, array(
						CURLOPT_URL => 'https://api.nimbuspost.com/v1/shipments',
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => '',
						CURLOPT_MAXREDIRS => 10,
						CURLOPT_TIMEOUT => 0,
						CURLOPT_FOLLOWLOCATION => true,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => 'POST',
						CURLOPT_POSTFIELDS => $obj,
						CURLOPT_HTTPHEADER => array(
						  'Content-Type: application/json',
						  "Authorization: Bearer ".$token
						),
					  ));
					  
					  $response = curl_exec($curl);
					  
					  $res = json_decode(utf8_encode($response), true);

					$lclOrder = "UPDATE purchased_products SET pp_order_status = 'RETURNED'
					WHERE pp_id = '".$params['productID']."'";
					$con->query($lclOrder);

					echo "1";
					  
				// }
				} else {
					echo "10";
				}
				
			}

		} else {
			echo "20";
		}
		
	}


	function getMyNetworkRefID($params, $con) {
		$details = array();
		$lclQuery1 = "SELECT * FROM users 
		WHERE us_referral_code = '".$params['refId']."'";
		$lclResult1 = $con->query($lclQuery1);

		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$details[] = $row1;
		}

		$details2 = array();
		$lclQuery2 = "SELECT * FROM users 
		WHERE us_id = '".$details[0]['us_referred_user_id']."'";
		$lclResult2 = $con->query($lclQuery2);
		
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$details2[] = $row2;
		}

		echo json_encode(array("details" => $details, "details2" => $details2));
	}

	function getWithdrawals($params, $con) {
		$withdrawalsDetails = array();
		$lclQuery1 = "SELECT * FROM withdrawals
		LEFT JOIN users ON users.us_id = withdrawals.wt_us_id
		LEFT JOIN kyc ON kyc.id = withdrawals.wt_kyc_id
		WHERE wt_us_id = '".$_SESSION['id']."'";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$withdrawalsDetails[] = $row1;
		}

		echo json_encode(array("withdrawalsDetails" => $withdrawalsDetails));
	}

	function searchMyWithdrawals($params, $con) {
		$toDate = date('Y-m-d', strtotime($params['toDate'] . ' +1 day'));
		$withdrawalsDetails = array();
		$withdrawals = "SELECT * FROM withdrawals
		LEFT JOIN users ON users.us_id = withdrawals.wt_us_id
		LEFT JOIN kyc ON kyc.id = withdrawals.wt_kyc_id
		WHERE wt_payment_date BETWEEN '".$params['fromDate']."' AND '".$toDate."' AND wt_us_id = '".$_SESSION['id']."'";
		$withdrawalsResult = $con->query($withdrawals);

		while($withdrawalsRow = $withdrawalsResult->fetch(PDO::FETCH_ASSOC)) {
			$withdrawalsDetails[] = $withdrawalsRow;
		}

		echo json_encode(array("withdrawalsDetails" => $withdrawalsDetails));
	}

	function getIdCard($params, $con) {
		if (isset($_SESSION['id'])) {
			$userInfo = array();
			$lclQuery4 = "SELECT * FROM users WHERE us_id = '" . $_SESSION['id'] . "'";
			$lclResult4 = $con->query($lclQuery4);

			while ($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
				$userInfo[] = $row4;
			}
			echo json_encode(array("userInfo" => $userInfo));
		} else {
			echo "10";
		}
	}

	function uploadImage($params, $con) {
		if (isset($_SESSION['id'])) {
			$data = file_get_contents($_FILES["uploadProfileImage"]["tmp_name"]);
			$base64 = 'data:image/png;base64,' . base64_encode($data);
			$base64_str = substr($base64, strpos($base64, ",") + 1);
			$image = base64_decode($base64_str);

			$s3Client = new S3Client([
				'version' => '2006-03-01',
				'region' => "us-east-1",
				'credentials' => [
					'key' => 'AKIAQI3REVFIUJ7P6ZX3',
					'secret' => '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'
				]
			]);

			$bucket = 'multimediastorage124243-dev';
			$key1 = "/profile/Profile" . $_SESSION['id'] . ".png";

			try {
				$result1 = $s3Client->putObject([
					'Bucket' => $bucket,
					'Key' => $key1,
					'Body' => $image,
					'ACL' => 'public-read', // make file 'public'
				]);
				// echo "Image uploaded successfully. Image path is: ". $result->get('ObjectURL');
				$imageURL = $result1->get('ObjectURL');
			} catch (Aws\S3\Exception\S3Exception $e) {
				echo "There was an error uploading the file.\n";
				echo $e->getMessage();
			}

			$lclQuery = $con->prepare("UPDATE users SET 
			us_image = :us_image
			WHERE us_id = :us_id");

			$lclQuery->bindParam(':us_image', $imageURL);
			$lclQuery->bindParam(':us_id', $_SESSION['id']);
			$lclResult = $lclQuery->execute();
			// echo $lclResult;
			echo $imageURL;
		} else {
			echo "10";
		}

	}

	function getImage($params, $con) {
		if (isset($_SESSION['id'])) {
			$userInfo = array();
			$lclQuery4 = "SELECT * FROM users WHERE us_id = '" . $_SESSION['id'] . "'";
			$lclResult4 = $con->query($lclQuery4);

			while ($row4 = $lclResult4->fetch(PDO::FETCH_ASSOC)) {
				$userInfo[] = $row4;
			}
			echo json_encode(array("userInfo" => $userInfo));
		} else {
			echo "10";
		}
	}


	function saveContact($params, $con, $UUID) {

		$lclQuery = $con->prepare("INSERT INTO contact (ct_id, ct_name, ct_mobile_no, ct_email, ct_message) VALUES(:ct_id, :ct_name, :ct_mobile_no, :ct_email, :ct_message)");

		$lclQuery->bindParam(':ct_id', $UUID);
		$lclQuery->bindParam(':ct_name', $params['txtName']);
		$lclQuery->bindParam(':ct_mobile_no', $params['txtMobileNo']);
		$lclQuery->bindParam(':ct_email', $params['txtEmail']);
		$lclQuery->bindParam(':ct_message', $params['txtMessage']);
		$lclResult = $lclQuery->execute();
		echo "1";
	}
<?php
	session_start();
	error_reporting(0);
	include_once('../conn/conn.php');
	include_once('../admin/backend/generate_uuid.php');
	// require_once 'vendor/autoload.php';
	require_once 'tcpdf/vendor/tecnickcom/tcpdf/examples/tcpdf_include.php';

	$lclCon = new DatabaseClass();
	$con = $lclCon->getCon();
	$con->exec("SET NAMES 'utf8'");
	$params = $_REQUEST;
	$action = $params['action'];
	$UUID = guidv4();
	require '../admin/backend/vendor/autoload.php';
	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;
	switch ($action) {
        case 'place_order':
			placeOrder($params, $con, $UUID);
			break;

		case 'cancel_order':
			cancelOrder($params, $con, $UUID);
			break;

		case 'get_product_delivery_information':
			getDeliveryInfo($params, $con, $UUID);
			break;
	
		case 'get_user_heirarchy_details':
			getUserHeirarchyDetails($params, $con);
			break;

		case 'get_credit_history':
			getCreditHistory($params, $con);
			break;

		case 'get_level_user_count':
			levelDetails($params, $con);
			break;

		case 'get_credit_history_by_search':
			gerCreditsBySearch($params, $con);
			break;
    }

    function placeOrder($params, $con, $UUID) {
		
		$deliveryData = json_decode($params['orderDetails'], TRUE);
		
		$lclOrderID = $params['orderID'];

		$returnValue = marketing($con, $UUID, $params['totalBV'], $params['totalPV'], $params['totalAppliedCoins']);

		$lclQuery = $con->prepare("INSERT INTO orders (or_id, or_readable_id, or_us_id, or_name, or_mobile, or_email, or_sub_total, or_shipping_charges, or_used_coins, or_total_amount, or_address_id, or_payment_type, or_account_name, or_account_number) VALUES(:or_id, :or_readable_id, :or_us_id, :or_name, :or_mobile, :or_email, :or_sub_total, :or_shipping_charges, :or_used_coins, :or_total_amount, :or_address_id, :or_payment_type, :or_account_name, :or_account_number)");

		$lclQuery->bindParam(':or_id', $UUID);
		$lclQuery->bindParam(':or_readable_id', $lclOrderID);
		$lclQuery->bindParam(':or_us_id', $_SESSION['id']);
		$lclQuery->bindParam(':or_name', $params['txtFullName']);
		$lclQuery->bindParam(':or_mobile', $params['txtMobileNo']);
		$lclQuery->bindParam(':or_email', $params['txtEmailID']);
		$lclQuery->bindParam(':or_sub_total', $params['subTotal']);
		$lclQuery->bindParam(':or_shipping_charges', $params['shippingCharges']);
		$lclQuery->bindParam(':or_used_coins', $params['totalAppliedCoins']);
		$lclQuery->bindParam(':or_total_amount', $params['totalAmount']);
		$lclQuery->bindParam(':or_address_id', $params['txtAddress']);
		$lclQuery->bindParam(':or_payment_type', $params['radioPaymentType']);
		$lclQuery->bindParam(':or_account_name', $params['qrPaymentAccountName']);
		$lclQuery->bindParam(':or_account_number', $params['qrPaymentAccountNumber']);
		$lclResult = $lclQuery->execute();

		if($params['totalAppliedCoins'] != 0) {
			$memberUUID = guidv4();
			$lclmemberPer = 25;
			$lclQuery1 = $con->prepare("INSERT INTO member_coin_history (mch_id, mch_user_id, mch_coins, mch_percentage) VALUES(:mch_id, :mch_user_id, :mch_coins, :mch_percentage)");

			$lclQuery1->bindParam(':mch_id', $memberUUID);
			$lclQuery1->bindParam(':mch_user_id', $_SESSION['id']);
			$lclQuery1->bindParam(':mch_coins', $params['totalAppliedCoins']);
			$lclQuery1->bindParam(':mch_percentage', $lclmemberPer);
			$lclResult1 = $lclQuery1->execute();
		}

		$lclQuery1 = "SELECT * FROM cart
		LEFT JOIN products ON products.pd_id = cart.ct_pd_id
		WHERE ct_us_id = '".$_SESSION['id']."'";
		$lclResult1 = $con->query($lclQuery1);
		$count = 0;
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$productUUID = guidv4();
			$lclQuery = $con->prepare("INSERT INTO purchased_products (pp_id, pp_od_id, pp_pd_id, pp_co_id, pp_sz_id, pp_pd_price, pp_qty, pp_order_id, pp_awb_number, pp_shipment_id) VALUES(:pp_id, :pp_od_id, :pp_pd_id, :pp_co_id, :pp_sz_id, :pp_pd_price, :pp_qty, :pp_order_id, :pp_awb_number, :pp_shipment_id)");

			$lclQuery->bindParam(':pp_id', $productUUID);
			$lclQuery->bindParam(':pp_od_id', $UUID);
			$lclQuery->bindParam(':pp_pd_id', $row1['ct_pd_id']);
			$lclQuery->bindParam(':pp_co_id', $row1['ct_color']);
			$lclQuery->bindParam(':pp_sz_id', $row1['ct_size']);
			$lclQuery->bindParam(':pp_pd_price', $row1['pd_discount_price']);
			$lclQuery->bindParam(':pp_qty', $row1['ct_qty']);
			$lclQuery->bindParam(':pp_order_id', $deliveryData[$count]['order_id']);
			$lclQuery->bindParam(':pp_awb_number', $deliveryData[$count]['awb_number']);
			$lclQuery->bindParam(':pp_shipment_id', $deliveryData[$count]['shipment_id']);
			$lclResult = $lclQuery->execute();
			$count++;

			$lclUpdate = "UPDATE product_size SET ps_stock = ps_stock - ".$row1['ct_qty']."
		 		WHERE ps_sz_id = '".$row1['ct_size']."' AND ps_pd_id = '".$row1['ct_pd_id']."'";
			$lclRes = $con->query($lclUpdate);
		}

		if($params['product_id']) {

			$lclQuery3 = "SELECT * FROM products
			WHERE pd_id = '".$params['product_id']."'";
			$lclResult3 = $con->query($lclQuery3);

			if($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
				$productUUID = guidv4();
				$lclQuery = $con->prepare("INSERT INTO purchased_products (pp_id, pp_od_id, pp_pd_id, pp_co_id, pp_sz_id, pp_pd_price, pp_qty, pp_order_id, pp_awb_number, pp_shipment_id) VALUES(:pp_id, :pp_od_id, :pp_pd_id, :pp_co_id, :pp_sz_id, :pp_pd_price, :pp_qty, :pp_order_id, :pp_awb_number, :pp_shipment_id)");

				$lclQuery->bindParam(':pp_id', $productUUID);
				$lclQuery->bindParam(':pp_od_id', $UUID);
				$lclQuery->bindParam(':pp_pd_id', $params['product_id']);
				$lclQuery->bindParam(':pp_co_id', $params['color']);
				$lclQuery->bindParam(':pp_sz_id', $params['size']);
				$lclQuery->bindParam(':pp_pd_price', $row3['pd_discount_price']);
				$lclQuery->bindParam(':pp_qty', $params['quantity']);
				$lclQuery->bindParam(':pp_order_id', $deliveryData[$count]['order_id']);
				$lclQuery->bindParam(':pp_awb_number', $deliveryData[$count]['awb_number']);
				$lclQuery->bindParam(':pp_shipment_id', $deliveryData[$count]['shipment_id']);
				$lclResult = $lclQuery->execute();

				$lclUpdate = "UPDATE product_size SET ps_stock = ps_stock - ".$params['quantity']."
		 		WHERE ps_sz_id = '".$params['size']."' AND ps_pd_id = '".$params['product_id']."'";
				$lclRes = $con->query($lclUpdate);
			}
			
		}

		$lclQuery4 = "DELETE FROM cart WHERE ct_us_id = '".$_SESSION['id']."'";
		$con->query($lclQuery4);

		$ch = curl_init();
		$accessToken = 'EAAJEMf5ULI8BAAupYtQjJwyFD0AyrTYoMuObkNmUyp56PsdphgJddDcnk92kuHgL6dqvM8p7z1O5j4KE1CCOZA8QepFPv95N7t4z1bUmjFJt0WfzkMLg4MWC9GCUpmsDtb4gn4l0sprfcq0UYvHEKBJZBClmlGaFXKwJwZBv3vr6fwkWSp1rgciacZCTl4IZD';
		$messageData = array(
			'messaging_product' => "whatsapp",
			'to' => '91'.$params['txtMobileNo'],
			'type' => "template",
			'template' => array("name"=> "invoice_template",'language'=> array("code"=>"en"),'components'=> 
			array(
				array(
					"type" => "HEADER",
					"parameters" => array(array("type"=> "document",  "document" => array("link"=> "https://multimediastorage124243-dev.s3.amazonaws.com/".$lclOrderID.".pdf", "filename"=> $lclOrderID.".pdf")))),
				array(
				"type" => "body",
				"parameters" => array(array("type"=> "text","text"=> $params['txtFullName']), array("type"=> "text", "text"=> $lclOrderID)))))
		);

		curl_setopt($ch, CURLOPT_URL,"https://graph.facebook.com/v16.0/100492896388925/messages");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Bearer $accessToken"));
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($messageData));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$server_output = curl_exec($ch);
		
		$messageData1 = array(
			'messaging_product' => "whatsapp",
			'to' => '91'.$params['txtMobileNo'],
			'type' => "template",
			'template' => array("name"=> "marketing1",'language'=>array("code"=>"en_US"),'components'=> 
			   array(array(
				"type" => "body",
				"parameters" => array(array("type"=> "text","text"=> $_SESSION['referral_code'])))))
		);
		
		curl_setopt($ch, CURLOPT_URL,"https://graph.facebook.com/v16.0/100492896388925/messages");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Bearer $accessToken"));
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($messageData1));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec($ch);
		curl_close($ch);

        echo "1";
	}

	function marketing($con, $UUID, $totalBV, $totalPV, $totalCoins) {
		$userRef= "SELECT count(*) FROM users WHERE us_id = '".$_SESSION['id']."' AND us_referral_code = 'No'";
		$userRes = $con->query($userRef);
		$userResCount = $userRes->fetchColumn();
		
		if($userResCount) {

			$lclRefCode = substr($UUID, 0, 6);
			$_SESSION['referral_code'] = $lclRefCode;

			$checkRef= "SELECT count(*) FROM users WHERE us_referral_code != '".$lclRefCode."'";
			$checkRes = $con->query($checkRef);
			$checkResCount = $checkRes->fetchColumn();
			if($checkResCount) {
				$lclUpdate = "UPDATE users SET us_referral_code = '".$lclRefCode."',
				us_bv = us_bv + ".$totalBV.",
				us_coins_usage = us_coins_usage - ".$totalCoins."
				WHERE us_id = '".$_SESSION['id']."'";
				$con->query($lclUpdate);
			}

			$recursiveQuery = "WITH RECURSIVE company_hierarchy AS (
				SELECT   us_id,
						  us_name,
						  us_mobile,
						  us_referred_user_id,
					   1 AS hierarchy_level
				FROM users
				WHERE us_id = '".$_SESSION['id']."'
				UNION ALL
				SELECT    u.us_id,
						  u.us_name,
						  u.us_mobile,
						  u.us_referred_user_id,
					  hierarchy_level + 1
				FROM users u, company_hierarchy ch
				WHERE u.us_id = ch.us_referred_user_id
			  )
			   
			  SELECT ch.us_name AS employee_name,
					 ch.us_mobile AS employee_mobile,
					 u.us_id AS main_id,
					 u.us_name AS main_name,
					 u.us_mobile AS main_mobile,
					 hierarchy_level
			  FROM company_hierarchy ch
			  LEFT JOIN users u
			  ON ch.us_referred_user_id = u.us_id
			  ORDER BY ch.hierarchy_level DESC";

			$recursiveResult = $con->query($recursiveQuery);

			while($recursiveRow = $recursiveResult->fetch(PDO::FETCH_ASSOC)) {

				if($recursiveRow['main_id'] != "") {
					$levelUUID = guidv4();
					$lclQuery = $con->prepare("INSERT INTO level_information (li_id, li_order_id, li_main_user_id, li_user_id, li_level_count) VALUES(:li_id, :li_order_id, :li_main_user_id, :li_user_id, :li_level_count)");

					$lclQuery->bindParam(':li_id', $levelUUID);
					$lclQuery->bindParam(':li_order_id', $UUID);
					$lclQuery->bindParam(':li_main_user_id', $recursiveRow['main_id']);
					$lclQuery->bindParam(':li_user_id', $_SESSION['id']);
					$lclQuery->bindParam(':li_level_count', $recursiveRow['hierarchy_level']);
					$lclResult = $lclQuery->execute();

					$lvlCheckPercentage = "SELECT * FROM level_percentage_chart WHERE lpa_level IN ('".$recursiveRow['hierarchy_level']."')";
					$lvlCheckPercentageRes = $con->query($lvlCheckPercentage);

					if($lvlCheckPercentageRow = $lvlCheckPercentageRes->fetch(PDO::FETCH_ASSOC)) {
						$addingAmount = ($lvlCheckPercentageRow['lpa_percentage'] / 100) * $totalBV;
						$lclCreditAmount = "UPDATE users SET us_wallet = us_wallet + ".$addingAmount."
						WHERE us_id = '".$recursiveRow['main_id']."'";
						$con->query($lclCreditAmount);

						// save amount credit history, later helpfull for order cancellation
						$amountHistoryUUID = guidv4();
						$achType = 'no_within_days';
						$insertAmountHistory = $con->prepare("INSERT INTO amount_credit_history (ach_id, ach_or_id, ach_us_id, ach_main_id, ach_percentage, ach_level, ach_amount, ach_type, ach_bv) VALUES(:ach_id, :ach_or_id, :ach_us_id, :ach_main_id, :ach_percentage, :ach_level, :ach_amount, :ach_type, :ach_bv)");

						$insertAmountHistory->bindParam(':ach_id', $amountHistoryUUID);
						$insertAmountHistory->bindParam(':ach_or_id', $UUID);
						$insertAmountHistory->bindParam(':ach_us_id', $_SESSION['id']);
						$insertAmountHistory->bindParam(':ach_main_id', $recursiveRow['main_id']);
						$insertAmountHistory->bindParam(':ach_percentage', $lvlCheckPercentageRow['lpa_percentage']);
						$insertAmountHistory->bindParam(':ach_level', $recursiveRow['hierarchy_level']);
						$insertAmountHistory->bindParam(':ach_amount', $addingAmount);
						$insertAmountHistory->bindParam(':ach_type', $achType);
						$insertAmountHistory->bindParam(':ach_bv', $totalBV);
						$insertAmountHistory->execute();

					}
					
					// start check level completed or NO
					$mainUser = "SELECT * FROM users WHERE us_id = '".$recursiveRow['main_id']."'";
					$mainUserResult = $con->query($mainUser);

					if($mainRow = $mainUserResult->fetch(PDO::FETCH_ASSOC)) {
						$newLevel = $mainRow['us_level'] + 1;
						$lclCheckLevelComplete = "SELECT count(*) FROM level_information WHERE li_main_user_id = '".$recursiveRow['main_id']."' AND li_level_count = '".$newLevel."' AND li_status = 'CREATED'";
						$lclCheckLevelCompleteRes = $con->query($lclCheckLevelComplete);
						$lclCheckLevelCompleteCount = $lclCheckLevelCompleteRes->fetchColumn();

						$lvlCount = "SELECT * FROM levels_count WHERE lvl_level = ".$recursiveRow['hierarchy_level']."";
						$lvlCountRes = $con->query($lvlCount);

						if($lvlRow = $lvlCountRes->fetch(PDO::FETCH_ASSOC)) {
							if($lclCheckLevelCompleteCount == $lvlRow['lvl_level_count']) {

								// start check user is completed order within given days
								$recursiveWithinDaysQuery = "WITH RECURSIVE company_hierarchy AS (
									SELECT   	us_id,
												us_name,
												us_mobile,
												us_referred_user_id,
											0 AS hierarchy_level
									FROM users
									WHERE us_id = '".$recursiveRow['main_id']."'
									UNION ALL
									SELECT    u.us_id,
												u.us_name,
												u.us_mobile,
												u.us_referred_user_id,
											hierarchy_level + 1
									FROM users u, company_hierarchy ch
									WHERE u.us_referred_user_id = ch.us_id
									)
									
									SELECT  ch.us_id AS employee_id,
											ch.us_name AS employee_name,
											ch.us_mobile AS employee_mobile,
											u.us_id AS main_id,
											u.us_name AS main_name,
											u.us_mobile AS main_mobile,
											hierarchy_level
									FROM company_hierarchy ch
									LEFT JOIN users u
									ON ch.us_referred_user_id = u.us_id
									WHERE ch.hierarchy_level = ".$newLevel."
									ORDER BY ch.hierarchy_level, ch.us_id";
					
								$recursiveWithinDaysResult = $con->query($recursiveWithinDaysQuery);
								$recursiveWithinDaysResult1 = $con->query($recursiveWithinDaysQuery);
								$checkTotalCount = 0;
								while($recursiveWithinDaysRow = $recursiveWithinDaysResult->fetch(PDO::FETCH_ASSOC)) {
								
									if($recursiveWithinDaysRow['main_id'] != "" && $recursiveWithinDaysRow['hierarchy_level'] != 0) {

										$lclMainUserLevelCompleteDetails = "SELECT * FROM level_information WHERE li_user_id = '".$recursiveWithinDaysRow['employee_id']."' AND li_level_count = '".$newLevel."' AND li_status = 'CREATED'";
										$lclMainUserCheckLevelCompleteRes = $con->query($lclMainUserLevelCompleteDetails);
										
										while($mainUserWithinDaysRow = $lclMainUserCheckLevelCompleteRes->fetch(PDO::FETCH_ASSOC)) {
											$belowUser = "SELECT * FROM users WHERE us_id = '".$mainUserWithinDaysRow['li_user_id']."'";
											$belowUserResult = $con->query($belowUser);

											if($belowUserRow = $belowUserResult->fetch(PDO::FETCH_ASSOC)) {
												$lclRegDate = new DateTime(date('Y-m-d', strtotime($belowUserRow['us_created_date'])));
												$lclOrderDate = new DateTime(date('Y-m-d'));
												$abs_diff = $lclOrderDate->diff($lclRegDate)->format("%a");

												$lvlCompleteDays = "SELECT * FROM level_complete_days";
												$lvlCompleteDaysResult = $con->query($lvlCompleteDays);

												if($lvlCompleteDaysRow = $lvlCompleteDaysResult->fetch(PDO::FETCH_ASSOC)) {
													$lvlCompleteDays = $lvlCompleteDaysRow['lcd_days'];
												}

												if($abs_diff < $lvlCompleteDays) {
													$checkTotalCount++;
												}
											}
										}

									}

								}

								// echo $checkTotalCount;

								while($recursiveWithinDaysRow = $recursiveWithinDaysResult1->fetch(PDO::FETCH_ASSOC)) {
									// echo "Hi";
									if($recursiveWithinDaysRow['main_id'] != "" && $recursiveWithinDaysRow['hierarchy_level'] != 0) {

										if($checkTotalCount == $lvlRow['lvl_level_count']) {

											$lclInsertUserLevelCompleteDetails = "SELECT * FROM level_information WHERE li_user_id = '".$recursiveWithinDaysRow['employee_id']."' AND li_level_count = '".$newLevel."' AND li_status = 'CREATED'";
											$lclInsertUserCheckLevelCompleteRes = $con->query($lclInsertUserLevelCompleteDetails);
											// $testCount = 0;
											if($insertUserWithinDaysRow = $lclInsertUserCheckLevelCompleteRes->fetch(PDO::FETCH_ASSOC)) {

												$lclInsertUserLevelCompleteBV = "SELECT * FROM amount_credit_history WHERE ach_level = '".$newLevel."' AND ach_us_id = '".$insertUserWithinDaysRow['li_user_id']."'";
												$lclInsertUserLevelCompleteBVRes = $con->query($lclInsertUserLevelCompleteBV);

												if($lclInsertUserLevelCompleteBVRow = $lclInsertUserLevelCompleteBVRes->fetch(PDO::FETCH_ASSOC)) {

													$lvlCheckComplete = "SELECT * FROM level_complete_chart WHERE lcc_level IN ('".$newLevel."')";
													$lvlCheckCompleteRes = $con->query($lvlCheckComplete);

													if($lvlCheckCompleteRow = $lvlCheckCompleteRes->fetch(PDO::FETCH_ASSOC)) {
														$addingAmount = ($lvlCheckCompleteRow['lcc_percentage'] / 100) * $lclInsertUserLevelCompleteBVRow['ach_bv'];
														$lclCreditAmount = "UPDATE users SET us_wallet = us_wallet + ".$addingAmount."
														WHERE us_id = '".$recursiveRow['main_id']."'";
														$con->query($lclCreditAmount);

														// save amount credit history, later helpfull for order cancellation
														$amountHistoryUUID = guidv4();
														$achType = 'within_days';
														$lclTotalBV = 0;
														$insertAmountHistory = $con->prepare("INSERT INTO amount_credit_history (ach_id, ach_or_id, ach_us_id, ach_main_id, ach_percentage, ach_level, ach_amount, ach_type, ach_bv) VALUES(:ach_id, :ach_or_id, :ach_us_id, :ach_main_id, :ach_percentage, :ach_level, :ach_amount, :ach_type, :ach_bv)");

														$insertAmountHistory->bindParam(':ach_id', $amountHistoryUUID);
														$insertAmountHistory->bindParam(':ach_or_id', $insertUserWithinDaysRow['li_order_id']);
														$insertAmountHistory->bindParam(':ach_us_id', $insertUserWithinDaysRow['li_user_id']);
														$insertAmountHistory->bindParam(':ach_main_id', $insertUserWithinDaysRow['li_main_user_id']);
														$insertAmountHistory->bindParam(':ach_percentage', $lvlCheckCompleteRow['lcc_percentage']);
														$insertAmountHistory->bindParam(':ach_level', $recursiveRow['hierarchy_level']);
														$insertAmountHistory->bindParam(':ach_amount', $addingAmount);
														$insertAmountHistory->bindParam(':ach_type', $achType);
														$insertAmountHistory->bindParam(':ach_bv', $lclTotalBV);
														$insertAmountHistory->execute();

													}
												}

											}
											
										}
									}
								}

								// end check user is completed order within 7 days
							

							// if Level Completed then execute this
							$lclUpdate = "UPDATE users SET us_level = us_level + 1
							WHERE us_id = '".$recursiveRow['main_id']."'";
							$con->query($lclUpdate);
						}
					}
					// end check level completed or NO
				}
			}
		}
			
	} else {

			$lclUpdate = "UPDATE users SET 
				us_bv = us_bv + ".$totalBV.",
				us_coins_usage = us_coins_usage - ".$totalCoins."
				WHERE us_id = '".$_SESSION['id']."'";
			$con->query($lclUpdate);

			$userRef1 = "SELECT count(*) FROM users WHERE us_id = '".$_SESSION['id']."' AND us_referred_user_id IS NULL";
			$userRes1 = $con->query($userRef1);
			$userResCount1 = $userRes1->fetchColumn();

			if($userResCount1) {
				$recursiveQuery = "WITH RECURSIVE company_hierarchy AS (
					SELECT   us_id,
							  us_name,
							  us_mobile,
							  us_referred_user_id,
						   0 AS hierarchy_level
					FROM users
					WHERE us_id = '".$_SESSION['id']."'
					UNION ALL
					SELECT    u.us_id,
							  u.us_name,
							  u.us_mobile,
							  u.us_referred_user_id,
						  hierarchy_level + 1
					FROM users u, company_hierarchy ch
					WHERE u.us_id = ch.us_referred_user_id
				  )
				   
				  SELECT ch.us_id AS employee_id,
						 ch.us_name AS employee_name,
						 ch.us_mobile AS employee_mobile,
						 u.us_id AS main_id,
						 u.us_name AS main_name,
						 u.us_mobile AS main_mobile,
						 hierarchy_level
				  FROM company_hierarchy ch
				  LEFT JOIN users u
				  ON ch.us_referred_user_id = u.us_id
				  ORDER BY ch.hierarchy_level DESC";
	
				$recursiveResult = $con->query($recursiveQuery);
				$checkMyCredit = 0;
	
				while($recursiveRow = $recursiveResult->fetch(PDO::FETCH_ASSOC)) {
					// $levelUUID = guidv4();
					if($checkMyCredit == 0) {
						$recursiveRow['main_id'] = $_SESSION['id'];
					}
	
					$checkMyCredit++;

					$lclHeirarchy = $recursiveRow['hierarchy_level'] + 1;
	
					if($recursiveRow['employee_id'] != "") {
						$levelUUID = guidv4();
	
						$lvlCheckPercentage = "SELECT * FROM level_percentage_chart WHERE lpa_level IN ('".$lclHeirarchy."')";
						$lvlCheckPercentageRes = $con->query($lvlCheckPercentage);
	
						if($lvlCheckPercentageRow = $lvlCheckPercentageRes->fetch(PDO::FETCH_ASSOC)) {
							$addingAmount = ($lvlCheckPercentageRow['lpa_percentage'] / 100) * $totalBV;
							$lclCreditAmount = "UPDATE users SET us_wallet = us_wallet + ".$addingAmount."
							WHERE us_id = '".$recursiveRow['employee_id']."'";
							$con->query($lclCreditAmount);
	
							// save amount credit history, later helpfull for order cancellation
							$amountHistoryUUID = guidv4();
							$achType = 'no_within_days';
							$insertAmountHistory = $con->prepare("INSERT INTO amount_credit_history (ach_id, ach_or_id, ach_us_id, ach_main_id, ach_percentage, ach_level, ach_amount, ach_type, ach_bv) VALUES(:ach_id, :ach_or_id, :ach_us_id, :ach_main_id, :ach_percentage, :ach_level, :ach_amount, :ach_type, :ach_bv)");
	
							$insertAmountHistory->bindParam(':ach_id', $amountHistoryUUID);
							$insertAmountHistory->bindParam(':ach_or_id', $UUID);
							$insertAmountHistory->bindParam(':ach_us_id', $_SESSION['id']);
							$insertAmountHistory->bindParam(':ach_main_id', $recursiveRow['employee_id']);
							$insertAmountHistory->bindParam(':ach_percentage', $lvlCheckPercentageRow['lpa_percentage']);
							$insertAmountHistory->bindParam(':ach_level', $recursiveRow['hierarchy_level']);
							$insertAmountHistory->bindParam(':ach_amount', $addingAmount);
							$insertAmountHistory->bindParam(':ach_type', $achType);
							$insertAmountHistory->bindParam(':ach_bv', $totalBV);
							$insertAmountHistory->execute();
						}
					}		
				}
			} else {
				$recursiveQuery = "WITH RECURSIVE company_hierarchy AS (
					SELECT   us_id,
							  us_name,
							  us_mobile,
							  us_referred_user_id,
						   0 AS hierarchy_level
					FROM users
					WHERE us_id = '".$_SESSION['id']."'
					UNION ALL
					SELECT    u.us_id,
							  u.us_name,
							  u.us_mobile,
							  u.us_referred_user_id,
						  hierarchy_level + 1
					FROM users u, company_hierarchy ch
					WHERE u.us_id = ch.us_referred_user_id
				  )
				   
				  SELECT ch.us_id AS employee_id,
						   ch.us_name AS employee_name,
						 ch.us_mobile AS employee_mobile,
						 u.us_id AS main_id,
						 u.us_name AS main_name,
						 u.us_mobile AS main_mobile,
						 hierarchy_level
				  FROM company_hierarchy ch
				  LEFT JOIN users u
				  ON ch.us_referred_user_id = u.us_id
				  ORDER BY ch.hierarchy_level ASC";
	
				$recursiveResult = $con->query($recursiveQuery);
				$checkMyCredit = 0;
	
				while($recursiveRow = $recursiveResult->fetch(PDO::FETCH_ASSOC)) {

					$lclHeirarchy = $recursiveRow['hierarchy_level'] + 1;
	
					$checkMyCredit++;
	
					if($recursiveRow['employee_id'] != "") {
						$levelUUID = guidv4();
	
						$lvlCheckPercentage = "SELECT * FROM level_percentage_chart WHERE lpa_level IN ('".$lclHeirarchy."')";
						$lvlCheckPercentageRes = $con->query($lvlCheckPercentage);
	
						if($lvlCheckPercentageRow = $lvlCheckPercentageRes->fetch(PDO::FETCH_ASSOC)) {
							$addingAmount = ($lvlCheckPercentageRow['lpa_percentage'] / 100) * $totalBV;
							$lclCreditAmount = "UPDATE users SET us_wallet = us_wallet + ".$addingAmount."
							WHERE us_id = '".$recursiveRow['employee_id']."'";
							$con->query($lclCreditAmount);
	
							// save amount credit history, later helpfull for order cancellation
							$amountHistoryUUID = guidv4();
							$achType = 'no_within_days';
							$insertAmountHistory = $con->prepare("INSERT INTO amount_credit_history (ach_id, ach_or_id, ach_us_id, ach_main_id, ach_percentage, ach_level, ach_amount, ach_type, ach_bv) VALUES(:ach_id, :ach_or_id, :ach_us_id, :ach_main_id, :ach_percentage, :ach_level, :ach_amount, :ach_type, :ach_bv)");
	
							$insertAmountHistory->bindParam(':ach_id', $amountHistoryUUID);
							$insertAmountHistory->bindParam(':ach_or_id', $UUID);
							$insertAmountHistory->bindParam(':ach_us_id', $_SESSION['id']);
							$insertAmountHistory->bindParam(':ach_main_id', $recursiveRow['employee_id']);
							$insertAmountHistory->bindParam(':ach_percentage', $lvlCheckPercentageRow['lpa_percentage']);
							$insertAmountHistory->bindParam(':ach_level', $recursiveRow['hierarchy_level']);
							$insertAmountHistory->bindParam(':ach_amount', $addingAmount);
							$insertAmountHistory->bindParam(':ach_type', $achType);
							$insertAmountHistory->bindParam(':ach_bv', $totalBV);
							$insertAmountHistory->execute();
						}
					}		
				}
			}

		}

		calculateBV($con);
		calculateTotalMember($con);
		// calculateTotalBV($con);
	}

	function calculateBV($con) {

		$recursiveBottomToTopQuery = "WITH RECURSIVE company_hierarchy AS (
			SELECT   us_id,
					  us_name,
					  us_mobile,
					  us_referred_user_id,
				   1 AS hierarchy_level
			FROM users
			WHERE us_id = '".$_SESSION['id']."'
			UNION ALL
			SELECT    u.us_id,
					  u.us_name,
					  u.us_mobile,
					  u.us_referred_user_id,
				  hierarchy_level + 1
			FROM users u, company_hierarchy ch
			WHERE u.us_id = ch.us_referred_user_id
		  )
		   
		  SELECT ch.us_id AS employee_id,
		  		 ch.us_name AS employee_name,
				 ch.us_mobile AS employee_mobile,
				 u.us_id AS main_id,
				 u.us_name AS main_name,
				 u.us_mobile AS main_mobile,
				 hierarchy_level
		  FROM company_hierarchy ch
		  LEFT JOIN users u
		  ON ch.us_referred_user_id = u.us_id
		  ORDER BY ch.hierarchy_level DESC";

		$recursiveBottomToTopResult = $con->query($recursiveBottomToTopQuery);

		while($recursiveBottomToTopRow = $recursiveBottomToTopResult->fetch(PDO::FETCH_ASSOC)) {

			$recursiveTopToBottomQuery = "WITH RECURSIVE company_hierarchy AS (
				SELECT    us_id,
							us_bv,
							us_name,
							us_mobile,
							us_referred_user_id,
						0 AS hierarchy_level
				FROM users
				WHERE us_id = '".$recursiveBottomToTopRow['employee_id']."'
				UNION ALL
				SELECT    u.us_id,
							u.us_bv,
							u.us_name,
							u.us_mobile,
							u.us_referred_user_id,
						hierarchy_level + 1
				FROM users u, company_hierarchy ch
				WHERE u.us_referred_user_id = ch.us_id
				)
				
				SELECT  
						SUM(ch.us_bv) AS empBV,
						ch.us_id AS employee_id,
						hierarchy_level
				FROM company_hierarchy ch
				LEFT JOIN users u
				ON ch.us_referred_user_id = u.us_id";

			$recursiveTopToBottomResult = $con->query($recursiveTopToBottomQuery);
			$totalBV = 0;
			while($recursiveTopToBottomRow = $recursiveTopToBottomResult->fetch(PDO::FETCH_ASSOC)) {
				$totalBV = $recursiveTopToBottomRow['empBV'];
				$businessHistory = "SELECT count(*) FROM rank_history WHERE rh_us_id = '".$recursiveTopToBottomRow['employee_id']."'";
				$businessHistoryRes = $con->query($businessHistory);
				$businessHistoryResCount = $businessHistoryRes->fetchColumn();
				$businessHistoryResCount = $businessHistoryResCount + 2;

				$business = "SELECT * FROM business_ranks WHERE br_id = ".$businessHistoryResCount."";
				$businessRes = $con->query($business);

				if($businessRow = $businessRes->fetch(PDO::FETCH_ASSOC)) {
					if($totalBV >=  $businessRow['br_bv']) {

						$amountHistoryUUID = guidv4();
						$achType = 'business_rank';
						$lclTotalBV = 0;
						$addingAmount = ($businessRow['br_bv'] / 100) * $businessRow['br_percentage'];
						$insertAmountHistory = $con->prepare("INSERT INTO amount_credit_history (ach_id, ach_us_id, ach_main_id, ach_percentage, ach_level, ach_amount, ach_type, ach_bv) VALUES(:ach_id, :ach_us_id, :ach_main_id, :ach_percentage, :ach_level, :ach_amount, :ach_type, :ach_bv)");

						$insertAmountHistory->bindParam(':ach_id', $amountHistoryUUID);
						$insertAmountHistory->bindParam(':ach_us_id', $recursiveTopToBottomRow['employee_id']);
						$insertAmountHistory->bindParam(':ach_main_id', $recursiveTopToBottomRow['employee_id']);
						$insertAmountHistory->bindParam(':ach_percentage', $businessRow['br_percentage']);
						$insertAmountHistory->bindParam(':ach_level', $businessRow['br_id']);
						$insertAmountHistory->bindParam(':ach_amount', $addingAmount);
						$insertAmountHistory->bindParam(':ach_type', $achType);
						$insertAmountHistory->bindParam(':ach_bv', $lclTotalBV);
						$insertAmountHistory->execute();

						$rankHistoryUUID = guidv4();

						$rankHistory = $con->prepare("INSERT INTO rank_history (rh_id, rh_us_id, rh_br_id) VALUES(:rh_id, :rh_us_id, :rh_br_id)");

						$rankHistory->bindParam(':rh_id', $rankHistoryUUID);
						$rankHistory->bindParam(':rh_us_id', $recursiveTopToBottomRow['employee_id']);
						$rankHistory->bindParam(':rh_br_id', $businessRow['br_id']);
						$rankHistory->execute();

						$lclUpdate = "UPDATE users SET 
						us_rank = '".$businessRow['br_rank_name']."',
						us_wallet = us_wallet + ".$addingAmount."
						WHERE us_id = '".$recursiveTopToBottomRow['employee_id']."'";
						$con->query($lclUpdate);
					}
				}
			}
		}
		
	}

	function calculateTotalMember($con) {

		$recursiveBottomToTopQuery = "WITH RECURSIVE company_hierarchy AS (
			SELECT   us_id,
					  us_name,
					  us_mobile,
					  us_referred_user_id,
				   1 AS hierarchy_level
			FROM users
			WHERE us_id = '".$_SESSION['id']."'
			UNION ALL
			SELECT    u.us_id,
					  u.us_name,
					  u.us_mobile,
					  u.us_referred_user_id,
				  hierarchy_level + 1
			FROM users u, company_hierarchy ch
			WHERE u.us_id = ch.us_referred_user_id
		  )
		   
		  SELECT ch.us_id AS employee_id,
		  		 ch.us_name AS employee_name,
				 ch.us_mobile AS employee_mobile,
				 u.us_id AS main_id,
				 u.us_name AS main_name,
				 u.us_mobile AS main_mobile,
				 hierarchy_level
		  FROM company_hierarchy ch
		  LEFT JOIN users u
		  ON ch.us_referred_user_id = u.us_id
		  ORDER BY ch.hierarchy_level DESC";

		$recursiveBottomToTopResult = $con->query($recursiveBottomToTopQuery);

		while($recursiveBottomToTopRow = $recursiveBottomToTopResult->fetch(PDO::FETCH_ASSOC)) {

			$recursiveTopToBottomQuery = "WITH RECURSIVE company_hierarchy AS (
				SELECT    us_id,
							us_bv,
							us_name,
							us_mobile,
							us_referred_user_id,
							us_created_date,
						0 AS hierarchy_level
				FROM users
				WHERE us_id = '".$recursiveBottomToTopRow['employee_id']."'
				UNION ALL
				SELECT    u.us_id,
							u.us_bv,
							u.us_name,
							u.us_mobile,
							u.us_referred_user_id,
							u.us_created_date,
							hierarchy_level + 1
				FROM users u, company_hierarchy ch
				WHERE u.us_referred_user_id = ch.us_id
				)
				
				SELECT  
						count(*) AS totalMember,
						SUM(ch.us_bv) AS empBV,
						ch.us_id AS employee_id,
						ch.us_created_date,
						hierarchy_level
				FROM company_hierarchy ch
				LEFT JOIN users u
				ON ch.us_referred_user_id = u.us_id";

			$recursiveTopToBottomResult = $con->query($recursiveTopToBottomQuery);
			$totalMember = 0;
			while($recursiveTopToBottomRow = $recursiveTopToBottomResult->fetch(PDO::FETCH_ASSOC)) {
				$totalMember = $recursiveTopToBottomRow['totalMember'] - 1;

				$teamHistory = "SELECT count(*) FROM team_building_history WHERE tbh_us_id = '".$recursiveTopToBottomRow['employee_id']."'";
				$teamHistoryRes = $con->query($teamHistory);
				$teamHistoryResCount = $teamHistoryRes->fetchColumn();
				$teamHistoryResCount = $teamHistoryResCount;

				$team = "SELECT * FROM team_building WHERE tb_id = ".$teamHistoryResCount."";
				$teamRes = $con->query($team);
				if($teamRow = $teamRes->fetch(PDO::FETCH_ASSOC)) {
					$lclRegDate = new DateTime(date('Y-m-d', strtotime($recursiveTopToBottomRow['us_created_date'])));
					$lclOrderDate = new DateTime(date('Y-m-d'));
					$abs_diff = $lclOrderDate->diff($lclRegDate)->format("%a");

					if($abs_diff <=  $teamRow['tb_ext_days']) {
						if($totalMember >=  $teamRow['tb_member']) {

							$amountHistoryUUID = guidv4();
							$achType = 'team_building';
							$lclTotalBV = 0;
							$addingAmount = ($recursiveTopToBottomRow['empBV'] / 100) * $teamRow['tb_percentage'];
							$insertAmountHistory = $con->prepare("INSERT INTO amount_credit_history (ach_id, ach_us_id, ach_main_id, ach_percentage, ach_level, ach_amount, ach_type, ach_bv) VALUES(:ach_id, :ach_us_id, :ach_main_id, :ach_percentage, :ach_level, :ach_amount, :ach_type, :ach_bv)");
	
							$insertAmountHistory->bindParam(':ach_id', $amountHistoryUUID);
							$insertAmountHistory->bindParam(':ach_us_id', $recursiveTopToBottomRow['employee_id']);
							$insertAmountHistory->bindParam(':ach_main_id', $recursiveTopToBottomRow['employee_id']);
							$insertAmountHistory->bindParam(':ach_percentage', $teamRow['tb_percentage']);
							$insertAmountHistory->bindParam(':ach_level', $teamRow['tb_id']);
							$insertAmountHistory->bindParam(':ach_amount', $addingAmount);
							$insertAmountHistory->bindParam(':ach_type', $achType);
							$insertAmountHistory->bindParam(':ach_bv', $lclTotalBV);
							$insertAmountHistory->execute();
	
							$teamHistoryUUID = guidv4();
							$tbhType = 'Completed';
	
							$rankHistory = $con->prepare("INSERT INTO team_building_history (tbh_id, tbh_us_id, tbh_tb_id, tbh_type) VALUES(:tbh_id, :tbh_us_id, :tbh_tb_id, :tbh_type)");
	
							$rankHistory->bindParam(':tbh_id', $teamHistoryUUID);
							$rankHistory->bindParam(':tbh_us_id', $recursiveTopToBottomRow['employee_id']);
							$rankHistory->bindParam(':tbh_tb_id', $teamRow['tb_id']);
							$rankHistory->bindParam(':tbh_type', $tbhType);
							$rankHistory->execute();
	
							$lclUpdate = "UPDATE users SET
							us_wallet = us_wallet + ".$addingAmount."
							WHERE us_id = '".$recursiveTopToBottomRow['employee_id']."'";
							$con->query($lclUpdate);
						}
					} else {

							$teamHistoryUUID = guidv4();
							$tbhType = 'Not Completed';
	
							$rankHistory = $con->prepare("INSERT INTO team_building_history (tbh_id, tbh_us_id, tbh_tb_id, tbh_type) VALUES(:tbh_id, :tbh_us_id, :tbh_tb_id, :tbh_type)");
	
							$rankHistory->bindParam(':tbh_id', $teamHistoryUUID);
							$rankHistory->bindParam(':tbh_us_id', $recursiveTopToBottomRow['employee_id']);
							$rankHistory->bindParam(':tbh_tb_id', $teamRow['tb_id']);
							$rankHistory->bindParam(':tbh_type', $tbhType);
							$rankHistory->execute();

					}
					
				}
			}
		}

	}

	function cancelOrderBackup($params, $con) {
		$orderUser = "SELECT * FROM purchased_products WHERE pp_awb_number = '".$params['orderID']."' AND os_delivery_status != 'CANCELLED'";
		$orderUserResult = $con->query($orderUser);

		
	}

	function cancelOrder($params, $con, $UUID) {

		$orderUser = "SELECT * FROM orders WHERE or_id = '".$params['orderID']."' AND os_delivery_status != 'CANCELLED'";
		$orderUserResult = $con->query($orderUser);

		if($orderUserRow = $orderUserResult->fetch(PDO::FETCH_ASSOC)) {

			$updateBVUser = "SELECT * FROM purchased_products 
			LEFT JOIN products ON products.pd_id = purchased_products.pp_pd_id
			WHERE pp_od_id = '".$params['orderID']."'";
			$updateBVUserResult = $con->query($updateBVUser);

			while($updateBVUserRow = $updateBVUserResult->fetch(PDO::FETCH_ASSOC)) {
				$lclUpdate = "UPDATE users SET 
				us_bv = us_bv - ".$updateBVUserRow['pd_bv']."
				WHERE us_id = '".$_SESSION['id']."'";
				$con->query($lclUpdate);
				$deliveryID = $updateBVUserRow['pp_awb_number'];
			}

			$cancelReason = $con->prepare("INSERT INTO cancel_reason (cr_id, cr_od_id, cr_us_id, cr_reason) VALUES(:cr_id, :cr_od_id, :cr_us_id, :cr_reason)");

			$cancelReason->bindParam(':cr_id', $UUID);
			$cancelReason->bindParam(':cr_od_id', $params['orderID']);
			$cancelReason->bindParam(':cr_us_id', $_SESSION['id']);
			$cancelReason->bindParam(':cr_reason', $params['txtReason']);
			$cancelReason->execute();

			// update order status to CANCELLED
			$lclOrder = "UPDATE orders SET os_delivery_status = 'CANCELLED'
				WHERE or_id = '".$params['orderID']."'";
			$con->query($lclOrder);

			$lclRegDate = new DateTime(date('Y-m-d', strtotime($orderUserRow['or_created_date'])));
			$lclOrderDate = new DateTime(date('Y-m-d'));
			$abs_diff = $lclOrderDate->diff($lclRegDate)->format("%a");

			$orderCancelDays = "SELECT * FROM order_cancel_days";
			$orderCancelDaysResult = $con->query($orderCancelDays);

			if($orderCancelDaysRow = $orderCancelDaysResult->fetch(PDO::FETCH_ASSOC)) {
				$cancelDays = $orderCancelDaysRow['ocd_days'];
			}

			if($abs_diff < $cancelDays) {
				$recursiveQuery = "WITH RECURSIVE company_hierarchy AS (
					SELECT   us_id,
							  us_name,
							  us_mobile,
							  us_referred_user_id,
						   1 AS hierarchy_level
					FROM users
					WHERE us_id = '".$_SESSION['id']."'
					UNION ALL
					SELECT    u.us_id,
							  u.us_name,
							  u.us_mobile,
							  u.us_referred_user_id,
						  hierarchy_level + 1
					FROM users u, company_hierarchy ch
					WHERE u.us_id = ch.us_referred_user_id
				  )
				   
				  SELECT ch.us_name AS employee_name,
						 ch.us_mobile AS employee_mobile,
						 u.us_id AS main_id,
						 u.us_name AS main_name,
						 u.us_mobile AS main_mobile,
						 hierarchy_level
				  FROM company_hierarchy ch
				  LEFT JOIN users u
				  ON ch.us_referred_user_id = u.us_id
				  ORDER BY ch.hierarchy_level DESC";
		
				$recursiveResult = $con->query($recursiveQuery);
		
				while($recursiveRow = $recursiveResult->fetch(PDO::FETCH_ASSOC)) {
					if($recursiveRow['main_id'] != "") {
							// demote user once cancellation start
						$lclCheckLevelComplete = "SELECT count(*) FROM level_information WHERE li_main_user_id = '".$recursiveRow['main_id']."' AND li_level_count = '".$recursiveRow['hierarchy_level']."' AND li_status = 'CREATED'";
						$lclCheckLevelCompleteRes = $con->query($lclCheckLevelComplete);
						$lclCheckLevelCompleteCount = $lclCheckLevelCompleteRes->fetchColumn();

						$lvlCount = "SELECT * FROM levels_count WHERE lvl_level = ".$recursiveRow['hierarchy_level']."";
						$lvlCountRes = $con->query($lvlCount);

						if($lvlRow = $lvlCountRes->fetch(PDO::FETCH_ASSOC)) {
							if($lclCheckLevelCompleteCount == $lvlRow['lvl_level_count']) {
								$lclUpdate = "UPDATE users SET us_level = us_level - 1
								WHERE us_id = '".$recursiveRow['main_id']."'";
								$con->query($lclUpdate);
							}
						}
		
						$lclMainUserAmtDeductNoWithin = "SELECT * FROM amount_credit_history WHERE ach_or_id = '".$params['orderID']."' AND ach_main_id = '".$recursiveRow['main_id']."' AND ach_level = '".$recursiveRow['hierarchy_level']."'";
						$lclMainUserAmtDeductNoWithinRes = $con->query($lclMainUserAmtDeductNoWithin);

						while($lclMainUserAmtDeductNoWithinRow = $lclMainUserAmtDeductNoWithinRes->fetch(PDO::FETCH_ASSOC)) {
		
							$lclDebitAmount = "UPDATE users SET us_wallet = us_wallet - ".$lclMainUserAmtDeductNoWithinRow['ach_amount']."
							WHERE us_id = '".$recursiveRow['main_id']."'";
							$con->query($lclDebitAmount);
		
							$lclUpdate = "UPDATE level_information SET li_status = 'CANCELLED'
								WHERE li_main_user_id = '".$recursiveRow['main_id']."' AND li_user_id = '".$_SESSION["id"]."'";
							$con->query($lclUpdate);
						}
		
					}
				}

				$apiToken = "SELECT * FROM delivery_api_token";
				$apiTokenRes = $con->query($apiToken);

				if($apiTokenRow = $apiTokenRes->fetch(PDO::FETCH_ASSOC)) {
					$datetime_1 = $apiTokenRow['dlt_updated_at'];
					$datetime_2 = date('Y-m-d H:i:s');
					
					$from_time = strtotime($datetime_1); 
					$to_time = strtotime($datetime_2); 
					$diff_minutes = round(abs($from_time - $to_time) / 60, 2);

					$token = $apiTokenRow['dlt_token'];

					if($diff_minutes > 160) {
						$curl = curl_init();

						curl_setopt_array($curl, array(
						CURLOPT_URL => 'https://api.nimbuspost.com/v1/users/login',
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => '',
						CURLOPT_MAXREDIRS => 10,
						CURLOPT_TIMEOUT => 0,
						CURLOPT_FOLLOWLOCATION => true,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => 'POST',
						CURLOPT_POSTFIELDS =>'{
							"email" : "'.$apiTokenRow['dlt_email'].'",
							"password" : "'.$apiTokenRow['dlt_password'].'"
						}',
							CURLOPT_HTTPHEADER => array(
								'content-type: application/json'
							),
						));

						$response = curl_exec($curl);

						curl_close($curl);
						$res = (array)($response);
						$a = $destination_array = explode('"', $res[0]);
						$token = $a[5];

						$lclUpdate = "UPDATE delivery_api_token SET dlt_token = '".$token."',
																	dlt_updated_at = '".date('Y-m-d H:i:s')."'";
						$con->query($lclUpdate);

					}

				}

				echo json_encode(array("deliveryID" => $deliveryID, "token" => $token));
			} else {
				echo "10";
			}
		} else {
			echo "20";
		}
	}


	function getDeliveryInfo($params, $con) {
		$products = array();
		$lclQuery1 = "SELECT pd_name as name, pd_product_id as sku, ct_qty as qty, pd_discount_price as price,pd_discount as discount, pd_price as originalPrice FROM cart
		LEFT JOIN products ON products.pd_id = cart.ct_pd_id
		WHERE ct_us_id = '".$_SESSION['id']."'";
		$lclResult1 = $con->query($lclQuery1);
			
		while($row1 = $lclResult1->fetch(PDO::FETCH_ASSOC)) {
			$products[] = $row1;
		}

		$lclQuery3 = "SELECT pd_name as name, pd_product_id as sku, pd_discount_price as price, pd_discount as discount, pd_price as originalPrice FROM products WHERE pd_id = '".$params['product_id']."'";
		$lclResult3 = $con->query($lclQuery3);
			
		if($row3 = $lclResult3->fetch(PDO::FETCH_ASSOC)) {
			$object = (object) ['name' => $row3['name'],
                            'sku' => $row3['sku'],
                            'qty' => $params['quantity'],
                            'price' => $row3['price']
                        ];
			$products[] = (array)$object;

		}

		$newProducts = array();
		// echo count($products);
		for($i = 0; $i < count($products); $i++) {
			$productCode = substr($products[$i]['sku'], 0, 4);

			$pickupLocation = "SELECT * FROM pickup_location WHERE pl_code = '".$productCode."'";
			$pickupLocationRes = $con->query($pickupLocation);

			if($pickupLocationRow = $pickupLocationRes->fetch(PDO::FETCH_ASSOC)) {

				$object = (object) ['warehouse_name' => $pickupLocationRow['pl_warehouse_name'],
							'name' => $pickupLocationRow['pl_name'],
							'address' => $pickupLocationRow['pl_address'],
							'address_2' => '',
							'city' => $pickupLocationRow['pl_city'],
							'state' => $pickupLocationRow['pl_state'],
							'pincode' => $pickupLocationRow['pl_pincode'],
							'phone' => $pickupLocationRow['pl_phone']
						];

				array_push($newProducts, [$products[$i], (array)$object]);
			}
		}

		$address = array();
		$lclQuery2 = "SELECT ads_fullName, ads_mobile_number, ads_address, ads_city, ads_pincode, st_name FROM address 
		LEFT JOIN state ON state.st_id = address.ads_state
		WHERE ads_id = '".$params['txtAddress']."'";
		$lclResult2 = $con->query($lclQuery2);
			
		while($row2 = $lclResult2->fetch(PDO::FETCH_ASSOC)) {
			$address[] = $row2;
		}

		$sql1 = "SELECT count(*) FROM orders";
		$res1 = $con->query($sql1);
		$resCount1 = $res1->fetchColumn() + 1;
		$lclOrderID = str_pad($resCount1, 10, "ORD-00000", STR_PAD_LEFT);

		$lclOrderDate = date("Y-m-d");

		$apiToken = "SELECT * FROM delivery_api_token";
		$apiTokenRes = $con->query($apiToken);

		if($apiTokenRow = $apiTokenRes->fetch(PDO::FETCH_ASSOC)) {
			$datetime_1 = $apiTokenRow['dlt_updated_at'];
			$datetime_2 = date('Y-m-d H:i:s');
			
			$from_time = strtotime($datetime_1); 
			$to_time = strtotime($datetime_2); 
			$diff_minutes = round(abs($from_time - $to_time) / 60, 2);

			$token = $apiTokenRow['dlt_token'];

			if($diff_minutes > 160) {
				$curl = curl_init();

				curl_setopt_array($curl, array(
				CURLOPT_URL => 'https://api.nimbuspost.com/v1/users/login',
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => '',
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => 'POST',
				CURLOPT_POSTFIELDS =>'{
					"email" : "'.$apiTokenRow['dlt_email'].'",
					"password" : "'.$apiTokenRow['dlt_password'].'"
				}',
					CURLOPT_HTTPHEADER => array(
						'content-type: application/json'
					),
				));

				$response = curl_exec($curl);

				curl_close($curl);
				$res = (array)($response);
				$a = $destination_array = explode('"', $res[0]);
				$token = $a[5];

				$lclUpdate = "UPDATE delivery_api_token SET dlt_token = '".$token."',
															dlt_updated_at = '".date('Y-m-d H:i:s')."'";
				$con->query($lclUpdate);

			}

		}

		$orderDetails = array();

		for($i = 0; $i < count($newProducts); $i++) {

			$obj = '{
				"order_number": "'.$lclOrderID.'",
				"shipping_charges": "'.$params['shippingCharges'].'",
				"discount": 0,
				"cod_charges": 0,
				"payment_type": "cod",
				"order_amount": "'.$params['subTotal'].'",
				"request_auto_pickup" : "yes",
				"consignee": {
					"name": "'.$address[0]['ads_fullName'].'",
					"address": "'.$address[0]['ads_address'].'",
					"address_2": "",
					"city": "'.$address[0]['ads_city'].'",
					"state": "'.$address[0]['st_name'].'",
					"pincode": "'.$address[0]['ads_pincode'].'",
					"phone": "'.$address[0]['ads_mobile_number'].'"
				},

				"pickup": {
					"warehouse_name": "'.$newProducts[$i][1]['warehouse_name'].'",
					"name" : "'.$newProducts[$i][1]['name'].'",
					"address": "'.$newProducts[$i][1]['address'].'",
					"address_2": "",
					"city": "'.$newProducts[$i][1]['city'].'",
					"state": "'.$newProducts[$i][1]['state'].'",
					"pincode": "'.$newProducts[$i][1]['pincode'].'",
					"phone": "'.$newProducts[$i][1]['phone'].'"
				},
				"order_items": [
					{
						"name": "'.$newProducts[$i][0]['name'].'",
						"qty": "'.$newProducts[$i][0]['qty'].'",
						"price": "'.$newProducts[$i][0]['price'].'",
						"sku": "'.$newProducts[$i][0]['sku'].'"
					}
				],

				"courier_id" : "",
				  "is_insurance" : "0",
				  "tags" : ""
			}';

			
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => 'https://api.nimbuspost.com/v1/shipments',
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => '',
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => 'POST',
				CURLOPT_POSTFIELDS => $obj,
				CURLOPT_HTTPHEADER => array(
				  'Content-Type: application/json',
				  "Authorization: Bearer ".$token
				),
			  ));
			  
			  $response = curl_exec($curl);

			  
			  $res = json_decode(utf8_encode($response), true);

			  $object = (object) ['order_id' => $res["data"]['order_id'],
							'awb_number' => $res["data"]['awb_number'],
							'shipment_id' => $res["data"]['shipment_id'],
							'product_id' => $newProducts[$i][0]['sku']
						];
			if(!is_null($res["data"]['awb_number'])) {
				array_push($orderDetails, (array)$object);
			}

		}

		// generateInvoicePDF($newProducts, $lclOrderID, $address, $params['subTotal'], $params['totalAppliedCoins'], $params['shippingCharges'], $params['totalAmount']);

		echo json_encode(array("orderID" => $lclOrderID, 'orderDetails' => $orderDetails));

	}



	function generateInvoicePDF($newProducts, $lclOrderID, $address, $subTotal, $appliedCoins, $shippingCharges, $totalAmount) {
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

		$pdf->SetCreator(PDF_CREATOR);
		$pdf->SetAuthor('OS FASHION');
		$pdf->SetTitle('Invoice');

		$pdf->setPrintHeader(false);
		$pdf->setPrintFooter(false);

		$pdf->AddPage();

		$pdf->SetFont('helvetica', '', 12);

		$html = '<table>';
		$html .= '<tr><td style="width: 300px;"><img src="https://osfashion.in/img/logo.png" height="65"></td><td style="color: #e7ab3c; font-size: 30px; marging-top: 10px;">Invoice</td></tr>';
		$html .= '<tr><td style="width: 300px; font-weight: bold; font-family: Arial, Helvetica, sans-serif;">FROM,</td><td style="font-weight: bold;">PAID TO,</td></tr>';
		$html .= '<tr><td style="color: #404040;">'.$address[0]['ads_fullName'].'</td><td style="color: #404040;">One step fashion network.pvt ltd</td></tr>';
		$html .= '<tr><td style="color: #404040;">'.$address[0]['ads_address'].'</td><td style="color: #404040;">Bharati Sankul Building 2nd Floor</td></tr>';
		$html .= '<tr><td style="color: #404040;">'.$address[0]['ads_city'].', '.$address[0]['st_name'].'</td><td style="color: #404040;">Club Road, Belagavi,</td></tr>';
		$html .= '<tr><td style="color: #404040;">'.$address[0]['ads_pincode'].'</td><td style="color: #404040;">Karnataka Pin Code - 590001</td></tr>';
		$html .= '<tr><td style="color: #404040;">Order ID : '.$lclOrderID.'</td><td style="color: #404040;">29AADCO9781E1ZZ</td></tr>';
		$html .= '<tr><td style="color: #404040;">Date : '.date("d-M-Y").'</td><td></td></tr>';
		$html .= '</table>';


		$html .= '<table>';
		$html .= '<br><br><br><table style="margin-top: 20px;">';
		$html .= '<tr><td style="font-weight: bold; color: #404040;">Sl No</td><td style="font-weight: bold; color: #404040;">Name</td><td style="font-weight: bold; color: #404040;">Original Price</td><td style="font-weight: bold; color: #404040;">Discount</td><td style="font-weight: bold; color: #404040;">Price</td><td style="font-weight: bold; color: #404040;">Quantity</td><td style="font-weight: bold; color: #404040;">Total Price</td></tr><hr>';

		for($i = 0; $i < count($newProducts); $i++ ) {
			$totalPrice = $newProducts[$i][0]['price'] * $newProducts[$i][0]['qty'];
			$html .= '<tr><td style="color: #404040;">1</td><td style="color: #404040;">'.$newProducts[$i][0]['name'].'</td><td style="color: #404040;">'.$newProducts[$i][0]['originalPrice'].'</td><td style="color: #404040;">'.$newProducts[$i][0]['discount'].'</td><td style="color: #404040;">'.$newProducts[$i][0]['price'].'</td><td style="color: #404040;">'.$newProducts[$i][0]['qty'].'</td><td style="color: #404040;">'.$totalPrice.'</td></tr><hr>';
		}

		
		$html .= '</table>';

		$html .= '<table><br><br>';
		$html .= '<tr><td></td><td></td><td style="text-align: right;">Sub Total</td><td style="text-align: right;">'.$subTotal.'</td></tr>';
		$html .= '<tr><td></td><td></td><td style="text-align: right;">Shipping Charges</td><td style="text-align: right;">'.$shippingCharges.'</td></tr>';
		$html .= '<tr><td></td><td></td><td style="text-align: right;">Discount</td><td style="text-align: right;">'.$appliedCoins.'</td></tr><hr>';
		$html .= '<tr><td></td><td></td><td style="text-align: right;">Grand Total</td><td style="text-align: right;">'.$totalAmount.'</td></tr>';
		$html .= '</table>';

		$pdf->writeHTML($html, true, false, true, false, '');

		$pdfData = $pdf->Output($lclOrderID.'.pdf', 'S');

		$bucket = 'multimediastorage124243-dev';
		$key = $lclOrderID.'.pdf';

		$s3Client = new S3Client([
			'version' => '2006-03-01',
			'region'  => "us-east-1",
			'credentials' => [
				'key'    => 'AKIAQI3REVFIUJ7P6ZX3',
				'secret' => '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'
			]
		]);

		$result = $s3Client->putObject([
			'Bucket' => $bucket,
			'Key' => $key,
			'Body' => $pdfData,
			'ACL' => 'public-read',
		]);

		// echo 'PDF saved to S3: ' . $result['ObjectURL'];
	}

	function getUserHeirarchyDetails($params, $con) {

		$treeView = array();

		$recursiveTopToBottomQuery = "WITH RECURSIVE company_hierarchy AS (
            SELECT    us_id,
                        us_name,
                        us_mobile,
                        us_referred_user_id,
						us_referral_code,
                    0 AS hierarchy_level
            FROM users
            WHERE us_id = '".$_SESSION['id']."'
            UNION ALL
            SELECT    u.us_id,
                        u.us_name,
                        u.us_mobile,
                        u.us_referred_user_id,
						u.us_referral_code,
                    hierarchy_level + 1
            FROM users u, company_hierarchy ch
            WHERE u.us_referred_user_id = ch.us_id
            )
            
            SELECT  ch.us_id AS employee_id,
                    ch.us_name AS name,
                    ch.us_referral_code AS title,
                    ch.us_mobile AS employee_mobile,
                    u.us_id AS main_id,
                    u.us_name AS main_name,
                    u.us_mobile AS main_mobile,
                    hierarchy_level
            FROM company_hierarchy ch
            LEFT JOIN users u
            ON ch.us_referred_user_id = u.us_id
            ORDER BY ch.hierarchy_level, ch.us_id;";

        $recursiveTopToBottomResult = $con->query($recursiveTopToBottomQuery);
        $count = 0;
        while($recursiveTopToBottomRow = $recursiveTopToBottomResult->fetch(PDO::FETCH_ASSOC)) {
            if($count == 0) {

                $recursiveTopToBottomRow['main_id'] = null;
                $recursiveTopToBottomRow['main_name'] = null;
                $recursiveTopToBottomRow['main_mobile'] = null;
                $treeView[] = $recursiveTopToBottomRow;
            } else {

				// $recursiveTopToBottomRow['name'] = $recursiveTopToBottomRow['main_name'] . "Member";
                $treeView[] = $recursiveTopToBottomRow;
            }
            $count++;
            
        }

		echo json_encode($treeView);
	}

	function getCreditHistory($params, $con) {
		$creditHistoryArray = array();
		$creditHistory = "SELECT * FROM amount_credit_history
		LEFT JOIN users ON users.us_id = amount_credit_history.ach_us_id
		WHERE (ach_main_id = '".$_SESSION['id']."') AND (ach_type != 'coin_credits' AND ach_type != 'business_rank') ORDER BY amount_credit_history.ach_level ASC";
		$creditHistoryResult = $con->query($creditHistory);

		while($creditHistoryRow = $creditHistoryResult->fetch(PDO::FETCH_ASSOC)) {
			$creditHistoryArray[] = $creditHistoryRow;
		}

		echo json_encode(array("creditHistoryArray" => $creditHistoryArray));
	}

	function levelDetails($params, $con) {
		$levelDetails = array();
		$lvlHistory = "SELECT count(*) AS users, li_level_count FROM level_information
		WHERE li_main_user_id = '".$_SESSION['id']."' GROUP BY li_level_count ORDER BY li_level_count ASC";
		$lvlHistoryResult = $con->query($lvlHistory);

		while($lvlHistoryRow = $lvlHistoryResult->fetch(PDO::FETCH_ASSOC)) {

			$totalAmountNoWithinDays = "SELECT ach_percentage, COALESCE(SUM(ach_amount),0) AS totalAmountNoWithinDays, COALESCE(SUM(ach_bv),0) AS totalBVNoWithinDays FROM amount_credit_history WHERE ach_level = ".$lvlHistoryRow['li_level_count']." AND ach_main_id = '".$_SESSION['id']."' AND ach_type = 'no_within_days'";
			$totalAmountNoWithinDaysRes = $con->query($totalAmountNoWithinDays);

			if($totalAmountNoWithinDaysRow = $totalAmountNoWithinDaysRes->fetch(PDO::FETCH_ASSOC)) {
				$lvlHistoryRow['totalAmountNoWithinDays'] = $totalAmountNoWithinDaysRow['totalAmountNoWithinDays'];
				$lvlHistoryRow['totalBVNoWithinDays'] = $totalAmountNoWithinDaysRow['totalBVNoWithinDays'];
				$lvlHistoryRow['achPercentageNoWithinDays'] = $totalAmountNoWithinDaysRow['ach_percentage'];
				// $levelDetails[] = $lvlHistoryRow;
			}

			$totalAmountWithinDays = "SELECT ach_percentage, COALESCE(SUM(ach_amount),0) AS totalAmountWithinDays, COALESCE(SUM(ach_bv),0) AS totalBVWithinDays FROM amount_credit_history WHERE ach_level = ".$lvlHistoryRow['li_level_count']." AND ach_main_id = '".$_SESSION['id']."' AND ach_type = 'within_days'";
			$totalAmountWithinDaysRes = $con->query($totalAmountWithinDays);

			if($totalAmountWithinDaysRow = $totalAmountWithinDaysRes->fetch(PDO::FETCH_ASSOC)) {
				$lvlHistoryRow['totalAmountWithinDays'] = $totalAmountWithinDaysRow['totalAmountWithinDays'];
				$lvlHistoryRow['totalBVWithinDays'] = $totalAmountWithinDaysRow['totalBVWithinDays'];
				$lvlHistoryRow['achPercentageWithinDays'] = $totalAmountWithinDaysRow['ach_percentage'];
				// $levelDetails[] = $lvlHistoryRow;
			}

			$levelDetails[] = $lvlHistoryRow;
		}

		echo json_encode(array("levelDetails" => $levelDetails));
	}

function gerCreditsBySearch($params, $con) {

	$toDate = date('Y-m-d', strtotime($params['toDate'] . ' +1 day'));

	if($params['fromDate'] != "" && $params['toDate'] != "" && $params['txtName'] != "" && $params['txtReferCode'] == "") {

		$creditHistoryArray = array();
		$creditHistory = "SELECT * FROM amount_credit_history
		LEFT JOIN users ON users.us_id = amount_credit_history.ach_us_id
		WHERE amount_credit_history.ach_created_date BETWEEN '".$params['fromDate']."' AND '".$toDate."' AND users.us_name = '".$params['txtName']."' AND ach_main_id = '".$_SESSION['id']."'";
		$creditHistoryResult = $con->query($creditHistory);

		while($creditHistoryRow = $creditHistoryResult->fetch(PDO::FETCH_ASSOC)) {
			$creditHistoryArray[] = $creditHistoryRow;
		}

	} else if($params['fromDate'] != "" && $params['toDate'] != "" && $params['txtName'] == "" && $params['txtReferCode'] == "") {

		$creditHistoryArray = array();
		$creditHistory = "SELECT * FROM amount_credit_history
		LEFT JOIN users ON users.us_id = amount_credit_history.ach_us_id
		WHERE amount_credit_history.ach_created_date BETWEEN '".$params['fromDate']."' AND '".$toDate."' AND ach_main_id = '".$_SESSION['id']."'";
		$creditHistoryResult = $con->query($creditHistory);

		while($creditHistoryRow = $creditHistoryResult->fetch(PDO::FETCH_ASSOC)) {
			$creditHistoryArray[] = $creditHistoryRow;
		}

	} else if($params['txtName'] != "" && $params['txtReferCode'] == "") {
		$creditHistoryArray = array();
		$creditHistory = "SELECT * FROM amount_credit_history
		LEFT JOIN users ON users.us_id = amount_credit_history.ach_us_id
		WHERE users.us_name = '".$params['txtName']."' AND ach_main_id = '".$_SESSION['id']."'";
		$creditHistoryResult = $con->query($creditHistory);

		while($creditHistoryRow = $creditHistoryResult->fetch(PDO::FETCH_ASSOC)) {
			$creditHistoryArray[] = $creditHistoryRow;
		}
	} else {
		$creditHistoryArray = array();
		$creditHistory = "SELECT * FROM amount_credit_history
		LEFT JOIN users ON users.us_id = amount_credit_history.ach_us_id
		WHERE users.us_referral_code = '".$params['txtReferCode']."' AND ach_main_id = '".$_SESSION['id']."'";
		$creditHistoryResult = $con->query($creditHistory);

		while($creditHistoryRow = $creditHistoryResult->fetch(PDO::FETCH_ASSOC)) {
			$creditHistoryArray[] = $creditHistoryRow;
		}
	}

	echo json_encode(array("creditHistoryArray" => $creditHistoryArray));

}
<?php

session_start();

include_once('conn/conn.php');
$db = new DatabaseClass();
$con = $db->getCon();
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <style>
        .checkout-add-adress:hover{
            color:black !important;
        }
        .checkout-add-adress:focus{
            color:black !important;
        }
        .checkout-add-adress{
            text-decoration: underline;
            font-size: 20px;
        }

        .form-control:disabled {
            background-color: black !important;
        }
    </style>
</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text product-more">
                        <a href="./index.php"><i class="fa fa-home"></i> Home</a>
                        <a href="./shop.php">Shop</a>
                        <span>Check Out</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Shopping Cart Section Begin -->
    <section class="checkout-section spad">
        <div class="container">
            <form action="#" class="checkout-form">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="checkout-content d-none">
                            <a href="Javascript:void(0)" class="content-btn">CHECKOUT</a>
                        </div>
                        <input type="hidden" value="<?php echo $_GET['q'] ?? '' ?>" id="product_id">
                        <input type="hidden" value="<?php echo $_GET['qty'] ?? '' ?>" id="quantity">
                        <input type="hidden" value="<?php echo $_GET['color'] ?? '' ?>" id="color">
                        <input type="hidden" value="<?php echo $_GET['size'] ?? '' ?>" id="size">
                        <h4>Billing Details</h4>
                        <div class="row d-none">

                            <div class="col-lg-6">
                                <label for="fir">Full Name<span>*</span></label>
                                <input type="text" id="txtName">
                            </div>

                            <div class="col-lg-6">
                                <label for="email">Email Address</label>
                                <input type="text" id="txtEmailID">
                            </div>

                            <div class="col-lg-12">
                                <label for="phone">Mobile<span>*</span></label>
                                <input type="text" id="txtMobileNo" maxlength="10">
                            </div>

                        </div>

                        <div>
                           <a href="javascript:void(0)" class="checkout-add-adress" id="addres-btn">Add address</a>
                        </div>

                        <div class="row mt-3" style="display:none" id="address-tab">

                            <div class="col-lg-6">
                                <label for="inputEmail4" class="text-left">Full Name</label>
                                <input type="text" class="form-control" id="txtFullName" placeholder="Full Name"
                                    value="">
                            </div>


                            <div class="col-lg-6">
                                <label for="inputPassword4" class="text-left">Mobile Number</label>
                                <input type="text" class="form-control" id="txtMobileNo1" placeholder="Mobile Number"
                                    onkeypress="return isNumberKey(event);" maxlength="10">
                            </div>

                            <div class="col-lg-6">
                                <label for="inputAddress" class="text-left">Address</label>
                                <input type="text" class="form-control" id="txtAddress" placeholder="Address" value="">
                            </div>

                            <div class="col-lg-6 d-none">
                                <label for="inputAddress2" class="text-left">Address
                                    2<span>(optional)</span></label>
                                <input type="text" class="form-control" id="txtAddress2" placeholder="">
                            </div>

                            <div class="col-lg-6">
                                <label for="inputCity" class="text-left">City</label>
                                <input type="text" class="form-control" id="txtCity" placeholder="city" value="">
                            </div>

                            <div class="col-lg-6">
                                <label for="inputState" class="text-left">State</label>
                                <select id="txtState" class="form-control">
                                    <option selected value="">Choose...</option>
                                    <?php
                                    $sql = "SELECT DISTINCT(st_name), st_id FROM state ORDER BY st_name ASC";
                                    $query = $con->query($sql);
                                    while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
                                        echo '<option value="' . $row['st_id'] . '">' . $row['st_name'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="col-lg-6">
                                <label for="inputZip" class="text-left">Pincode</label>
                                <input type="text" class="form-control" id="txtPincode" placeholder="pincode" onkeypress="return isNumberKey(event);" maxlength="6" value="">
                            </div>

                            <div class="col-lg-6">
                                <button type="button" class=" primary-btn" id="addNewAddress" value="Submit">Save</button>
                            </div>


                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="checkout-content d-none">
                            <input type="text" placeholder="Enter Your Coupon Code">
                        </div>
                        <div class="place-order">
                            <h4>Your Order</h4>
                            <div class="order-total">
                                <ul class="order-table" id="productDetails">
                                    <li>Product <span>Total</span></li>
                                </ul>

                                <ul class="order-table">
                                    <li class="fw-normal">Subtotal <span id="subTotal">₹0.00</span></li>
                                    <li class="fw-normal">BV <span id="totalBV">0</span></li>
                                    <li class="fw-normal">Shipping Charges <span id="shippingCharges">₹0.00</span></li>
                                    <li class="fw-normal check-coins"><input type="button" id="applyCoins" class="primary-btn form-control" value="Redeem Coins" style="padding: 4px 30px; width: 166px; height: 32px;"> <span id="totalCoins">0</span></li>
                                    <li class="total-price">Total <span id="totalAmount">₹0.00</span></li>
                                </ul>

                                <div class="col-lg-12 mb-5" id="selAddress">
                                    <label for="street">Address<span>*</span></label><br>
                                </div>
                                <div class="payment-check">
                                    <div class="pc-item d-none">
                                        <label for="pc-check">
                                            Online Payment
                                            <input type="radio" name="payment" id="pc-check" value="Online">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    <br>
                                    <div class="pc-item">
                                        <label for="pc-paypal">
                                            Cash on Delivery
                                            <input type="radio" name="payment" id="pc-paypal" value="Cash On Delivery" checked>
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="order-btn">
                                    <button type="button" class="site-btn place-btn" id="checkout">Place Order</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!-- Shopping Cart Section End -->

    <!-- Modal -->
    <div class="modal fade" id="onlinePaymentQrCode" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Scan QR code and Pay</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body text-center">
            <div>
                <img src="img/qr.jpg" height="150">
            </div>

            <h5 class="p-4">UPI ID <input type="text" id="myInput"
                                            style="border: none;display: inline;font-weight: bold;" size="12" value="matin1991@ybl" readonly> <i class="fa fa-clone" aria-hidden="true" onclick="myFunction()"
                                            style=" margin-top: 5px; color: #e7ab3c; font-weight: bold; font-size: 20px;">
                                            <span class="tooltiptext" id="myTooltip" style="font-size:15px"></span>
                                        </i></h5>
            <div class="row">
                <div class="form-group col-sm-6">
                    <label class="text-start">Account Name</label>
                    <input type="text" class="form-control" id="qrPaymentAccountName">
                </div>

                <div class="form-group col-sm-6">
                    <label class="text-start">Account Number/ UPI ID</label>
                    <input type="text" class="form-control" id="qrPaymentAccountNumber">
                </div>
            </div>
        </div>
        <div class="text-center mb-3">
            <button type="button" class="btn btn-secondary" style="height: 46px;" data-dismiss="modal">Close</button>
            <button type="button" class="btn site-btn place-btn text-white" id="proceedQRCheckout">Place Order</button>
        </div>
        </div>
    </div>
    </div>

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsCheckout.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>
</body>

</html>

<script>

function myFunction() {
    let checkCopyText = document.getElementById("myInput").value;

    if (checkCopyText == "No Referral") {
        alert("Please purchase product for Referral Code");
        return false;
    }

    let copyText = document.getElementById("myInput");

    copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.value);

    let tooltip = document.getElementById("myTooltip");
    tooltip.innerHTML = "Copied ";

    setTimeout(() => {
        tooltip.innerHTML = "";
    }, 2000);
}
</script>
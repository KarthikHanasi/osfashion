<?php

	$sql_details = array(
		'host' => 'localhost',
		'db'   => 'fashion',
	    'user' => 'root',
	    'pass' => ''
	);


?>
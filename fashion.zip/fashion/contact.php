<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description"
        content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>Contact</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Map Section Begin -->
    <div class="map spad d-none">
        <div class="container">
            <div class="map-inner">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3838.4293341865186!2d74.5017787148721!3d15.834016649904095!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf66a455555555%3A0x68be6a454d516476!2sInfynow%20Software%20Solutions%20LLP!5e0!3m2!1sen!2sin!4v1678970327129!5m2!1sen!2sin"
                    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
                <div class="icon">
                    <i class="fa fa-map-marker"></i>
                </div>
            </div>
        </div>
    </div>
    <!-- Map Section Begin -->

    <!-- Contact Section Begin -->
    <section class="contact-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="contact-title">
                        <h4>Contacts <span> Us </span></h4>
                        <p class="mt-4"><b>One step fashion network.pvt ltd</b></p>
                    </div>
                    <div class="contact-widget">
                        <div class="cw-item">
                            <div class="ci-icon">
                                <i class="ti-location-pin"></i>
                            </div>
                            <div class="ci-text">
                                <span>Address:</span>
                                <p>Bharati Sankul Building 2nd Floor, Club Road, Belagavi, Karnataka Pin Code - 590001
                                </p>
                            </div>
                        </div>
                        <div class="cw-item">
                            <div class="ci-icon">
                                <i class="ti-mobile"></i>
                            </div>
                            <div class="ci-text">
                                <span>Phone:</span>
                                <p>+91 98453 01177</p>
                                <p>+91 6362864949</p>
                                <p>+91 97318 98229</p>
                            </div>
                        </div>
                        <div class="cw-item">
                            <div class="ci-icon">
                                <i class="ti-email"></i>
                            </div>
                            <div class="ci-text">
                                <span>Email:</span>
                                <p>osfashionetwork@gmail.com</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 ">
                    <div class="contact-form">
                        <div class="leave-comment">
                            <h4>Leave A <span> Comment </span></h4>
                            <!-- <p>Our staff will call back later and answer your questions.</p> -->
                            <form class="comment-form mt-4">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <input type="text" placeholder="Name" id="txtName">
                                    </div>
                                    <div class="col-lg-6">
                                        <input type="text" placeholder="Mobile" id="txtMobileNo" onkeypress="return isNumberKey(event);" maxlength="10">

                                    </div>
                                    <div class="col-lg-12">
                                        <input type="email" placeholder="Email" id="txtEmail">
                                    </div>
                                    <div class="col-lg-12">
                                        <textarea placeholder="Your message" id="txtMessage"></textarea>
                                        <button type="button" class="site-btn" id="submit-contact">Send message</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->
    <div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3837.764889029675!2d74.50463147430773!3d15.86894964477011!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf67a30ac56a2f%3A0xf09f202d501c9098!2sOne%20step%20fashion%20network%20Pvt.Ltd!5e0!3m2!1sen!2sin!4v1687158795267!5m2!1sen!2sin"  height="450" style="border:0; width: 100%;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/js/jsContact.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>
</body>

</html>
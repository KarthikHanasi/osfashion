



// <?php
// require 'vendor/autoload.php';
// use Netflie\WhatsAppCloudApi\WhatsAppCloudApi;
// use Netflie\WhatsAppCloudApi\Message\Media\LinkID;
// use Netflie\WhatsAppCloudApi\Message\Media\MediaObjectID;

// $document_id = '341476474779872';
// $document_name = 'whatsapp-cloud-api-from-id.pdf';
// $document_caption = "WhastApp API Cloud Guide";

// // Instantiate the WhatsAppCloudApi super class.
// $whatsapp_cloud_api = new WhatsAppCloudApi([
//     'from_phone_number_id' => '100492896388925',
//     'access_token' => 'EAAJEMf5ULI8BAAupYtQjJwyFD0AyrTYoMuObkNmUyp56PsdphgJddDcnk92kuHgL6dqvM8p7z1O5j4KE1CCOZA8QepFPv95N7t4z1bUmjFJt0WfzkMLg4MWC9GCUpmsDtb4gn4l0sprfcq0UYvHEKBJZBClmlGaFXKwJwZBv3vr6fwkWSp1rgciacZCTl4IZD',
// ]);

// // With the Media Object ID of some document upload on the WhatsApp Cloud servers
// // $media_id = new MediaObjectID($document_id);
// // $whatsapp_cloud_api->sendDocument('919611860475', $media_id, $document_name, $document_caption);

// // Or
// // $document_link = 'https://multimediastorage124243-dev.s3.amazonaws.com/Kitchen%20and%20Home%20Appliances.png';
// // $link_id = new LinkID($document_link);
// // $whatsapp_cloud_api->sendDocument('919611860475', $link_id, $document_name, $document_caption);
// // var_dump($whatsapp_cloud_api);


// $whatsapp_cloud_api->sendTemplate('919611860475', 'marketing1', 'en_US'); // Language is optional


$html = '
<html>
<head>
<style type="text/css">
  @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);
  body { margin: 0; padding: 0; background: #e1e1e1; }
  div, p, a, li, td { -webkit-text-size-adjust: none; }
  .ReadMsgBody { width: 100%; background-color: #ffffff; }
  .ExternalClass { width: 100%; background-color: #ffffff; }
  body { width: 100%; height: 100%; background-color: #e1e1e1; margin: 0; padding: 0; -webkit-font-smoothing: antialiased; }
  html { width: 100%; }
  p { padding: 0 !important; margin-top: 0 !important; margin-right: 0 !important; margin-bottom: 0 !important; margin-left: 0 !important; }
  .visibleMobile { display: none; }
  .hiddenMobile { display: block; }

  @media only screen and (max-width: 600px) {
  body { width: auto !important; }
  table[class=fullTable] { width: 96% !important; clear: both; }
  table[class=fullPadding] { width: 85% !important; clear: both; }
  table[class=col] { width: 45% !important; }
  .erase { display: none; }
  }

  @media only screen and (max-width: 420px) {
  table[class=fullTable] { width: 100% !important; clear: both; }
  table[class=fullPadding] { width: 85% !important; clear: both; }
  table[class=col] { width: 100% !important; clear: both; }
  table[class=col] td { text-align: left !important; }
  .erase { display: none; font-size: 0; max-height: 0; line-height: 0; padding: 0; }
  .visibleMobile { display: block !important; }
  .hiddenMobile { display: none !important; }
  }
</style>
</head>
<body>';


  
// if (mysqli_num_rows($result) > 0) { 

// while($row =$result->fetch(PDO::FETCH_ASSOC)){
  require_once __DIR__ . '/backend/mpdf/autoload.php';
  $mpdf = new \Mpdf\Mpdf();
  // echo "Hello";
  
  $html .='
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">
  <tr>
    <td height="20"></td>
  </tr>
  <tr>
    <td>
      <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff" style="border-radius: 10px 10px 0 0;">
        <tr class="visibleMobile">
          <td height="30"></td>
        </tr>

        <tr>
          <td>
            <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
              <tbody>
                <tr>
                  <td>
                      <table width="220" border="0" cellpadding="0" cellspacing="0" align="left" class="col">
                      <tbody>
                        <tr>
                          <td align="left"> <img src="https://osfashion.in/img/logo.png" width="50" height="50" alt="logo" border="0" /></td>
                        </tr>
                        <tr class="visibleMobile">
                          <td height="20"></td>
                        </tr>
                        <tr>
                          <td style="font-size: 12px; color: #5b5b5b; font-family: "Open Sans", sans-serif; line-height: 18px; vertical-align: top; text-align: left;">
                            Hello [Full Name], <br>
                            <br> Thank you very much for upgrading your Qlearly account and for support us!
                          </td>
                        </tr>
                        <tr>
                          <td style="font-size: 12px; color: #5b5b5b; font-family: "Open Sans", sans-serif; line-height: 18px; vertical-align: top; text-align: left;">
                            <small>ORDER</small> #800000025<br />
                            <small>MARCH 4TH 2018</small>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    </td>
                    <td>
                      <table width="220" border="0" cellpadding="0" cellspacing="0" align="right" class="col">
                      <tbody>
                        <tr class="visibleMobile">
                          <td height="20"></td>
                        </tr>
                        <tr>
                          <td height="5"></td>
                        </tr>
                        <tr>
                          <td style="font-size: 21px; color: #0EADF0; letter-spacing: -1px; font-family: "Open Sans", sans-serif; line-height: 1; vertical-align: top; text-align: right;">
                            Invoice
                          </td>
                        </tr>
                        <tr>
                        <tr class="visibleMobile">
                          <td height="20"></td>
                        </tr>
                        <tr>
                          <td style="font-size: 11px; font-family: "Open Sans", sans-serif; color: #5b5b5b; line-height: 1; text-align: right;">
                            <strong>PAID TO</strong>
                          </td>
                        </tr>
                        <tr>
                          <td width="100%" height="10"></td>
                        </tr>
                        <tr>
                          <td style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #5b5b5b; line-height: 20px; text-align: right; ">
                            Qlearly<br>227 Sw 21st Ct<br> Miami, FL<br> 33135, United States<br> Email: guillaume@qlearly.com
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>

<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">
  <tbody>
    <tr>
      <td>
        <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff">
          <tbody>
            <tr>
            <tr class="visibleMobile">
              <td height="20"></td>
            </tr>
            <tr>
              <td>
                <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
                  <tbody>
                    <tr>
                      <th style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #5b5b5b; font-weight: normal; line-height: 1; vertical-align: top; padding: 0 10px 7px 0;" width="52%" align="left">
                        Item
                      </th>
                      <th style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #5b5b5b; font-weight: normal; line-height: 1; vertical-align: top; padding: 0 0 7px;" align="center">
                        Quantity
                      </th>
                      <th style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #1e2b33; font-weight: normal; line-height: 1; vertical-align: top; padding: 0 0 7px;" align="right">
                        Subtotal
                      </th>
                    </tr>
                    <tr>
                      <td height="1" style="background: #bebebe;" colspan="4"></td>
                    </tr>
                    <tr>
                      <td height="10" colspan="4"></td>
                    </tr>
                    <tr>
                      <td style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #0EADF0;  line-height: 18px;  vertical-align: top; padding:10px 0;" class="article">
                        Qlearly Premium Plan
                      </td>
                      
                      <td style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #646a6e;  line-height: 18px;  vertical-align: top; padding:10px 0;" align="center">1</td>
                      <td style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #1e2b33;  line-height: 18px;  vertical-align: top; padding:10px 0;" align="right">₹ 5.00</td>
                    </tr>
                    <tr>
                      <td height="1" colspan="4" style="border-bottom:1px solid #e4e4e4"></td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <td height="20"></td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
  </tbody>
</table>

<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">
  <tbody>
    <tr>
      <td>
        <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff">
          <tbody>
            <tr>
              <td>
                <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
                  <tbody>
                    <tr>
                      <td style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #646a6e; line-height: 22px; vertical-align: top; text-align:right; ">
                        Subtotal
                      </td>
                      <td style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #646a6e; line-height: 22px; vertical-align: top; text-align:right; white-space:nowrap;" width="80">
                        ₹ 5.00
                      </td>
                    </tr>
                    
                    <tr>
                      <td style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #000; line-height: 22px; vertical-align: top; text-align:right; ">
                        <strong>Grand Total (Incl.Tax)</strong>
                      </td>
                      <td style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #000; line-height: 22px; vertical-align: top; text-align:right; ">
                        <strong>₹ 5.00</strong>
                      </td>
                    </tr>
                    <tr>
                      </td>
                    </tr>
                  </tbody>
                </table>

              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
  </tbody>
</table>

<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">
  <tbody>
    <tr>
      <td>
        <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff">
          <tbody>
            <tr>
            <tr class="hiddenMobile">
              <td height="60"></td>
            </tr>
            <tr class="visibleMobile">
              <td height="40"></td>
            </tr>
            <tr>
              <td>
                <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
                  <tbody>
                    <tr>
                      <td>
                        <table width="220" border="0" cellpadding="0" cellspacing="0" align="left" class="col">

                          <tbody>
                            <tr>
                              <td style="font-size: 11px; font-family: "Open Sans", sans-serif; color: #5b5b5b; line-height: 1; vertical-align: top; ">
                                <strong>BILLING INFORMATION</strong>
                              </td>
                            </tr>
                            <tr>
                              <td width="100%" height="10"></td>
                            </tr>
                            <tr>
                              <td style="font-size: 12px; font-family: "Open Sans", sans-serif; color: #5b5b5b; line-height: 20px; vertical-align: top; ">
                                Philip Brooks<br> Adress: N/A<br>Country: N/A<br> Zip: N/A<br> T: N/A
                              </td>
                            </tr>
                            <tr>
                              <td width="100%" height="30"></td>
                            </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            
          </tbody>
        </table>
      </td>
    </tr>
  </tbody>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">

  <tr>
    <td>
      <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff" style="border-radius: 0 0 10px 10px;">
        <tr>
          <td>
            <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
              <tbody>
                <tr>
                  <td style="font-size: 12px; color: #5b5b5b; font-family: "Open Sans", sans-serif; line-height: 18px; vertical-align: top; text-align: left;">
                    
              </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr class="spacer">
          <td height="50"></td>
        </tr>

      </table>
    </td>
  </tr>
  <tr>
    <td height="100"></td>
  </tr>
</table>';

$html .= '</body>
</html> ';

require_once __DIR__ . '/backend/mpdf/autoload.php';

$mpdf = new \Mpdf\Mpdf();


$mpdf = new \Mpdf\Mpdf([
  // 'margin_left' => 20,
//   'margin_right' => 15,
//   'margin_top' => 48,
//   'margin_bottom' => 25,
//   'margin_header' => 10,
  'margin_footer' => 30
]);
// $mpdf->SetColumns(2, 'J', 3);

$mpdf->SetTitle("Invoice");
$mpdf->showWatermarkText = true;
$mpdf->watermark_font = 'DejaVuSansCondensed';
$mpdf->watermarkTextAlpha = 0.1;
$mpdf->SetDisplayMode('fullpage');

$mpdf->WriteHTML($html);

$mpdf->Output();


<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.nimbuspost.com/v1/shipments',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{
    "cod_charges": 0,
    "consignee": {
        "address": "Address",
        "address_2": "",
        "city": "bgv",
        "name": "Karthik",
        "phone": "9611860475",
        "pincode": "590010",
        "state": "Andra Pradesh"
    },
    "courier_id": "",
    "discount": 0,
    "is_insurance": "0",
    "order_amount": "90",
    "order_items": [
        {
            "name": "product 1",
            "price": "100",
            "qty": "18",
            "sku": "sku001"
        }
    ],
    "order_number": "Karthik",
    "payment_type": "cod",
    "pickup": {
        "address": "OS Fashion, 2nd floor, Bharti Sankul, Above RBL bank, club road, Belagavi, Karnataka 590015",
        "address_2": "",
        "city": "Belagavi",
        "name": "Os Fashion",
        "phone": "9845301177",
        "pincode": "590001",
        "state": "Karnataka",
        "warehouse_name": "Os Fashion"
    },
    "request_auto_pickup": "yes",
    "shipping_charges": "4",
    "tags": ""
}',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json',
    "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE2ODY2NjA3NjUsImp0aSI6IjJYKys1dHRCcFN4cXlEZDRyeitiVUpLRG9kdXV6ZDJsVDVUWG4wYURocGM9IiwibmJmIjoxNjg2NjYwNzY1LCJleHAiOjE2ODY2NzE1NjUsImRhdGEiOnsidXNlcl9pZCI6IjkxMDY5IiwicGFyZW50X2lkIjoiMSJ9fQ.H2m6K1B-wLSQZKH-KbUWS3xrRo5mYBFE7j-IrOiP7mnk3W-eWCQPG2JOXQdZzGX4hxIjx7zu6BqApVJsG4yh6Q"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
$res = json_decode(utf8_encode($response), true);
var_dump($res["data"]);

echo $response;
<?php

$ch = curl_init();
		$accessToken = 'EAAJEMf5ULI8BAAupYtQjJwyFD0AyrTYoMuObkNmUyp56PsdphgJddDcnk92kuHgL6dqvM8p7z1O5j4KE1CCOZA8QepFPv95N7t4z1bUmjFJt0WfzkMLg4MWC9GCUpmsDtb4gn4l0sprfcq0UYvHEKBJZBClmlGaFXKwJwZBv3vr6fwkWSp1rgciacZCTl4IZD';

$messageData1 = array(
    'messaging_product' => "whatsapp",
    'to' => '919611860475',
    'type' => "template",
    'template' => array("name"=> "marketing1",'language'=>array("code"=>"en_US"),'components'=> 
       array(array(
        "type" => "body",
        "parameters" => array(array("type"=> "text","text"=> 123456)))))
);

curl_setopt($ch, CURLOPT_URL,"https://graph.facebook.com/v16.0/100492896388925/messages");
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Bearer $accessToken"));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($messageData1));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
echo $server_output = curl_exec($ch);
curl_close($ch);
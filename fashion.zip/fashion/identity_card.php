<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description"
        content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>My ID Card</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <!-- My Profile Begin -->
    <div class="my-profile mt-5">
        <div class="container">
            <div class="mobile-quick-access">
                <div class="row">
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="myprofile.php" class="text-dark">My Profile</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow  p-2 text-center">
                        <a href="my_orders.php" class="text-dark">My Orders</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="mlm.php" class="text-dark">My Network</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="add_address.php" class="text-dark">Add Address</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="my_credit_history.php" class="text-dark">My Credits</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="withdraw.php" class="text-dark">My Withdrawal</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="kyc.php" class="text-dark">My KYC</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center my-profile-color">
                        <a href="identity_card.php" class="text-white">My ID</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="networking_business_plan.php" class="text-dark">N & B Plans</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3 desktop-quick-access">
                    <div class="profile-q-title ">
                        <h4>Quick Access</h4>
                    </div>
                    <ul class="quick-menu">
                        <li class="list"><a href="myprofile.php">My Profile</a></li>
                        <li class="list"><a href="my_orders.php">My Orders</a></li>
                        <li class="list"><a href="mlm.php">My Network</a></li>
                        <li class="list"><a href="add_address.php">Add Address</a></li>
                        <li class="list"><a href="my_credit_history.php">My Credits</a></li>
                        <li class="list"><a href="withdraw.php">My Withdrawal</a></li>
                        <li class="list"><a href="kyc.php">My KYC</a></li>
                        <li class="list"><a href="identity_card.php">My ID</a></li>
                        <li class="list"><a href="networking_business_plan.php">N & B Plans</a></li>

                    </ul>
                </div>

                <div style="height: 26rem; width: 18rem; background-color: white;
                    border-radius: 10px; box-shadow: 0 6px 20px 0 rgba(0, 0, 0, 0.2),0 4px 8px 0 rgba(0, 0, 0, 0.19);" id="front">
                    <!-- logo --image  -->
                    <div style="display: flex; align-items: center; justify-content: center">
                        <img src="https://osfashion.in/img/logo.png" alt="" style="width: 85px; height: 85px; margin-top: 10px" />
                    </div>
                    <!-- profile image -->
                    <div style="display: flex; align-items: center; justify-content: center">
                        <img src=""
                            alt="" style="
                        width: 150px;
                        height: 150px;
                        border: 2px solid black;
                        margin-top: 4%;
                        border-radius: 15px;
                    " id="profile-card"/>
                    </div>

                    <!-- user info rounded div  -->
                    <div style="height: 190px; width: 100%; background-color: #e7ab3c; margin-top: 4%; border-radius: 0px 130px 0px 0px;">
                        <!-- user name -->
                        <div style="
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 30px;
                        font-family: 'Poppins', sans-serif;
                        color: white;
                        font-weight: bold;
                    ">
                            <span style="position: relative; top: 20px" id="txtName">Os Fashion</span>
                        </div>

                        <div style="text-align: center; color: white; font-size: 15px; font-family: 'Poppins', sans-serif;">
                            <span style="position: relative; top: 20px" id="designation">Managing Director</span>
                        </div>
                        <div style="text-align: center; color: white; font-size: 15px; font-family: 'Poppins', sans-serif;">
                            <span style="position: relative; top: 20px" id="email">ajeet.infynow@gmail.com</span>
                        </div>
                        <div style="text-align: center; color: white; font-size: 15px; font-family: 'Poppins', sans-serif;">
                            <span style="position: relative; top: 20px" id="phone">+91 1234567890</span>
                        </div>
                        <div style="text-align: center; color: white; font-size: 15px; font-family: 'Poppins', sans-serif;">
                            <span style="position: relative; top: 20px" id="joining_date">01 Jan 2023</span>
                        </div>
                        <div style="text-align: center; color: white; font-size: 15px; font-family: 'Poppins', sans-serif;">
                            <span style="position: relative; top: 20px" id="bloodGroup">B+</span>
                        </div>

                    </div>

                    <div
                        style="height: 35px; width: 100%; background-color: black; border-radius: 0px 0px 9px 9px; text-align: center; color: white;  font-family: 'Poppins', sans-serif; letter-spacing: 2px; font-size: 18px;">
                        www.osfashion.com
                    </div>

                </div>

            

                <div style=" box-shadow: 0 2rem 5rem 1rem rgba(0, 5, 15, 0.2); 
                    width: 18rem; margin-left: 10%; border-radius: 10px; border-radius: 9px 9px 0px 0px;" id="back">

                    <div style=" height: 70px;
                        background-color: #e7ab3c;
                        border-radius: 9px 9px 130px 0px;
                        box-shadow: 0 2rem 5rem 1rem rgba(0, 5, 15, 0.1); ">
                    </div> 

                    <div style=" font-size: 12px;
                        text-align: left;
                        padding: 20px; 
                        font-family: 'Poppins', sans-serif;">
                        <li >To be returned upon cessation of employement</li> 
                        <li>If lost inform HR/Security Immediatley</li>   
                    </div>

                    <div style="text-align: center;">
                        <img src="https://www.osfashion.in/img/logo.png" style=" width: 95px;">
                        </div>

                        <div style="font-size: 14px; font-family: 'Poppins', sans-serif; font-weight: bold; text-align: center; margin-bottom: 24px;">
                                <p style="line-height: 33px; color: black; font-weight: 500;">Bharati Sankul Building 2nd Floor, Club Road, Belagavi, Karnataka 
                                     Pin Code - 590001 
                                     Phone No. +91 98453 01177, 0831 4059426
                                <p style="font-weight: 500;">info@osfashion.in</p>
                        </div>
                        
                        <div style="text-align: center; background-color: black; border-radius: 0px 0px 9px 9px; padding:3px; font-family: 'Poppins', sans-serif; letter-spacing: 2px; font-size: 18px;">
                            <a href="#" style="text-decoration:none; color:white;  ">www.osfashion.com</a>
                        </div>

                </div>

            </div>
        </div>


        <div class="row text-center mt-5">
            <div class="col-sm-12">
                <button id="btn_print">Print</button>
            </div>
        </div>

        <!-- Footer Section Begin -->
        <div class="mt-5"></div>
        <?php include_once('includes/footer.php'); ?>

        <!-- Footer Section End -->

        <!-- Js Plugins -->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/popper.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/jquery.countdown.min.js"></script>
        <script src="js/jquery.nice-select.min.js"></script>
        <script src="js/jquery.zoom.min.js"></script>
        <script src="js/jquery.dd.min.js"></script>
        <script src="js/jquery.slicknav.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/main.js"></script>
        <script src="js/aes.js"></script>
        <script src="js/js/jsCollectionCart.js"></script>
        <script src="js/print.js"></script>
        <script src="js/js/jsIdCard.js"></script>

        <script>
             $( document ).ready(function() {
                $("#btn_print").click(function() {
                    // alert("Hi");
                    $("#front, #back").printThis({
                        debug: false,               // show the iframe for debugging
                        importCSS: true,            // import page CSS
                        importStyle: false,         // import style tags
                        printContainer: true,       // grab outer container as well as the contents of the selector
                        loadCSS: "fashion/css/print.css",  // path to additional css file - us an array [] for multiple
                        pageTitle: "",              // add title to print page
                        removeInline: false,        // remove all inline styles from print elements
                        printDelay: 333,            // variable print delay
                        header: null,               // prefix to html
                        footer: null,               // postfix to html
                        base: false,                // preserve the BASE tag, or accept a string for the URL
                        formValues: true,           // preserve input/form values
                        canvas: false,              // copy canvas elements (experimental)
                        doctypeString: '',          // enter a different doctype for older markup
                        removeScripts: false,       // remove script tags from print content
                        copyTagClasses: false       // copy classes from the html & body tag
                    });

                });

            });
        </script>


</body>

</html>
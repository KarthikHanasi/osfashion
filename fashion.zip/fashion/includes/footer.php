<footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="footer-left">
                        <div class="footer-logo">
                            <!-- <a href="#"><img src="img/footer-logo.png" alt=""></a> -->
                            <span class="footer-company-name">OS FASHION</span>
                        </div>
                        <ul>
                            <li><b>Address:</b> Bharati Sankul Building 
                            2nd Floor, Club Road, Belagavi, Karnataka Pin Code - 590001</li><br>
                            <li><b>Phone:<br>
                                Our Customer Care No<br></b>+91 9845301177 <br>
                            </li>
                            <li><b>Land - Line No :</b><br>
                            0831 4059426</li>
                            <li><b>Email:</b> info@osfashion.in</li>
                        </ul><br>
                        <div class="footer-social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 offset-lg-1">
                    <div class="footer-widget">
                        <h5>Information</h5>
                        <ul>
                            <li><a href="about.php">About Us</a></li>
                            <!-- <li><a href="check-out.php">Checkout</a></li> -->
                            <li><a href="contact.php">Contact</a></li>
                            <!-- <li><a href="faq.php">FAQs</a></li> -->
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="footer-widget">
                        <h5>My Account</h5>
                        <ul>
                            <li><a href="myprofile.php">My Account</a></li>
                            <li><a href="contact.php">Contact</a></li>
                            <li><a href="shopping-cart.php">Shopping Cart</a></li>
                            <li><a href="shop.php">Shop</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="footer-widget">
                        <h5>Information</h5>
                        <ul>
                            <li><a href="privacy-policy.php">Privacy & Policy</a></li>
                            <li><a href="return_policy.php">Return Policy</a></li>
                            <li><a href="company_compliance.php">Company Compliance</a></li>
                        </ul>
                    </div>
                </div>

                
                
            </div>
        </div>
        <div class="copyright-reserved">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright-text">
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved by <a href="http://infynow.com" target="_blank" style="letter-spacing:2px; font-weight: bold;"><i class="fa fa-info" style="color: blue;font-size:20px"></i>nfynow</a>
                        </div>
                        <div class="payment-pic">
                            <img src="img/payment-method.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
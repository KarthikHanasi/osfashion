    <!-- <div id="preloder">
        <div class="loader"><img src="img/logo1.png"></div>
    </div> -->
    <header class="header-section" id="header">
        <div class="header-top">
            <div class="container">
                <div class="ht-left">
                    <div class="mail-service">
                        <i class=" fa fa-envelope"></i>
                        info@osfashion.in
                    </div>
                    <div class="phone-service">
                        <i class=" fa fa-phone"></i>
                        +91 98453 01177
                    </div>
                </div>

                <div class="dropdown ht-right" id="notLogin">
                    <span type="button" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-user"></i> My Account
                    </span>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="login.php">Login</a>
                        <a class="dropdown-item" href="register.php">Register</a>
                    </div>
                </div>
                <div class="dropdown ht-right" id="yesLogin">
                    <span type="button" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-user"></i> <span id="userName">My Account</span>
                    </span>

                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="myprofile.php">My Profile</a>
                        <a class="dropdown-item" href="my_orders.php">My Orders</a>
                        <a class="dropdown-item" href="logout.php">Logout</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
        <marquee behavior="scroll" direction="left"><b>Under Testing</b></marquee>
            <div class="inner-header">
                <div class="row">
                    <div class="col-lg-2 col-md-2" id="logo-header">
                        <div class="logo">
                            <a href="index.php">
                                <img src="img/logo.png" class="img-logo" alt="">
                            </a>
                            <span class="logo-company-name">
                                <h4 class="company-name">Os Fashion<h4>
                            </span>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-7">
                        <div class="advanced-search">
                            <div class="input-group">
                                <input type="text" placeholder="What do you need?" id="inputSearch">
                                <button type="button" id="search"><i class="ti-search"></i></button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 text-right col-md-3">
                        <ul class="nav-right">
                            <!-- <li class="heart-icon">
                                <a href="#">
                                    <i class="icon_heart_alt"></i>
                                    <span>1</span>
                                </a>
                            </li> -->
                            <li class="cart-icon">
                                <a href="shopping-cart.php">
                                    <i class="icon_bag_alt"></i>
                                    <span id="cartCount">0</span>
                                </a>
                                
                            </li>
                            <li class="cart-price" id="totalCartPrice">₹0.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="nav-item">
            <div class="container">
                <nav class="nav-menu mobile-menu">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="shop.php">Shop</a></li>
                        <li><a href="#">Collection</a>
                            <ul class="dropdown" id="headerDropdownCollection">
                            </ul>
                        </li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="member.php">Member</a></li>
                        <li><a href="privacy-policy.php">Privacy & Policy</a></li>
                        <li><a href="digital_shop.php">Digital Shop</a></li>
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>

    <script>
        window.addEventListener('scroll', function(ev) {

            let someDiv = document.getElementById('header');
            let distanceToTop = someDiv.getBoundingClientRect().top;

            if(Math.abs(distanceToTop) >= 200) {
                $("#logo-header").addClass("logo-header");
            } else {
                $("#logo-header").removeClass("logo-header");
            }
        });
    </script>
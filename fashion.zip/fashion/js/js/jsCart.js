function loadCartDetails() {

    let formData = new FormData();
    formData.append("action", "get_cart_details");

        $.ajax({

            url: "backend/process_web.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);
                let subTotal = 0;
                let totalSubTotal = 0;
                let totalAmount = 0;
                for(let i = 0; i < lclJSON.cartDetails.length; i++) {

                  if(lclJSON.isLogin === 0) {
                    $("#cartDetails").append('<tr><td class="cart-pic first-row"><img src="'+lclJSON.cartDetails[i].pd_cart_image+'" class="cart-image" alt=""></td><td class="cart-title first-row"><h5>'+lclJSON.cartDetails[i].pd_cart_name+'</h5></td><td class="p-price first-row" id="singlePrice'+i+'">₹'+lclJSON.cartDetails[i].pd_cart_price+'</td><td class="qua-col first-row"><div class="quantity"><div class="pro-qty"><span class="dec qtybtn" onclick="minusOneSession('+i+')">-</span><input type="text" id="singleQTY'+i+'" value="'+lclJSON.cartDetails[i].pd_cart_quantity+'"><span class="inc qtybtn" onclick="plusOneSession('+i+')">+</span></div></div></td><td class="total-price first-row" id="totalPrice'+i+'">₹'+lclJSON.cartDetails[i].pd_cart_total_price+'</td><td class="close-td first-row"><i class="ti-close" onclick="deleteCart1('+i+')"></i></td></tr>');
                    subTotal = subTotal + parseFloat(lclJSON.cartDetails[i].pd_cart_total_price);
                    totalSubTotal = totalSubTotal + parseFloat(lclJSON.cartDetails[i].pd_cart_total_price);
                  } else {
                    totalAmount = parseFloat(lclJSON.cartDetails[i].pd_discount_price) * parseFloat(lclJSON.cartDetails[i].ct_qty);
                    let cartID = "'"+lclJSON.cartDetails[i].ct_id+"'";
                    $("#cartDetails").append('<tr><td class="cart-pic first-row"><img src="'+lclJSON.cartDetails[i].pd_image+'" class="cart-image" alt=""></td><td class="cart-title first-row"><h5>'+lclJSON.cartDetails[i].pd_name+'</h5></td><td class="p-price first-row" id="singlePrice'+lclJSON.cartDetails[i].ct_id+'">₹'+lclJSON.cartDetails[i].pd_discount_price+'</td><td class="qua-col first-row"><div class="quantity"><div class="pro-qty"><span class="dec qtybtn" onclick="minusOne('+cartID+')">-</span><input type="text" id="singleQTY'+lclJSON.cartDetails[i].ct_id+'" value="'+lclJSON.cartDetails[i].ct_qty+'"><span class="inc qtybtn" onclick="plusOne('+cartID+')">+</span></div></div></td><td class="total-price first-row" id="totalPrice'+lclJSON.cartDetails[i].ct_id+'">₹'+totalAmount+'</td><td class="close-td first-row"><i class="ti-close" onclick="deleteCart('+cartID+')"></i></td></tr>');
                    subTotal = subTotal + parseFloat(lclJSON.cartDetails[i].pd_discount_price) * parseFloat(lclJSON.cartDetails[i].ct_qty);
                    totalSubTotal = totalSubTotal + parseFloat(lclJSON.cartDetails[i].pd_discount_price) * parseFloat(lclJSON.cartDetails[i].ct_qty);
                  }
                  
                }

                let proQty = $('.pro-qty');
                // proQty.prepend('<span class="dec qtybtn">-</span>');
                // proQty.append('<span class="inc qtybtn">+</span>');

                proQty.on('click', '.qtybtn', function () {
                    var $button = $(this);
                    var oldValue = $button.parent().find('input').val();
                    if ($button.hasClass('inc')) {
                        var newVal = parseFloat(oldValue) + 1;
                    } else {
                        // Don't allow decrementing below zero
                        if (oldValue > 1) {
                            var newVal = parseFloat(oldValue) - 1;
                        } else {
                            newVal = 1;
                        }
                    }
                    $button.parent().find('input').val(newVal);
                });
                
                $("#subTotal").text("₹ "+subTotal.toFixed(2));
                $("#totalSubTotal").text("₹ "+totalSubTotal.toFixed(2));

              }
            
        });
    
  }

  loadCartDetails();

  function deleteCart1(index) {
    let formData = new FormData();

    formData.append("txtIndex", index);
    formData.append("action", "delete_cart1");

    $.ajax({
      beforeSend: function () {
      },
      url: "backend/process_web.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {
        location.reload();
      }
    });
  }

  function deleteCart(cartID) {
    let formData = new FormData();

    formData.append("cartID", cartID);
    formData.append("action", "delete_cart");

    $.ajax({
      beforeSend: function () {
      },
      url: "backend/process_web.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {
        location.reload();
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {

      },
    });
}

function plusOne(cartID) {
  
  let presentQTY = Number($("#singleQTY"+cartID).val()) + 1;
  let singlePrice = $("#singlePrice"+cartID).text().substring(1);
  
  let lclTotalPrice = Number(singlePrice) * Number(presentQTY);
  $("#totalPrice"+cartID).text("₹"+lclTotalPrice);
  updateCart(cartID, 1);

}

function minusOne(cartID) {

  let presentQTY = Number($("#singleQTY"+cartID).val()) - 1;
  if(presentQTY > 0) {
    let singlePrice = $("#singlePrice"+cartID).text().substring(1);
    let lclTotalPrice = Number(singlePrice) * Number(presentQTY);

    $("#totalPrice"+cartID).text("₹"+lclTotalPrice);
    updateCart(cartID, 0);
  }

}

function updateCart(cartID, checkInput) {
  let formData = new FormData();

  formData.append("cartID", cartID);
  formData.append("checkInput", checkInput);
  formData.append("action", "update_cart");

  $.ajax({
    beforeSend: function () {
    },
    url: "backend/process_web.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (res) {
      let newAmount = $("#subTotal").text().substring(1);
      amount = (Number(res) + Number(newAmount)).toFixed(2);
      $("#subTotal").text(`₹ ${amount}`);
      $("#totalSubTotal").text(`₹ ${amount}`);
    },
    error: function (res, error) {
      console.error(error);
    },
    complete: function () {

    },
  });
}

function plusOneSession(cartID) {
  let presentQTY = Number($("#singleQTY"+cartID).val()) + 1;
  let singlePrice = $("#singlePrice"+cartID).text().substring(1);
  
  let lclTotalPrice = Number(singlePrice) * Number(presentQTY);
  $("#totalPrice"+cartID).text("₹"+lclTotalPrice);

  updateSessionCart(cartID, 1);

}

function minusOneSession(cartID) {
  let presentQTY = Number($("#singleQTY"+cartID).val()) - 1;
  if(presentQTY > 0) {
    
    let singlePrice = $("#singlePrice"+cartID).text().substring(1);
    
    let lclTotalPrice = Number(singlePrice) * Number(presentQTY);
    $("#totalPrice"+cartID).text("₹"+lclTotalPrice);
    updateSessionCart(cartID, 0);
  }
}

function updateSessionCart(cartID, checkInput) {
  let formData = new FormData();

  formData.append("cartID", cartID);
  formData.append("checkInput", checkInput);
  formData.append("action", "update_session_cart");

  $.ajax({
    beforeSend: function () {
    },
    url: "backend/process_web.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (res) {
      $("#subTotal").text(`₹ ${res}`);
      $("#totalSubTotal").text(`₹ ${res}`);
    },
    error: function (request, error) {
      console.error(error);
    },
    complete: function () {

    },
  });
}

$("#checkout").click(function() {
  let rowCount = $('#cartTable tr').length;
  if(rowCount > 1) {

    let encrypted = localStorage.getItem("login");
    let decrypted = CryptoJS.AES.decrypt(encrypted, "osfashionKey");
    let decVal = decrypted.toString(CryptoJS.enc.Utf8);
    if(decVal === "NO") {
      localStorage.setItem("url", 'check-out.php');
      window.location = 'login.php';
      return false;
    } else {
      $("#checkout").html("<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> PROCEED TO CHECK OUT");
      window.location = 'check-out.php';
    }
  } else {
    alert("Please add Products to Cart");
    return false;
  }
});
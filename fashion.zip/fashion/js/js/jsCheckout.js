function isNumberKey(evt) {
  let charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

$(".check-coins").hide();
let totalCoins = 0;
let encryptedAppliedCoins = CryptoJS.AES.encrypt(String(0), "osfashionKey");
localStorage.setItem("totalAppliedCoins", encryptedAppliedCoins);
function loadCheckoutDetails() {

    let formData = new FormData();
    formData.append("product_id", $("#product_id").val());
    formData.append("quantity", $("#quantity").val());
    formData.append("action", "get_checkout_details");

        $.ajax({

            url: "backend/process_web.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);
                let subTotal = 0;
                let totalAmount = 0;
                let shippingCharges = 0;
                let totalBV = 0;
                let totalPV = 0;

                if(lclJSON.member == 1) {
                  if(lclJSON.coinUsage == 1) {
                    $(".check-coins").show();
                  }
                }
                
                for(let i = 0; i < lclJSON.singleProducts.length; i++) {
                    let totalSingleProductAmount = Number($("#quantity").val()) * Number(lclJSON.singleProducts[i].pd_discount_price);

                    totalBV += Number($("#quantity").val()) * Number(lclJSON.singleProducts[i].pd_bv);
                    totalPV += Number($("#quantity").val()) * Number(lclJSON.singleProducts[i].pd_pv);

                    subTotal += totalSingleProductAmount;
                    totalAmount += totalSingleProductAmount;
                    let productImg = lclJSON.singleProducts[i].pd_image;
                    $("#productDetails").append('<li class="fw-normal"><img src="'+productImg+'" class="check-out-product-img">'+lclJSON.singleProducts[i].pd_name+' x '+$("#quantity").val()+'(P-ID '+lclJSON.singleProducts[i].pd_product_id+') <span>₹'+totalSingleProductAmount+'</span></li>');
                }

                for(let i = 0; i < lclJSON.cartProducts.length; i++) {
                    let totalSingleProductAmount = Number(lclJSON.cartProducts[i].ct_qty) * Number(lclJSON.cartProducts[i].pd_discount_price);

                    totalBV += Number(lclJSON.cartProducts[i].ct_qty) * Number(lclJSON.cartProducts[i].pd_bv);
                    totalPV += Number(lclJSON.cartProducts[i].ct_qty) * Number(lclJSON.cartProducts[i].pd_pv);

                    subTotal += totalSingleProductAmount;
                    totalAmount += totalSingleProductAmount;
                    let productImg = lclJSON.cartProducts[i].pd_image;
                    $("#productDetails").append('<li class="fw-normal"><img src="'+productImg+'" class="check-out-product-img">'+lclJSON.cartProducts[i].pd_name+' x '+lclJSON.cartProducts[i].ct_qty+'(P-ID '+lclJSON.cartProducts[i].pd_product_id+') <span>₹'+totalSingleProductAmount+'</span></li>');
                }

                for(let i = 0; i < lclJSON.userAddress.length; i++) {
                  let checkedAttribute = i === 0 ? 'checked' : '';
                  $("#selAddress").append('<input type="radio" name="address" class="input-radio" value="' + lclJSON.userAddress[i].ads_id + '" ' + checkedAttribute + '><p class="card-text d-inline"><b>'+lclJSON.userAddress[i].ads_fullName+','+lclJSON.userAddress[i].ads_address+','+lclJSON.userAddress[i].ads_pincode+' '+lclJSON.userAddress[i].ads_city+','+lclJSON.userAddress[i].st_name+', '+lclJSON.userAddress[i].ads_mobile_number+'</b></p><br>');
                }

                for(let i = 0; i < lclJSON.userInfo.length; i++) {
                    $("#txtFullName").val(lclJSON.userInfo[i].us_name);
                    $("#txtEmailID").val(lclJSON.userInfo[i].us_email);
                    $("#txtMobileNo1").val(lclJSON.userInfo[i].us_mobile);
                    $("#txtMobileNo").val(lclJSON.userInfo[i].us_mobile);
                    totalCoins = lclJSON.userInfo[i].us_coins;
                }

                if(subTotal < lclJSON.shippingCharges[0].sc_below_amount) {
                  shippingCharges += Number(lclJSON.shippingCharges[0].sc_amount);
                  totalAmount += Number(lclJSON.shippingCharges[0].sc_amount);
                }
                
                $("#subTotal").text("₹ "+subTotal.toFixed(2));
                $("#totalBV").text(totalBV.toFixed(0));
                $("#shippingCharges").text("₹ "+shippingCharges.toFixed(2));
                $("#totalAmount").text("₹ "+totalAmount.toFixed(2));

                let encryptedSubTotal = CryptoJS.AES.encrypt(String(subTotal), "osfashionKey");
                let encryptedTotalBV = CryptoJS.AES.encrypt(String(totalBV), "osfashionKey");
                let encryptedTotalPV = CryptoJS.AES.encrypt(String(totalPV), "osfashionKey");
                let encryptedShippingCharges = CryptoJS.AES.encrypt(String(shippingCharges), "osfashionKey");
                let encryptedTotalAmount = CryptoJS.AES.encrypt(String(totalAmount), "osfashionKey");

                localStorage.setItem("subTotal", encryptedSubTotal);
                localStorage.setItem("totalBV", encryptedTotalBV);
                localStorage.setItem("totalPV", encryptedTotalPV);
                localStorage.setItem("shippingCharges", encryptedShippingCharges);
                localStorage.setItem("totalAmount", encryptedTotalAmount);

              }
            
        });
    
  }

  loadCheckoutDetails();
  
  const checkout = () => {

    let formData = new FormData();

    formData.append("product_id", $("#product_id").val());
    formData.append("quantity", $("#quantity").val());

    let address = $("input[name='address']:checked").val();

    let encryptedSubTotal = localStorage.getItem("subTotal");
    let encryptedShippingCharges = localStorage.getItem("shippingCharges");
    let encryptedTotalAmount = localStorage.getItem("totalAmount");

    let decryptedSubTotal = CryptoJS.AES.decrypt(encryptedSubTotal, "osfashionKey");
    let decryptedShippingCharges = CryptoJS.AES.decrypt(encryptedShippingCharges, "osfashionKey");
    let decryptedTotalAmount = CryptoJS.AES.decrypt(encryptedTotalAmount, "osfashionKey");

    formData.append("subTotal", decryptedSubTotal.toString(CryptoJS.enc.Utf8));
    formData.append("shippingCharges", decryptedShippingCharges.toString(CryptoJS.enc.Utf8));
    formData.append("totalAmount", decryptedTotalAmount.toString(CryptoJS.enc.Utf8));

    let encryptedTotalAppliedCoins = localStorage.getItem("totalAppliedCoins");
    let decryptedTotalAppliedCoins = CryptoJS.AES.decrypt(encryptedTotalAppliedCoins, "osfashionKey").toString(CryptoJS.enc.Utf8);

    formData.append("txtAddress", address);
    formData.append("totalAppliedCoins", decryptedTotalAppliedCoins);
    formData.append("action", "get_product_delivery_information");

    $.ajax({
      beforeSend: function () {
        $("#checkout").attr("disabled", true);
        
      },
      url: "backend/process_web_place_order.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {

        let lclJSON = JSON.parse(res);
        console.log(lclJSON.orderDetails.length);

        if(lclJSON.orderDetails.length == 0) {
          alert("Something went wrong, please check your address before placing order");
          location.reload();
        } else {
          let orderDetails = JSON.stringify(lclJSON.orderDetails);
          finalOrder(orderDetails, lclJSON.orderID);
        }
     
    }
  });
    
}

function finalOrder(orderDetails, orderID) {

    let formData = new FormData();

    formData.append("product_id", $("#product_id").val());
    formData.append("quantity", $("#quantity").val());
    formData.append("color", $("#color").val());
    formData.append("size", $("#size").val());
    
    formData.append("txtFullName", $("#txtFullName").val());
    formData.append("txtMobileNo", $("#txtMobileNo").val());
    formData.append("txtEmailID", $("#txtEmailID").val());
    formData.append("txtAddress", $("input[name='address']:checked").val());
    formData.append("radioPaymentType", $("input[name='payment']:checked").val());

    // qr payment details start
    formData.append("qrPaymentAccountName", $("#qrPaymentAccountName").val());
    formData.append("qrPaymentAccountNumber", $("#qrPaymentAccountNumber").val());
    // qr payment details end

    let address = $("input[name='address']:checked").val();

    let encryptedSubTotal = localStorage.getItem("subTotal");
    let encryptedTotalBV = localStorage.getItem("totalBV");
    let encryptedTotalPV = localStorage.getItem("totalPV");
    let encryptedShippingCharges = localStorage.getItem("shippingCharges");
    let encryptedTotalAmount = localStorage.getItem("totalAmount");
    let encryptedTotalAppliedCoins = localStorage.getItem("totalAppliedCoins");

    let decryptedSubTotal = CryptoJS.AES.decrypt(encryptedSubTotal, "osfashionKey");
    let decryptedTotalBV = CryptoJS.AES.decrypt(encryptedTotalBV, "osfashionKey");
    let decryptedTotalPV = CryptoJS.AES.decrypt(encryptedTotalPV, "osfashionKey");
    let decryptedShippingCharges = CryptoJS.AES.decrypt(encryptedShippingCharges, "osfashionKey");
    let decryptedTotalAmount = CryptoJS.AES.decrypt(encryptedTotalAmount, "osfashionKey");
    let decryptedAppliedCoins = CryptoJS.AES.decrypt(encryptedTotalAppliedCoins, "osfashionKey");

    formData.append("subTotal", decryptedSubTotal.toString(CryptoJS.enc.Utf8));
    formData.append("totalBV", decryptedTotalBV.toString(CryptoJS.enc.Utf8));
    formData.append("totalPV", decryptedTotalPV.toString(CryptoJS.enc.Utf8));
    formData.append("shippingCharges", decryptedShippingCharges.toString(CryptoJS.enc.Utf8));
    formData.append("totalAmount", decryptedTotalAmount.toString(CryptoJS.enc.Utf8));
    formData.append("totalAppliedCoins", decryptedAppliedCoins.toString(CryptoJS.enc.Utf8));

    formData.append("txtAddress", address);
    formData.append("orderDetails", orderDetails);
    formData.append("orderID", orderID);
    formData.append("action", "place_order");
    $.ajax({
      beforeSend: function () {
        $("#checkout").attr("disabled", true);
      },
      url: "backend/process_web_place_order.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {
          // if($("input[name='payment']:checked").val() == "Cash On Delivery") {
            alert("Orders Placed Successfully, Thank You Visit Again!!!");
            window.location = 'index.php';
            return false;
          // }
      },
      error: function (error) {
        console.error(error);
      },
      complete: function () {
        $("#checkout").attr("disabled", false);
      },
    });
}

  $("#checkout").click(function (e) {

    let address = $("input[name='address']:checked").val();

    if(!address) {
      alert("Please Select Address OR add new address");
      return false;
    }

    let payment = $("input[name='payment']:checked").val();

    if(!payment) {
      alert("Please Select Payment Type");
      return false;
    }

    $("#checkout").attr("disabled", true);
    $("#checkout").html("<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> Placing Order Please Wait...");
    $("#checkout").prop("disabled", true);

    if($("input[name='payment']:checked").val() == "Cash On Delivery") {
      checkout();
      return false;
    } else {
      openQrCodeModal();
    }
});

function openQrCodeModal() {
  $('#onlinePaymentQrCode').modal('show');
}

$("#proceedQRCheckout").click(function() {
  if($("#qrPaymentAccountName").val() == "") {
    alert("Please enter account name from which you are paying now");
    $("#qrPaymentAccountName").focus()
    return false;
  }

  if($("#qrPaymentAccountNumber").val() == "") {
    alert("Please enter account number from which you are paying now");
    $("#qrPaymentAccountNumber").focus()
    return false;
  }
  $("#proceedQRCheckout").prop("disabled", true);
  $("#proceedQRCheckout").html("<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> Placing Order Please Wait...");
  checkout();
});

$("#addNewAddress").click(function (e) {
   
  //verification
  if ($("#txtFullName").val().trim().length < 1) {
    alert("Please Enter Full Name");
    $("#txtFullName").focus();
    return false;
}

  if ($("#txtMobileNo1").val().trim().length < 1) {
      alert("Please Enter Mobile Number");
      $("#txtMobileNo1").focus();
      return false;
  }

  if ($("#txtMobileNo1").val().trim().length < 10) {
      alert("Please Enter 10 Digits Mobile Number");
      $("#txtMobileNo1").focus();
      return false;
  }

  if ($("#txtAddress").val().trim().length < 1) {
      alert("Please Enter Address");
      $("#txtAddress").focus();
      return false;
  }


  if ($("#txtCity").val().trim().length < 1) {
      alert("Please Enter City");
      $("#txtCity").focus();
      return false;
  }

  if ($("#txtState").val().trim().length < 1) {
      alert("Please Select State");
      $("#txtState").focus();
      return false;
  }

  if ($("#txtPincode").val().trim().length < 1) {
      alert("Please Enter Pincode");
      $("#txtPincode").focus();
      return false;
  }

  if ($("#txtPincode").val().trim().length < 6 || $("#txtPincode").val().trim().length > 6 ) {
    alert("Please Enter Valid Pincode");
    $("#txtPincode").focus();
    return false;
}
  
    
  let formData = new FormData();
  formData.append("txtId", $("#txtId").val());
  formData.append("txtFullName", $("#txtFullName").val());
  formData.append("txtMobileNo1", $("#txtMobileNo1").val());
  formData.append("txtAddress", $("#txtAddress").val());
  formData.append("txtAddress2", $("#txtAddress2").val());
  formData.append("txtCity", $("#txtCity").val());
  formData.append("txtState", $("#txtState").val());
  formData.append("txtPincode", $("#txtPincode").val());
  formData.append("action", "add_new_address");

  $.ajax({
    beforeSend: function () {
      $("#addNewAddress").attr("disabled", true);
    },
    url: "backend/process_web.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      alert("Address saved successfully");
      $("#selAddress").empty();
      let lclJSON = JSON.parse(response);
      userAddressDetails =  lclJSON.userAddress;
        for(let i = 0; i < lclJSON.userAddress.length; i++) {
          let checkedAttribute = i === 0 ? 'checked' : '';
          $("#selAddress").prepend('<input type="radio" name="address" class="input-radio" value="' + lclJSON.userAddress[i].ads_id + '" ' + checkedAttribute + '><p class="card-text d-inline"><b>'+lclJSON.userAddress[i].ads_fullName+','+lclJSON.userAddress[i].ads_address+','+lclJSON.userAddress[i].ads_pincode+' '+lclJSON.userAddress[i].ads_city+','+lclJSON.userAddress[i].st_name+', '+lclJSON.userAddress[i].ads_mobile_number+'</b></p><br>');
        }
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $("#addNewAddress").attr("disabled", false);
      $("#txtFullName").val('')
      $("#txtMobileNo1").val('')
      $("#txtAddress").val('')
      $("#txtCity").val('')
      $("#txtState").val('')
      $("#txtPincode").val('')
      $("#txtId").val('')
      $("#address-tab").hide()

    },
  });
});

$("#applyCoins").click(function() {
    $("#applyCoins").val("Applied");
    $("#applyCoins").attr("disabled", true);
    totalAppliedCoins = (totalCoins/4).toFixed(2);
    $("#totalCoins").text(parseFloat(totalCoins/4));

    let encryptedAppliedCoins = CryptoJS.AES.encrypt(String(totalAppliedCoins), "osfashionKey");
    localStorage.setItem("totalAppliedCoins", encryptedAppliedCoins);

    let encryptedTotalAmount = localStorage.getItem("totalAmount");
    let decryptedTotalAmount = CryptoJS.AES.decrypt(encryptedTotalAmount, "osfashionKey").toString(CryptoJS.enc.Utf8);

    let newTotalAfterCoins = (decryptedTotalAmount) - totalAppliedCoins;

    let encryptedSetTotalAmount = CryptoJS.AES.encrypt(String(newTotalAfterCoins), "osfashionKey");
    localStorage.setItem("totalAmount", encryptedSetTotalAmount);

    $("#totalAmount").text("₹ "+newTotalAfterCoins.toFixed(2));
});

$("#addres-btn").click(function() {
  $("#address-tab").toggle()
});
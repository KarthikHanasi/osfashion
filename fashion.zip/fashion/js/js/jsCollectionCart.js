$("#notLogin").hide();
$("#yesLogin").hide();
function loadCollectionDetails() {

    let formData = new FormData();
    formData.append("action", "get_collection_cart_details");

        $.ajax({

            url: "backend/process_web.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);
                if(lclJSON.isLogin != 0) {
                    
                    let totalCart = 0.00;
                    let cartCount = 0;
                    
                    for(let i = 0; i < lclJSON.cartDetails.length; i++) {
                        totalCart += Number(lclJSON.cartDetails[i].ct_qty) * Number(lclJSON.cartDetails[i].pd_discount_price);
                        cartCount += 1;
                    }

                    $("#cartCount").text(cartCount);
                    $("#totalCartPrice").text(`₹ ${totalCart.toFixed(2)}`);

                    for(let i = 0; i < lclJSON.category.length; i++) {
                        $("#headerDropdownCollection").append('<li><a href="shop.php?q='+lclJSON.category[i].ca_id+'">'+lclJSON.category[i].ca_name+'</a></li>');
                    }

                    $("#userName").text(lclJSON.users[0].us_name);
                    $("#notLogin").hide();
                    $("#yesLogin").show();
                    let encrypted = CryptoJS.AES.encrypt("YES", "osfashionKey");
                    localStorage.setItem("login", encrypted);

                } else {

                    for(let i = 0; i < lclJSON.category.length; i++) {
                        $("#headerDropdownCollection").append('<li><a href="shop.php?q='+lclJSON.category[i].ca_id+'">'+lclJSON.category[i].ca_name+'</a></li>');
                    }

                    $("#notLogin").show();
                    $("#yesLogin").hide();
                    let encrypted = CryptoJS.AES.encrypt("NO", "osfashionKey");
                    localStorage.setItem("login", encrypted);
                }
            }
            
        });
    
  }

  loadCollectionDetails();

  $("#search").click(function() {

    if($("#inputSearch").val() === "") {
        alert("Please Enter in search box");
        $("#inputSearch").focus();
        return false;
    }

    window.location = 'shop.php?search='+$("#inputSearch").val();
  });
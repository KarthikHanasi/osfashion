
function loadCompanyDetails() {

    let formData = new FormData();
    formData.append("action", "get_company_compliance");

        $.ajax({

            url: "backend/process_web3.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                let lclJSON = JSON.parse(response);
                console.log(lclJSON)
                for(let i = 0; i < lclJSON.details.length; i++) {
                    $("#details").append('<div class="col-md-4"><a href='+lclJSON.details[i].cc_image+' target="_blank"><img src='+lclJSON.details[i].cc_image+'></img></a></div>');
                }
            }
        });
  }

  loadCompanyDetails();

  function loadNetworkDetails() {

    let formData = new FormData();
    formData.append("action", "get_networking_business_plans");

        $.ajax({

            url: "backend/process_web3.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);
                    
                for(let i = 0; i < lclJSON.details.length; i++) {

                    if(lclJSON.details[i].nbp_file_type == "Image") {
                        $("#imageDetails").append('<div class="col-md-4 mb-3"><img src='+lclJSON.details[i].nbp_file+' height="250" width="200"><br><a href='+lclJSON.details[i].nbp_file+' class="btn btn-success mt-3" download>Download</a></div>');
                    } else if(lclJSON.details[i].nbp_file_type == "PDF") {
                        $("#pdfDetails").append('<div class="col-md-4"><i class="fa fa-file-pdf-o" style="font-size:48px;color:red"></i><br><a href='+lclJSON.details[i].nbp_file+' style="color: red;" download>Download</a></div>');
                    } else {
                        $("#videoDetails").append('<div class="col-sm-4"><video width="160" height="240" controls><source src='+lclJSON.details[i].nbp_file+' type="video/mp4"><source src="movie.ogg" type="video/ogg"></video></div>');
                    }
                    
                }
            }
            
        });
    
  }

  loadNetworkDetails();

    $("#imageDetails").show();
    $("#pdfDetails").hide();
    $("#videoDetails").hide();

    $("#Images").click(function() {
        $("#imageDetails").show();
        $("#pdfDetails").hide();
        $("#videoDetails").hide();
    });

    $("#PDF").click(function() {
        $("#imageDetails").hide();
        $("#pdfDetails").show();
        $("#videoDetails").hide();
    });

    $("#Videos").click(function() {
        $("#imageDetails").hide();
        $("#pdfDetails").hide();
        $("#videoDetails").show();
    });
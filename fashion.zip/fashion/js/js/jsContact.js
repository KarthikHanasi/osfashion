function isNumberKey(evt) {
    let charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  
  $(document).on('keypress',function(e) {
    if(e.which == 13) {
      $("#register").click();
    }
  });
  
    $("#submit-contact").click(function (e) {
      //verification
      if ($("#txtName").val().trim().length < 1) {
          alert("Please Enter Full Name");
          $("#txtName").focus();
          return false;
      }
  
      if ($("#txtMobileNo").val().trim() === "") {
          alert("Please Enter Mobile Number");
          $("#txtMobileNo").focus();
          return false;
      }
  
      if ($("#txtMobileNo").val().trim().length !== 10) {
          alert("Please Enter Correct Mobile Number");
          $("#txtMobileNo").focus();
          return false;
      }
  
      // if ($("#txtMessage").val().trim().length < 5) {
      //     alert("Please Enter Correct Message");
      //     $("#txtMessage").focus();
      //     return false;
      // }
      
      let formData = new FormData();
      formData.append("txtName", $("#txtName").val());
      formData.append("txtMobileNo", $("#txtMobileNo").val());
      formData.append("txtEmail", $("#txtEmail").val());
      formData.append("txtMessage", $("#txtMessage").val());
  
      formData.append("action", "contact");
  
      $.ajax({
        beforeSend: function () {
          $("#submit-contact").attr("disabled", true);
          $("#submit-contact").html("<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> SUBMITTING...");
        },
        url: "backend/process_web3.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
            alert("Contact Details Submitted Successfully");
            location.reload();
        },
        error: function (res, error) {
          console.error(error);
        },
        complete: function () {
          $("#submit-contact").attr("disabled", false);
          $("#submit-contact").html("Send message");
        },
      });
    });
  
  
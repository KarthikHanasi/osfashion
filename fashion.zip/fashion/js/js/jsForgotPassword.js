function isNumberKey(evt) {
    let charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

$(document).on('keypress',function(e) {
    if(e.which == 13) {
      $("#forgotPassword").click();
    }
});
  
    $("#forgotPassword").click(function (e) {
      //verification
      if ($("#txtMobileNo").val() == "") {
          alert("Please Enter Mobile Number");
          $("#txtMobileNo").focus();
          return false;
      }
  
      if ($("#txtMobileNo").val().length !== 10) {
          alert("Please Enter Correct Mobile Number");
          $("#txtMobileNo").focus();
          return false;
      }
      
      let formData = new FormData();
      formData.append("txtMobileNo", $("#txtMobileNo").val());
      formData.append("action", "forgot_password");

      const otp = Math.floor(100000 + Math.random() * 900000);
      // executeSMS(otp, $("#txtMobileNo").val());
      formData.append("otp", otp);
  
      $.ajax({
        beforeSend: function () {
          $("#login").attr("disabled", true);
        },
        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
          if(res == "10") {
            alert("Please Enter Valid Mobile Number");
            return false;
          } else {
            window.location = "forgot_password_otp.php";
          }
            
        },
        error: function (res, error) {
          console.error(error);
        },
        complete: function () {
          $("#login").attr("disabled", false);
        },
      });
    });

    function executeSMS(otp, mobile) {

      let formData = new FormData();
      $.ajax({
        url: "http://sms.pearlsms.com/public/sms/send?sender=OSFSNN&smstype=TRANS&numbers="+mobile+"&apikey=5aa722b394c14f799fb01cc6caa69375&message=Dear client , Your One Time Password is "+otp+" - One Step Fashion Network OSFSNN",
        type: "GET",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
        }
      });
    }
    

function getHomeDetails() {
    
    let formData = new FormData();
    formData.append("action", "get_home_category_details");

    $.ajax({

        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {

            let lclJSON = JSON.parse(response);

            for(let i = 0; i < lclJSON.category.length; i++) {
                $("#categoryTop").append('<div class="product-item"><div class="pi-pic"><a href="shop.php?q='+lclJSON.category[i].ca_id+'"><img class="lazy category-img" src="'+lclJSON.category[i].ca_image+'?q='+lclJSON.category[i].ca_id+'" loading="lazy" alt=""><div class="category-name"><span>'+lclJSON.category[i].ca_name+'</span></div></a></div></div>');
            }

            getHomeWomensDetails();

            $(".category-slider").owlCarousel({
                loop: true,
                margin: 25,
                // nav: true,
                items: 4,
                dots: true,
                // navText: ['<i class="ti-angle-left"></i>', '<i class="ti-angle-right"></i>'],
                smartSpeed: 1200,
                autoHeight: false,
                autoplay: true,
                responsive: {
                    0: {
                        items: 5,
                    },
                    576: {
                        items: 5,
                    },
                    992: {
                        items: 8,
                    },
                    1200: {
                        items: 8,
                    }
                }
            });
        }
    });
}

getHomeDetails();

function getHomeWomensDetails() {
    let formData = new FormData();
    formData.append("action", "get_home_women_details");

    $.ajax({

        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {

            let lclJSON = JSON.parse(response);
            let checkOutOfStock = "";

            for(let i = 0; i < lclJSON.womens.length; i++) {
                // if(Number(lclJSON.womens[i].pd_stock) <= 0) {
                //     checkOutOfStock = '<div class="sale pp-out-of-stock">Out Of Stock</div>';
                // } else {
                    checkOutOfStock = '<div class="sale pp-sale">'+lclJSON.womens[i].pd_discount+'% discount</div>';
                // }

                $("#productsWomen").append('<div class="product-item"><div class="pi-pic"><a href="product.php?id='+lclJSON.womens[i].pd_id+'"><img class="lazy" src="'+lclJSON.womens[i].pd_image+'?q='+lclJSON.womens[i].pd_id+'" loading="lazy" alt=""></a><ul class="quick-view-animation"><li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li><li class="quick-view"><a href="product.php?id='+lclJSON.womens[i].pd_id+'">+ Quick View</a></li><li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li></ul></div><div class="pi-text"><div class="catagory-name">'+lclJSON.womens[i].ca_name+'</div><a href="product.php?id='+lclJSON.womens[i].pd_id+'"><h5>'+lclJSON.womens[i].pd_name+'</h5></a>'+checkOutOfStock+'<div class="product-price">₹'+lclJSON.womens[i].pd_discount_price+'&nbsp;<span>₹'+lclJSON.womens[i].pd_price+'</span></div></div></div>');
            }

            $(".product-slider").owlCarousel({
                loop: true,
                margin: 25,
                nav: true,
                items: 4,
                dots: true,
                // navText: ['<i class="ti-angle-left"></i>', '<i class="ti-angle-right"></i>'],
                smartSpeed: 1200,
                autoHeight: false,
                autoplay: true,
                responsive: {
                    0: {
                        items: 2,
                    },
                    576: {
                        items: 2,
                    },
                    992: {
                        items: 2,
                    },
                    1200: {
                        items: 3,
                    }
                }
            });

            getHomeMensDetails();
        }
    });
}

function getHomeMensDetails() {
    let formData = new FormData();
    formData.append("action", "get_home_men_details");

    $.ajax({

        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {

            let lclJSON = JSON.parse(response);
            let checkOutOfStock = "";
            
            for(let i = 0; i < lclJSON.mens.length; i++) {

                // if(Number(lclJSON.mens[i].pd_stock) <= 0) {
                //     checkOutOfStock = '<div class="sale pp-out-of-stock">Out Of Stock</div>';
                // } else {
                    checkOutOfStock = '<div class="sale pp-sale">'+lclJSON.mens[i].pd_discount+'% discount</div>';
                // }

                $("#productsMen").append('<div class="product-item"><div class="pi-pic"><a href="product.php?id='+lclJSON.mens[i].pd_id+'"><img class="lazy" src="'+lclJSON.mens[i].pd_image+'?q='+lclJSON.mens[i].pd_id+'" loading="lazy" alt=""></a><ul class="quick-view-animation"><li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li><li class="quick-view"><a href="product.php?id='+lclJSON.mens[i].pd_id+'">+ Quick View</a></li><li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li></ul></div><div class="pi-text"><div class="catagory-name">'+lclJSON.mens[i].ca_name+'</div><a href="product.php?id='+lclJSON.mens[i].pd_id+'"><h5>'+lclJSON.mens[i].pd_name+'</h5></a>'+checkOutOfStock+'<div class="product-price">₹'+lclJSON.mens[i].pd_discount_price+'&nbsp;<span>₹'+lclJSON.mens[i].pd_price+'</span></div></div></div>');
            }

            $(".product-slider1").owlCarousel({
                loop: true,
                margin: 25,
                nav: true,
                items: 4,
                dots: true,
                // navText: ['<i class="ti-angle-left"></i>', '<i class="ti-angle-right"></i>'],
                smartSpeed: 1200,
                autoHeight: false,
                autoplay: true,
                responsive: {
                    0: {
                        items: 2,
                    },
                    576: {
                        items: 2,
                    },
                    992: {
                        items: 2,
                    },
                    1200: {
                        items: 3,
                    }
                }
            });

            getHomeAllDetails();
        }
    });
}

function getHomeAllDetails() {
    let formData = new FormData();
    formData.append("action", "get_home_all_details");

    $.ajax({

        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {

            let lclJSON = JSON.parse(response);
            let checkOutOfStock = "";

            for(let i = 0; i < lclJSON.allProducts.length; i++) {

                // if(Number(lclJSON.allProducts[i].pd_stock) <= 0) {
                //     checkOutOfStock = '<div class="sale pp-out-of-stock">Out Of Stock</div>';
                // } else {
                    checkOutOfStock = '<div class="sale pp-sale">'+lclJSON.allProducts[i].pd_discount+'% discount</div>';
                // }

                $("#allProducts").append('<div class="col-6 col-xs-3 col-sm-3 col-md-3"><div class="product-item"><div class="pi-pic"><a href="product.php?id='+lclJSON.allProducts[i].pd_id+'"><img class="lazy" src="'+lclJSON.allProducts[i].pd_image+'?q='+lclJSON.allProducts[i].pd_id+'" loading="lazy" alt=""></a><ul class="quick-view-animation"><li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li><li class="quick-view"><a href="product.php?id='+lclJSON.allProducts[i].pd_id+'">+ Quick View</a></li><li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li></ul></div><div class="pi-text"><div class="catagory-name">'+lclJSON.allProducts[i].ca_name+'</div><a href="product.php?id='+lclJSON.allProducts[i].pd_id+'"><h5>'+lclJSON.allProducts[i].pd_name+'</h5></a>'+checkOutOfStock+'<div class="product-price">₹'+lclJSON.allProducts[i].pd_discount_price+'&nbsp;<span>₹'+lclJSON.allProducts[i].pd_price+'</span></div></div></div></div>');

                if(i === 3) {
                    $("#allProducts").append('<div class="col-12 mb-4"><img src="img/slider/6.png"></div>');
                }
            }
        }
    });
}
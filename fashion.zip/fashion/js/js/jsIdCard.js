function loadIdCardDetails() {
  let formData = new FormData();
  formData.append("action", "get_id_card");

  $.ajax({
    url: "backend/process_web3.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      let lclJSON = JSON.parse(response);
      if (response == 10) {
        window.location = "login.php";
      } else {
        const dateObj = new Date(lclJSON.userInfo[0]?.us_created_date);

        // Define the formatting options
        const options = {
          day: "numeric",
          month: "long",
          year: "numeric",
        };
        const formattedDate = new Intl.DateTimeFormat("en-IN", options).format(
          dateObj
        );joining_date
        $("#txtName").text(lclJSON.userInfo[0]?.us_name || "---");
        $("#designation").text(lclJSON.userInfo[0]?.us_designation || "---");
        // $("#dob").text(lclJSON.userInfo[0]?.us_dob || "---");
        $("#email").text(lclJSON.userInfo[0]?.us_email || "---");
        $("#phone").text(lclJSON.userInfo[0]?.us_mobile || "---");
        $("#bloodGroup").text(lclJSON.userInfo[0]?.us_blood_group || "---");
        $("#joining_date").text(formattedDate || "---");
        $("#profile-card").attr("src",lclJSON.userInfo[0]?.us_image || "img/myprofile.png")
      }
    },
  });
}
loadIdCardDetails();

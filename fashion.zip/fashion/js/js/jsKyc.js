function isNumberKey(evt) {
  let charCode = evt.which ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

$("#saveAadhar").click(function () {
  if ($("#txtAadharNumber").val().trim().length < 1) {
    alert("Enter Aadhar Number");
    $("#txtAadharNumber").focus();
    return false;
  }

  if ($("#uploadAadharFile").val().trim().length < 1) {
    alert("Upload Aadhar");
    $("#uploadAadharFile").focus();
    return false;
  }

  $("#saveAadhar").attr("disabled", true);
  $("#saveAadhar").html(
    "<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> Uploading..."
  );
  let formData = new FormData();
  let lclImage = document.getElementById("uploadAadharFile");
  lclImage1 = lclImage.files[0];
  formData.append("uploadAadharFile", lclImage1);
  formData.append("txtAadharNumber", $("#txtAadharNumber").val());
  formData.append("action", "add_aadhar");

  $.ajax({
    url: "backend/process_web2.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      if (response == "10") {
        alert("Something went wrong");
      } else {
        alert("Aadhar Details Saved Successfully");
        location.reload();
      }
    },
  });
});

$("#savePan").click(function () {
  if ($("#txtPanNumber").val().trim().length < 1) {
    alert("Enter Pan Number");
    $("#txtPanNumber").focus();
    return false;
  }

  if ($("#uploadPanFile").val().trim().length < 1) {
    alert("Upload Pan");
    $("#uploadPanFile").focus();
    return false;
  }

  $("#savePan").attr("disabled", true);
  $("#savePan").html(
    "<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> Uploading..."
  );

  let formData = new FormData();
  let lclImage = document.getElementById("uploadPanFile");
  lclImage1 = lclImage.files[0];
  formData.append("uploadPanFile", lclImage1);
  formData.append("txtPanNumber", $("#txtPanNumber").val());
  formData.append("action", "add_pan");

  $.ajax({
    url: "backend/process_web2.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      if (response == "10") {
        alert("Something went wrong");
      } else {
        alert("Pan Details Saved Successfully");
        location.reload();
      }
    },
  });
});

$("#saveBankDetails").click(function () {
  if ($("#txtBankUserName").val().trim().length < 1) {
    alert("Enter Bank Name");
    $("#txtBankUserName").focus();
    return false;
  }

  if ($("#txtBankNumber").val().trim().length < 1) {
    alert("Enter Bank Account Number");
    $("#txtBankNumber").focus();
    return false;
  }

  if ($("#txtBankIfsc").val().trim().length < 1) {
    alert("Enter Ifsc Code");
    $("#txtBankIfsc").focus();
    return false;
  }

  // if ($("#uploadBankFile").val().trim().length < 1) {
  //   alert("Upload Bank Details");
  //   $("#uploadBankFile").focus();
  //   return false;
  // }

  $("#saveBankDetails").attr("disabled", true);
  $("#saveBankDetails").html(
    "<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> Uploading..."
  );

  let formData = new FormData();
  let lclImage = document.getElementById("uploadBankFile");
  lclImage1 = lclImage.files[0];
  formData.append("uploadBankFile", lclImage1);
  formData.append("txtBankNumber", $("#txtBankNumber").val());
  formData.append("txtBankUserName", $("#txtBankUserName").val());
  formData.append("txtBankName", $("#txtBankName").val());
  formData.append("txtBankIfsc", $("#txtBankIfsc").val());
  formData.append("action", "add_bank");

  $.ajax({
    url: "backend/process_web2.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      if (response == "10") {
        alert("Something went wrong");
      } else {
        alert("Bank Details Saved Successfully");
        location.reload();
      }
    },
  });
});

function loadKycDetails() {
  let formData = new FormData();
  formData.append("action", "get_kyc_details");

  $.ajax({
    url: "backend/process_web2.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      let lclJSON = JSON.parse(response);
      let [kycDetails] = lclJSON?.kyc_details;
      const defaultImage = "img/No-Image.png";
      if (kycDetails?.aadhar_status === "Accepted") {
        $("#uploadAadharFile").prop("disabled", true);
        $("#saveAadhar").prop("disabled", true);
        $("#txtAadharNumber").prop("disabled", true);
        $("#aadharStatus").css("background-color", "green");
      } else if (kycDetails?.aadhar_status === "Rejected") {
        $("#aadharStatus").css("background-color", "red");
      }
      if (kycDetails?.pan_status === "Accepted") {
        $("#uploadPanFile").prop("disabled", true);
        $("#savePan").prop("disabled", true);
        $("#txtPanNumber").prop("disabled", true);
        $("#panStatus").css("background-color", "green");
      } else if (kycDetails?.pan_status === "Rejected") {
        $("#panStatus").css("background-color", "red");
      }
      if (kycDetails?.bank_status === "Accepted") {
        $("#uploadBankFile").prop("disabled", true);
        $("#saveBankDetails").prop("disabled", true);
        $("#txtBankNumber").prop("disabled", true);
        $("#bankStatus").css("background-color", "green");
      } else if (kycDetails?.bank_status === "Rejected") {
        $("#bankStatus").css("background-color", "red");
      }

      $("#txtAadharNumber").val(kycDetails?.aadhar_number);
      $("#aadharLink").attr("href", kycDetails?.aadhar_file);
      $("#txtPanNumber").val(kycDetails?.pan_number);
      $("#panLink").attr("href", kycDetails?.pan_file);
      $("#txtBankNumber").val(kycDetails?.bank_number);
      $("#txtBankName").val(kycDetails?.bank_name);
      $("#txtBankIfsc").val(kycDetails?.bank_ifsc_code);
      $("#txtBankUserName").val(kycDetails?.bank_user_name);
      $("#bankLink").val(kycDetails?.bank_file);
      $("#aadharStatus").text(kycDetails?.aadhar_status);
      $("#panStatus").text(kycDetails?.pan_status);
      $("#bankStatus").text(kycDetails?.bank_status);

      if (kycDetails?.aadhar_file !== null) {
        $("#aadharImg").attr("src", kycDetails?.aadhar_file);
      } else {
        $("#aadharImg").attr("src", defaultImage);
      }

      if (kycDetails?.pan_file !== null) {
        $("#panImg").attr("src", kycDetails?.pan_file);
      } else {
        $("#panImg").attr("src", defaultImage);
      }

      if (kycDetails?.bank_file !== null) {
        $("#bankImg").attr("src", kycDetails?.bank_file);
      } else {
        $("#bankImg").attr("src", defaultImage);
      }
    },
  });
}
loadKycDetails();

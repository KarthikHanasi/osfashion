function isNumberKey(evt) {
  let charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

$(document).on('keypress',function(e) {
  if(e.which == 13) {
    $("#login").click();
  }
});

  $("#login").click(function (e) {
    //verification
    if ($("#txtMobileNo").val() == "") {
        alert("Please Enter Mobile Number");
        $("#txtMobileNo").focus();
        return false;
    }

    if ($("#txtMobileNo").val().length !== 10) {
        alert("Please Enter Correct Mobile Number");
        $("#txtMobileNo").focus();
        return false;
    }

    if ($("#txtPassword").val().trim().length < 1) {
        alert("Please Enter Password");
        $("#txtPassword").focus();
        return false;
    }
    
    let formData = new FormData();
    formData.append("txtMobileNo", $("#txtMobileNo").val());
    formData.append("txtPassword", $("#txtPassword").val());

    formData.append("action", "login");

    $.ajax({
      beforeSend: function () {
        $("#login").attr("disabled", true);
      },
      url: "backend/process_web.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {

        if(res == "10") {
          alert("Mobile Number OR Password is incorrect, Please try again!!!");
        } else {
          alert("Login Successful");
          let url = localStorage.getItem("url");
          localStorage.removeItem("url");

          try{
            if(url.length) {
              window.location = url;
            } else {
              window.location = 'index.php';
            }
          } catch {
            window.location = 'index.php';
          }
          
          
        }
        
      },
      error: function (res, error) {
        console.error(error);
      },
      complete: function () {
        $("#login").attr("disabled", false);
      },
    });
  });
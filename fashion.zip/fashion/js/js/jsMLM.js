    function getMLM() {
        let formData = new FormData();
      formData.append("action", "get_user_heirarchy_details");
  
      $.ajax({
        beforeSend: function () {
        },
        url: "backend/process_web_place_order.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
          let lclJSON = JSON.parse(response);
          // $("#chart-container").empty();
          const data = {"items": lclJSON}

          const buildTree = (main_id) => (item) => {
            const children = data.items.filter((child) => child.main_id === item.employee_id);
            return {
              ...item,
              ...(children.length > 0 && { children: children.map(buildTree(item.employee_id)) }),
            };
          };
          
          const nestedData = {
            items: data.items.filter((item) => !item.main_id).map(buildTree(undefined)),
          };
          
          console.log(nestedData);

          const {items} = nestedData 
          const [data1] = items;
          // console.log(data1)

          $(function() {
    
            $.mockjax({
              url: '/orgchart/initdata',
              responseTime: 1000,
              contentType: 'application/json',
              responseText: data1
            });
    
            $('#chart-container').orgchart({
            'data' : '/orgchart/initdata',
            'nodeContent': 'title'
            });
    
        });

        },
        error: function (error) {
          console.error(error);
        },
        complete: function () {
  
        },
      });
    }

    getMLM();


    function myfun(refId) {
      let formData = new FormData();
      formData.append("refId", refId);
      formData.append("action", "get_mynetwork_refid");
    
      $.ajax({
        url: "backend/process_web3.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
          let lclJSON = JSON.parse(response);
          let res = "";
          let email = lclJSON.details[0].us_email;
          if (email) {
            res = email;
          }
    
          $("#mlmDetails").html(
            '<div class="container"><div class="row"><div class="photo"><div class="col-"><img class="profile rounded" src="img/myprofile.png" alt="profile"><div class="mt-2"><span class="in" for=""><b>'+
            lclJSON.details[0].us_rank +'</b></div></div></div><div class="col"><span class="info"><b>Name : </b>' +
              lclJSON.details[0].us_name +
              '</span><br><span class="info"><b>Age : </b>22</span><br><span class="info"><b>Ref Code : </b>' +
              lclJSON.details[0].us_referral_code +
              '</span><br><span class="info"><b>Ref By : </b>' +
              lclJSON.details2[0].us_name +
              '</span><br><span class="info"><b>Gender : </b></span><br><span class="info" ><b>Email : </b>' +
               res +
              "</span><span></span></div></div></div>"
          );
        },
      });
      $("#exampleModal").modal("show");
    }
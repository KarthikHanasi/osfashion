function loadOrderDetails() {

    let formData = new FormData();
    formData.append("action", "get_credit_history");
    let totalAmount = 0;
    let totalBV = 0;

        $.ajax({

            url: "backend/process_web_place_order.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);

                if(response == 10) {
                    window.location = 'login.php';
                } else {
                for(let i = 0; i < lclJSON.creditHistoryArray.length; i++) {
                    let lclDate = (lclJSON.creditHistoryArray[i].ach_created_date).substring(0,10);
                    let lclLevel = (lclJSON.creditHistoryArray[i].ach_level == 0) ? "R" : lclJSON.creditHistoryArray[i].ach_level;
                    $("#creditHistoryDetails").append('<tr><td class="order-title first-row"><a href="user_details.php?q='+lclJSON.creditHistoryArray[i].us_id+'" style="text-decoration:underline;color:black">'+lclJSON.creditHistoryArray[i].us_name+' ('+lclJSON.creditHistoryArray[i].us_rank+')</a></td><td class="order-title first-row">'+lclJSON.creditHistoryArray[i].ach_amount+'</td><td class="order-title first-row">'+lclJSON.creditHistoryArray[i].ach_bv+'</td><td class="order-title first-row">'+lclJSON.creditHistoryArray[i].ach_percentage+'</td><td class="order-title first-row">'+lclLevel+'</td><td class="order-title first-row"><h5 style="width: 120px; font-size: 14px;">'+formatDate(lclDate)+'</h5></td></tr>');

                    totalAmount = totalAmount + parseFloat(lclJSON.creditHistoryArray[i].ach_amount);
                    totalBV = totalBV + parseFloat(lclJSON.creditHistoryArray[i].ach_bv);

                    $("#totalAmount").text("₹ "+totalAmount.toFixed(2));
                    $("#totalBV").text(totalBV);

                }
            }
        }  
    });
    
  }

  loadOrderDetails();

  function loadLevelDetails() {

    let formData = new FormData();
    formData.append("action", "get_level_user_count");

        $.ajax({

            url: "backend/process_web_place_order.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);

                if(response == 10) {
                    window.location = 'login.php';
                } else {
                for(let i = 0; i < lclJSON.levelDetails.length; i++) {
                    let totalBv = Number(lclJSON.levelDetails[i].totalBVNoWithinDays) + Number(lclJSON.levelDetails[i].totalBVWithinDays);
                    let totalAmount = Number(lclJSON.levelDetails[i].totalAmountNoWithinDays) + Number(lclJSON.levelDetails[i].totalAmountWithinDays);

                    $("#levelDetails").append('<tr><td class="order-title first-row"><h5>'+lclJSON.levelDetails[i].li_level_count+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.levelDetails[i].users+'</h5></td><td class="order-title first-row"><h5>'+totalBv+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.levelDetails[i].achPercentageNoWithinDays+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.levelDetails[i].totalAmountNoWithinDays+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.levelDetails[i].achPercentageWithinDays+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.levelDetails[i].totalAmountWithinDays+'</h5></td><td class="order-title first-row"><h5>'+totalAmount.toFixed(2)+'</h5></td></tr>');

                }
            }
        }  
    });
    
  }

  loadLevelDetails();
 
  function formatDate (input) {
    let datePart = input.match(/\d+/g),
    year = datePart[0].substring(), // get only two digits
    month = datePart[1], day = datePart[2];

    return `${day}-${month}-${year}`;
  }


let searchRes = () => {

    if($("#fromDate").val() != "") {
        if($("#toDate").val() == "") {
            alert("Please select to Date");
            $("#toDate").focus();
            return false;
        }
    }

    let formData = new FormData();
    formData.append("fromDate", $("#fromDate").val());
    formData.append("toDate", $("#toDate").val());
    formData.append("txtName", $("#txtName").val());
    formData.append("txtReferCode", $("#txtReferCode").val());
    formData.append("action", "get_credit_history_by_search");
    let totalAmount = 0;
    $("#totalAmount").text("₹ 0");
    $("#creditHistoryDetails").empty()

        $.ajax({

            url: "backend/process_web_place_order.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);

                if(response == 10) {
                    window.location = 'login.php';
                } else {
                for(let i = 0; i < lclJSON.creditHistoryArray.length; i++) {
                    let lclDate = (lclJSON.creditHistoryArray[i].ach_created_date).substring(0,10);
                    $("#creditHistoryDetails").append('<tr><td class="order-title first-row"><a href="user_details.php?q='+lclJSON.creditHistoryArray[i].us_id+'" style="text-decoration:underline;color:black"><h5>'+lclJSON.creditHistoryArray[i].us_name+' ('+lclJSON.creditHistoryArray[i].us_rank+')</h5></a></td><td class="order-title first-row"><h5>'+lclJSON.creditHistoryArray[i].ach_amount+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.creditHistoryArray[i].ach_bv+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.creditHistoryArray[i].ach_percentage+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.creditHistoryArray[i].ach_level+'</h5></td><td class="order-title first-row"><h5>'+formatDate(lclDate)+'</h5></td></tr>');

                    totalAmount = totalAmount + parseFloat(lclJSON.creditHistoryArray[i].ach_amount);

                    $("#totalAmount").text("₹ "+totalAmount.toFixed(2));

                }
            }
        }  
    });
}

function loadBusinessRanksDetails() {

    let formData = new FormData();
    formData.append("action", "get_business_ranks_history");
    let totalAmount = 0;

        $.ajax({

            url: "backend/process_web3.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);

                if(response == 10) {
                    window.location = 'login.php';
                } else {
                for(let i = 0; i < lclJSON.creditHistoryArray.length; i++) {
                    let lclDate = (lclJSON.creditHistoryArray[i].ach_created_date).substring(0,10);
                    $("#businessRankDetails").append('<tr><td class="order-title first-row">'+lclJSON.creditHistoryArray[i].br_rank_name+'</td><td class="order-title first-row">'+lclJSON.creditHistoryArray[i].ach_amount+'</td><td class="order-title first-row">'+lclJSON.creditHistoryArray[i].ach_percentage+'</td><td class="order-title first-row"><h5 style="width: 120px; font-size: 14px;">'+formatDate(lclDate)+'</h5></td></tr>');

                    // totalAmount = totalAmount + parseFloat(lclJSON.creditHistoryArray[i].ach_amount);

                    // $("#totalAmount").text("₹ "+totalAmount.toFixed(2));

                }
            }
        }  
    });
    
  }

  loadBusinessRanksDetails();
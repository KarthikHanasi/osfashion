function loadOrderDetails() {

    let formData = new FormData();
    formData.append("action", "get_orders_details");

        $.ajax({

            url: "backend/process_web.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);
                let totalAmount = 0;

                if(response == 10) {
                    window.location = 'login.php';
                } else {
                for(let i = 0; i < lclJSON.orderDetails.length; i++) {

                    let orderID = "'"+lclJSON.orderDetails[i].or_id+"'";

                    $("#orderDetails").append('<tr><td class="order-title first-row"><h5>'+lclJSON.orderDetails[i].or_readable_id+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.orderDetails[i].ads_fullName+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.orderDetails[i].ads_mobile_number+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.orderDetails[i].ads_address+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.orderDetails[i].or_payment_type+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.orderDetails[i].or_total_amount+'</h5></td><td class="order-title first-row"><h5>'+lclJSON.orderDetails[i].os_delivery_status+'</h5></td><td class="order-title first-row"><h5><a href="JavaScript:void(0)" class="view-order" onclick="myProducts('+orderID+')">view</a></h5></td></tr>');

                    // <td class="order-title first-row"><h5><a href="JavaScript:void(0)" class="cancel-order" onclick="orderCancelReason('+orderID+')"></a></h5></td>

                    totalAmount = totalAmount + parseFloat(lclJSON.orderDetails[i].or_total_amount);

                    $("#totalAmount").text("₹ "+totalAmount.toFixed(2));

              }
            }
        }  
    });
    
  }

  loadOrderDetails();
  let returnOrderID = "";
  function orderReturnReason(id) {
    returnOrderID = id;
    $('#reasonOrderReturn').modal('show');
  }

  function myProducts(id) {
    
    let formData = new FormData();
    formData.append('orderID', id);
    formData.append("action", "get_my_products_details");

    $.ajax({
        beforeSend: function () {
      },
      url: "backend/process_web.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        $("#myOrders").empty();
        $("#myProducts").empty();
        $('#productDetails').modal('show');
        let lclJSON = JSON.parse(response);
        for(let i = 0; i < lclJSON.orderDetails.length; i++) {

          let lclAddress = `${lclJSON.orderDetails[i].ads_address}  ${lclJSON.orderDetails[i].ads_city} ${lclJSON.orderDetails[i].st_name} ${lclJSON.orderDetails[i].ads_pincode}`;
          let transactionNo = (lclJSON.orderDetails[i].or_transaction_no === null ) ? "" : lclJSON.orderDetails[i].or_transaction_no;

            $("#myOrders").append('<tr><th>Order ID</th><td>'+lclJSON.orderDetails[i].or_readable_id+'</td></tr><tr><th>Name</th><td>'+lclJSON.orderDetails[i].ads_fullName+'</td></tr><tr><th>Mobile</th><td>'+lclJSON.orderDetails[i].ads_mobile_number+'</td></tr><tr><th>Date</th><td>'+formatDate(lclJSON.orderDetails[i].or_created_date)+'</td></tr><tr><th>Transaction ID</th><td>'+transactionNo+'</td></tr><tr><th>Sub Total</th><td>'+lclJSON.orderDetails[i].or_sub_total+'</td></tr><tr><th>Shipping Charges</th><td>'+lclJSON.orderDetails[i].or_shipping_charges+'</td></tr><tr><th>Discount</th><td>'+lclJSON.orderDetails[i].or_used_coins+'</td></tr><tr><th>Total</th><td>'+lclJSON.orderDetails[i].or_total_amount+'</td></tr><tr><th>Address</th><td>'+lclAddress+'</td></tr>');
        }

        for(let i = 0; i < lclJSON.productDetails.length; i++) {

            let productID = "'"+lclJSON.productDetails[i].pp_id+"'";
            let totalPrice = Number(lclJSON.productDetails[i].pp_pd_price) * Number(lclJSON.productDetails[i].pp_qty);
            $("#myProducts").append('<tr><td><img src="'+lclJSON.productDetails[i].pd_image+'" height="50" alt=""></td><td>'+lclJSON.productDetails[i].pd_name+'</td><td>'+lclJSON.productDetails[i].pp_pd_price+'</td><td>'+lclJSON.productDetails[i].pp_qty+'</td><td>'+totalPrice.toFixed(2)+'</td><td><a href="JavaScript:void(0)" class="view-order" onclick="reviewProduct('+productID+')">Review</a></td><td class="order-title first-row"><h5><a href="JavaScript:void(0)" class="cancel-order" onclick="orderReturnReason('+productID+')">Return Order</a></h5></td></tr>');
        }
      },
      error: function (error) {
        console.error(error);
      },
      complete: function () {
      },
    });
  }

  function returnOrder() {

    let returnTrue = confirm("Are you sure want to Return Order?")

    if(!returnTrue) {
      return false;
    }
    let formData = new FormData();
    // formData.append('orderID', returnOrderID);
    formData.append('productID', returnOrderID);
    formData.append("txtReason", $("#txtReason").val());
    formData.append("action", "return_order");

    $.ajax({
        beforeSend: function () {
      },
      url: "backend/process_web3.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        if(response.trim() == "10") {
          alert("You cannot return order, you exceeded 15 days return policy");
        } else if(response.trim() == "20") {
          alert("Product is Already Returned");
        } else {
          alert("Product Return is Successful, Thank you");
          location.reload();
        }

      },
      error: function (error) {
        console.error(error);
      },
      complete: function () {
      },
    });
  }

  function reviewProduct(id) {
    $('#reviewProduct').modal('show');
    $("#product_id").val(id);
  }

  function formatDate (input) {
    let datePart = input.match(/\d+/g),
    year = datePart[0].substring(), // get only two digits
    month = datePart[1], day = datePart[2];

    return `${day}-${month}-${year}`;
  }

  function printData() {

    $("#txtTotal").val(lclRoundOffValue);
   
    $("#txtPrintName").val($("#txtCusName").val());
    $("#txtPrintAddress").val($("#txtAddress").val());
    $("#txtPrintMobile").val($("#txtMobile").val());

    $("#txtPrintDate").val(formatDate($("#txtSaleDate").val()));
    $("#txtPrintInvoice").val($("#txtUniqueNo").val());
    $("#txtPrintTransportName").val($("#txtTransporterName").val());
    $("#txtPrintTransportVehicleNo").val($("#txtTransporterVehicleNo").val());
    $("#txtPrintGSTNo").val($("#selGSTIN").val());
    $("#txtPrintTotal").val(parseFloat(Math.round($("#txtSubTotal").val())).toFixed(2));
    $("#txtPrintSGST").val(parseFloat($("#txtSGST").val()).toFixed(2));
    $("#txtPrintCGST").val(parseFloat($("#txtCGST").val()).toFixed(2));
    $("#txtPrintIGST").val(parseFloat($("#txtIGST").val()).toFixed(2));
    $("#txtPrintRoundOff").val($("#txtRoundOff").val());
    $("#txtPrintGrandTotal").val(parseFloat($("#txtTotal").val()).toFixed(2));

  }

  function deliveryOrderCancel(awb, token) {

    let settings = {
      "url": "https://api.nimbuspost.com/v1/shipments/cancel",
      "method": "POST",
      "timeout": 0,
      "headers": {
        "Content-Type": "application/json",
        "Authorization": "Bearer "+token
      },
      "data": JSON.stringify({
        "awb": awb
      }),
    };
    
    $.ajax(settings).done(function (response) {
      console.log(response);
      location.reload();
    });
  }
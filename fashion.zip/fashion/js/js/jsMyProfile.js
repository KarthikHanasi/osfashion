function isNumberKey(evt) {
  let charCode = evt.which ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

let userAddressDetails;
function loadProfileDetails() {
  let formData = new FormData();
  formData.append("action", "get_profile");

  $.ajax({
    url: "backend/process_web.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      let lclJSON = JSON.parse(response);
      if (response == 10) {
        window.location = "login.php";
      } else {
        $("#txtName").val(lclJSON.userInfo[0].us_name);
        $("#headName").text(lclJSON.userInfo[0].us_name);
        $("#rank").text(`(${lclJSON.userInfo[0].us_rank})`);
        $("#txtMobileNo").val(lclJSON.userInfo[0].us_mobile);
        $("#txtEmailID").val(lclJSON.userInfo[0].us_email);
        $("#txtDesignation").val(lclJSON.userInfo[0].us_designation);
        $("#selBloodGroup").val(lclJSON.userInfo[0].us_blood_group);
        referralCode =
          lclJSON.userInfo[0].us_referral_code == "No"
            ? "No Referral"
            : lclJSON.userInfo[0].us_referral_code;
        $("#myInput").val(referralCode);
        $("#myWallet").val(lclJSON.userInfo[0].us_wallet);
        $("#myCoins").val(lclJSON.userInfo[0].us_coins_usage);
        $("#myTeamBV").val(lclJSON.totalBV);
      }

      userAddressDetails = lclJSON.userAddress;

      for (let i = 0; i < lclJSON.userAddress.length; i++) {
        let addressID = "'" + lclJSON.userAddress[i].ads_id + "'";
        $("#addressList").append(
          '<div class="card mb-4 shadow-lg"><div class="card-body"><p class="card-text"><b>' +
            lclJSON.userAddress[i].ads_fullName +
            "," +
            lclJSON.userAddress[i].ads_address +
            "," +
            lclJSON.userAddress[i].ads_pincode +
            " " +
            lclJSON.userAddress[i].ads_city +
            ",<br> " +
            lclJSON.userAddress[i].st_name +
            ", " +
            lclJSON.userAddress[i].ads_mobile_number +
            '</b></p><a class="btn font-weight-bold text-white" href=JavaScript:void(0) onclick="editAddress(' +
            addressID +
            ')">Edit</a> <a class="btn font-weight-bold text-white" href="#address" onclick="deleteAddress(' +
            addressID +
            ')">Delete</a></div></div>'
        );
      }
    },
  });
}

loadProfileDetails();

function editAddress(addressId) {
  userAddressDetails.forEach((element) => {
    if (element.ads_id === addressId) {
      $("#txtFullName").val(element.ads_fullName);
      $("#txtMobileNo1").val(element.ads_mobile_number);
      $("#txtAddress").val(element.ads_address);
      $("#txtAddress2").val(element.ads_address2);
      $("#txtCity").val(element.ads_city);
      $("#txtState").val(element.ads_state);
      $("#txtPincode").val(element.ads_pincode);
      $("#txtId").val(element.ads_id);
      $("#txtFullName").focus();
      $("html,body").animate({ scrollTop: "400" }, 2000);
    }
  });
}

$("#updateProfile").click(function (e) {
  //verification
  if ($("#txtName").val().trim().length < 1) {
    alert("Please Enter Full Name");
    $("#txtName").focus();
    return false;
  }

  let formData = new FormData();

  // let lclImage = document.getElementById("uploadProfileImage");
  // lclImage1 = lclImage.files[0];
  // formData.append("uploadProfileImage", lclImage1);

  formData.append("txtName", $("#txtName").val());
  formData.append("txtEmailID", $("#txtEmailID").val());
  formData.append("txtDesignation", $("#txtDesignation").val());
  formData.append("selBloodGroup", $("#selBloodGroup").val());
  formData.append("action", "update_profile");

  $.ajax({
    beforeSend: function () {
      $("#updateProfile").attr("disabled", true);
    },
    url: "backend/process_web.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (res) {
      alert("Profile Updated Successfully");
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $("#updateProfile").attr("disabled", false);
    },
  });
});

$("#addNewAddress").click(function (e) {
  //verification
  if ($("#txtFullName").val().trim().length < 1) {
    alert("Please Enter Full Name");
    $("#txtFullName").focus();
    return false;
  }

  if ($("#txtMobileNo1").val().trim().length < 1) {
    alert("Please Enter Mobile Number");
    $("#txtMobileNo1").focus();
    return false;
  }

  if ($("#txtMobileNo1").val().trim().length < 10) {
    alert("Please Enter 10 Digits Mobile Number");
    $("#txtMobileNo1").focus();
    return false;
  }

  if ($("#txtAddress").val().trim().length < 1) {
    alert("Please Enter Address");
    $("#txtAddress").focus();
    return false;
  }

  if ($("#txtCity").val().trim().length < 1) {
    alert("Please Enter City");
    $("#txtCity").focus();
    return false;
  }

  if ($("#txtState").val().trim().length < 1) {
    alert("Please Select State");
    $("#txtState").focus();
    return false;
  }

  if ($("#txtPincode").val().trim().length < 1) {
    alert("Please Enter Pincode");
    $("#txtPincode").focus();
    return false;
  }

  if (
    $("#txtPincode").val().trim().length < 6 ||
    $("#txtPincode").val().trim().length > 6
  ) {
    alert("Please Enter Valid Pincode");
    $("#txtPincode").focus();
    return false;
  }

  let formData = new FormData();
  formData.append("txtId", $("#txtId").val());
  formData.append("txtFullName", $("#txtFullName").val());
  formData.append("txtMobileNo1", $("#txtMobileNo1").val());
  formData.append("txtAddress", $("#txtAddress").val());
  formData.append("txtAddress2", $("#txtAddress2").val());
  formData.append("txtCity", $("#txtCity").val());
  formData.append("txtState", $("#txtState").val());
  formData.append("txtPincode", $("#txtPincode").val());
  if ($("#txtId").val()) {
    formData.append("action", "update_new_address");
  } else {
    formData.append("action", "add_new_address");
  }

  $.ajax({
    beforeSend: function () {
      $("#addNewAddress").attr("disabled", true);
    },
    url: "backend/process_web.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      alert("Address saved successfully");
      // loadProfileDetails();
      $("#addressList").empty();
      // $(".add-address").hide();
      let lclJSON = JSON.parse(response);
      userAddressDetails = lclJSON.userAddress;
      // console.log(lclJSON.userAddress[i].ads_mobile_number)
      for (let i = 0; i < lclJSON.userAddress.length; i++) {
        let addressID = "'" + lclJSON.userAddress[i].ads_id + "'";
        $("#addressList").append(
          '<div class="card mb-4 shadow-lg"><div class="card-body"><p class="card-text"><b>' +
            lclJSON.userAddress[i].ads_fullName +
            "," +
            lclJSON.userAddress[i].ads_address +
            "," +
            lclJSON.userAddress[i].ads_pincode +
            " " +
            lclJSON.userAddress[i].ads_city +
            ",<br> " +
            lclJSON.userAddress[i].st_name +
            ", " +
            lclJSON.userAddress[i].ads_mobile_number +
            '</b></p><a class="btn font-weight-bold text-white" href=JavaScript:void(0) onclick="editAddress(' +
            addressID +
            ')">Edit</a> <a class="btn font-weight-bold text-white" href="#address" onclick="deleteAddress(' +
            addressID +
            ')">Delete</a></div></div>'
        );
      }
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $("#addNewAddress").attr("disabled", false);
      $("#txtFullName").val("");
      $("#txtMobileNo1").val("");
      $("#txtAddress").val("");
      $("#txtCity").val("");
      $("#txtState").val("");
      $("#txtPincode").val("");
      $("#txtId").val("");
    },
  });
});

function deleteAddress(id) {
  let formData = new FormData();
  formData.append("addressID", id);
  formData.append("action", "delete_address");

  $.ajax({
    beforeSend: function () {
      $("#addNewAddress").attr("disabled", true);
    },
    url: "backend/process_web.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      alert("Address Deleted Successfully");

      $("#addressList").empty();
      let lclJSON = JSON.parse(response);
      // userAddressDetails = ''
      userAddressDetails = lclJSON.userAddress;
      for (let i = 0; i < lclJSON.userAddress.length; i++) {
        let addressID = "'" + lclJSON.userAddress[i].ads_id + "'";
        $("#addressList").append(
          '<div class="card mb-4 shadow-lg"><div class="card-body"><p class="card-text"><b>' +
            lclJSON.userAddress[i].ads_fullName +
            "," +
            lclJSON.userAddress[i].ads_address +
            "," +
            lclJSON.userAddress[i].ads_pincode +
            " " +
            lclJSON.userAddress[i].ads_city +
            ",<br> " +
            lclJSON.userAddress[i].st_name +
            ", " +
            lclJSON.userAddress[i].ads_mobile_number +
            '</b></p><a class="btn font-weight-bold text-white" href=JavaScript:void(0) onclick="editAddress(' +
            addressID +
            ')">Edit</a> <a class="btn font-weight-bold text-white" href="#address" onclick="deleteAddress(' +
            addressID +
            ')">Delete</a></div></div>'
        );
      }
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $("#addNewAddress").attr("disabled", false);
    },
  });
}

function uploadImage() {
  let formData = new FormData();

  let lclImage = document.getElementById("uploadProfileImage");
  let lclImage1 = lclImage.files[0];
  formData.append("uploadProfileImage", lclImage1);
  formData.append("action", "upload_image");

  $.ajax({
    beforeSend: function () {
      $("#updateProfile").attr("disabled", true);
    },
    url: "backend/process_web3.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (res) {
      if (res === "10") {
        window.location = "login.php";
      }
      $("#profileImage").attr("src", res);
      location.reload()
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $("#updateProfile").attr("disabled", false);
    },
  });
}

function getProfileImage() {
  let formData = new FormData();
  formData.append("action", "get_image");
  $.ajax({
    beforeSend: function () {
      $("#updateProfile").attr("disabled", true);
    },
    url: "backend/process_web3.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      let lclJSON = JSON.parse(response);
      if (response === "10") {
        window.location = "login.php";
      }
      if(lclJSON.userInfo[0].us_image) {
        $("#profileImage").attr("src", lclJSON.userInfo[0].us_image);
      } else {
        $("#profileImage").attr("src", "img/myprofile.png");
      }
      
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {
      $("#updateProfile").attr("disabled", false);
    },
  });
}

getProfileImage()

function loadWithdrwalsDetails() {

    let formData = new FormData();
    formData.append("action", "get_withdrawals");
    let totalAmount = 0;

        $.ajax({

            url: "backend/process_web3.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);

                if(response == 10) {
                    window.location = 'login.php';
                } else {
                for(let i = 0; i < lclJSON.withdrawalsDetails.length; i++) {
                    j = i + 1;
                    $("#withdrawalsDetails").append("<tr><td>"+j+"</td><td>"+lclJSON.withdrawalsDetails[i].us_name+"</td><td>"+lclJSON.withdrawalsDetails[i].us_mobile+"</td><td>"+lclJSON.withdrawalsDetails[i].wt_amount+"</td><td>"+lclJSON.withdrawalsDetails[i].wt_transaction_id+"</td><td style='width: 100px'>"+formatDate(lclJSON.withdrawalsDetails[i].wt_payment_date)+"</td><td>"+lclJSON.withdrawalsDetails[i].bank_user_name+"</td><td>"+lclJSON.withdrawalsDetails[i].bank_number+"</td></tr>");

                    totalAmount = totalAmount + Number(lclJSON.withdrawalsDetails[i].wt_amount);

                }

                $("#totalAmount").text("₹ "+totalAmount.toFixed(2));
            }
        }  
    });
    
  }

  loadWithdrwalsDetails();
 
  function formatDate (input) {
    let datePart = input.match(/\d+/g),
    year = datePart[0].substring(), // get only two digits
    month = datePart[1], day = datePart[2];

    return `${day}-${month}-${year}`;
  }


let searchRes = () => {

    if($("#fromDate").val() != "") {
        if($("#toDate").val() == "") {
            alert("Please select to Date");
            $("#toDate").focus();
            return false;
        }
    }

    let formData = new FormData();
    formData.append("fromDate", $("#fromDate").val());
    formData.append("toDate", $("#toDate").val());
    formData.append("action", "search_my_withdrawals");
    let totalAmount = 0;
    $("#totalAmount").text("₹ 0");
    $("#withdrawalsDetails").empty()

        $.ajax({

            url: "backend/process_web3.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);

                if(response == 10) {
                    window.location = 'login.php';
                } else {
                for(let i = 0; i < lclJSON.withdrawalsDetails.length; i++) {
                    $("#withdrawalsDetails").append("<tr><td>"+j+"</td><td>"+lclJSON.withdrawalsDetails[i].us_name+"</td><td>"+lclJSON.withdrawalsDetails[i].us_mobile+"</td><td>"+lclJSON.withdrawalsDetails[i].wt_amount+"</td><td>"+lclJSON.withdrawalsDetails[i].wt_transaction_id+"</td><td style='width: 100px'>"+formatDate(lclJSON.withdrawalsDetails[i].wt_payment_date)+"</td><td>"+lclJSON.withdrawalsDetails[i].bank_user_name+"</td><td>"+lclJSON.withdrawalsDetails[i].bank_number+"</td></tr>");

                    totalAmount = totalAmount + Number(lclJSON.withdrawalsDetails[i].wt_amount);

                }
            }
        }  
    });
}

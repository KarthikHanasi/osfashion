function loadPaymentDetails() {

    let formData = new FormData();
    formData.append("transaction_id", $("#transaction_id").val());
    formData.append("action", "update_payment");

    $("#paymentStatus").text('SUCCESS');
    $("#paymentID").text($("#transaction_id").val());

    $.ajax({

        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {

            if(response === 10) {
                alert("Payment Already Captured, Thank You");
            }
            
        }
        
    });
    
  }

  loadPaymentDetails();
 
    history.pushState(null, null, 'index.php');
    window.addEventListener('popstate', function(event) {
      history.pushState(null, null, 'index.php');
    });

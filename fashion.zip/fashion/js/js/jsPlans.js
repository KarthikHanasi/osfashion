
function loadPlansDetails() {

    let formData = new FormData();
    formData.append("action", "get_plans");

        $.ajax({

            url: "backend/process_web2.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);
                    
                for(let i = 0; i < lclJSON.planDetails.length; i++) {
                    $("#planDetails").append('<ul class="card ul-radio"><label><div class="div-radio"><input type="radio" name="member" value="'+lclJSON.planDetails[i].pl_id+'"><span class="plan-name"><b>'+lclJSON.planDetails[i].pl_name+'</b></span> &emsp; <span class="plan-name"><b>₹ '+lclJSON.planDetails[i].pl_amount+'</b></span></div></label></ul>');
                }
            }
            
        });
    
  }

  loadPlansDetails();

  $("#member").click(function (e) {
    let planID = $("input[name='member']:checked").val();

    if(!planID) {
      alert("Please Select Plan");
      return false;
    }
    
    let formData = new FormData();
    formData.append("planID", planID);

    formData.append("action", "new_member");

    $.ajax({
      beforeSend: function () {
        $("#register").attr("disabled", true);
      },
      url: "backend/process_web2.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {

        if(res == "10") {
            alert("You are already Member");
        } else if(res == "20") {
            alert("Please Login/Register");
            window.location = 'login.php';
        } else {
            alert("Thank you for becoming a Valuable Member");
            window.location = 'member.php';
        }
        
      },
      error: function (res, error) {
        console.error(error);
      },
      complete: function () {
        $("#register").attr("disabled", false);
      },
    });
  });
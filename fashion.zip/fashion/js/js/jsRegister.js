function isNumberKey(evt) {
  let charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

$(document).on('keypress',function(e) {
  if(e.which == 13) {
    $("#register").click();
  }
});

  $("#register").click(function (e) {
    //verification
    if ($("#txtName").val().trim().length < 1) {
        alert("Please Enter Full Name");
        $("#txtName").focus();
        return false;
    }

    if ($("#txtMobileNo").val().trim() === "") {
        alert("Please Enter Mobile Number");
        $("#txtMobileNo").focus();
        return false;
    }

    if ($("#txtMobileNo").val().trim().length !== 10) {
        alert("Please Enter Correct Mobile Number");
        $("#txtMobileNo").focus();
        return false;
    }

    if ($("#txtPassword").val().trim().length < 5) {
        alert("Please Enter Password Minimum length 5");
        $("#txtPassword").focus();
        return false;
    }

    if($("#txtConfirmPassword").val() == "") {
        alert("Please Enter Confirm Password");
        $("#txtConfirmPassword").focus();
        return false;
    }

    if($("#txtPassword").val() != $("#txtConfirmPassword").val()) {
        alert("Password and Confirm Password does not match");
        $("#txtConfirmPassword").focus();
        return false;
    }

    const otp = Math.floor(100000 + Math.random() * 900000);
    // const otp = '123456';
    
    let formData = new FormData();
    formData.append("otp", otp);
    formData.append("txtName", $("#txtName").val());
    formData.append("txtMobileNo", $("#txtMobileNo").val());
    formData.append("txtReferralCode", $("#txtReferralCode").val());
    formData.append("txtPassword", $("#txtPassword").val());

    formData.append("action", "register");

    $.ajax({
      beforeSend: function () {
        $("#register").attr("disabled", true);
        $("#register").html("<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> REGISTERING...");
      },
      url: "backend/process_web.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {

        if(res == "10") {
          alert("You are already registered, Please Login");
        } else if(res == "20") {
          alert("Invalid Referral Code");
          $("#txtReferralCode").focus();
        } else {
          // executeSMS(otp, $("#txtMobileNo").val());
          window.location = 'verify_mobile.php';
          // window.location = 'login.php';
        }
        
      },
      error: function (res, error) {
        console.error(error);
      },
      complete: function () {
        $("#register").attr("disabled", false);
        $("#register").html("REGISTER");
      },
    });
  });

  function executeSMS(otp, mobile) {

		let formData = new FormData();
		$.ajax({
			url: "http://sms.pearlsms.com/public/sms/send?sender=OSFSNN&smstype=TRANS&numbers="+mobile+"&apikey=5aa722b394c14f799fb01cc6caa69375&message=Dear client , Your One Time Password is "+otp+" - One Step Fashion Network OSFSNN",
			type: "GET",
			data: formData,
      crossDomain: true,
      // datatype: 'jsonp',
			processData: false,
			contentType: false,
			success: function (res) {
			}
		});
	}


function validateEmail(paramEmailID) {
    var filter = /^[0-9a-z.]+\@[a-z0-9]+\.[a-zA-z0-9]{2,4}$/;
    
    if (filter.test(paramEmailID)) {
      return true;
    } else {
      return false;
    }
  }
$("#submitReview").click(function (e) {
    //verification
    if ($("#txtName").val().trim().length < 1) {
      alert("Please Enter Full Name");
      $("#txtName").focus();
      return false;
    }

    if ($("#txtEmail").val().trim() === "") {
      alert("Please Enter Email");
      $("#txtEmail").focus();
      return false;
    }

    if(!validateEmail($("#txtEmail").val())) {
      alert("Please  Enter Valid Email");
      $("#txtEmail").focus();
      return false;
	  }

    if($("#rating").val() == "") {
      alert("Please Select Ratng");
      $("#rating").focus();
      return false;
    }

    if($("#comment").val().trim() == "") {
        alert("Please Enter Comment");
        $("#comment").focus();
        return false;
    }
    
    let formData = new FormData();
    formData.append("productId", $("#product_id").val());
    formData.append("txtName", $("#txtName").val());
    formData.append("txtEmail", $("#txtEmail").val());
    formData.append("rating", $("#rating").val());
    formData.append("comment", $("#comment").val());


    formData.append("action", "add_review");

    $.ajax({
      beforeSend: function () {
        $("#register").attr("disabled", true);
      },
      url: "backend/process_web.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {

        if(res == "10") {
          window.location = 'login.php';
        } else if(res == "11") {
          alert("You have already given review to this product");
        }else{
          alert("Review submitted successfully")
          // getReviewDetails();
          $("#txtName").val('');
          $("#txtEmail").val('');
          $("#rating").val('');
          $("#comment").val('');
          $('#reviewProduct').modal('hide');

        }
      },
      error: function (res, error) {
        console.error(error);
      },
      complete: function () {
        $("#register").attr("disabled", false);
      },
    });
  });

  function getReviewDetails() {
    let formData = new FormData();
    formData.append("productId", $("#product_id").val());
    formData.append("action", "get_review");

    $.ajax({

        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {

            let lclJSON = JSON.parse(response);
            const {reviews, count} = lclJSON;
            $("#review").empty();
            $("#reviewCount").text(`${count} Reviews`)
            $("#customerReviewCount").text(`Customer Reviews (${count})`)

            for(let i = 0; i < reviews.length; i++) {
              const date = reviews[i].rv_created_date.slice(0,11)
                $("#review").append('<div class=co-item><div class=avatar-pic><img alt=""src=img/myprofile.png></div><div class=avatar-text><div class=at-rating><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star-o"></i></div><h5>'+reviews[i].rv_name+'<span>'+date+'</span></h5><div class=at-reply>'+reviews[i].rv_review+'</div></div></div>');
            }
        }
    });
}

getReviewDetails()
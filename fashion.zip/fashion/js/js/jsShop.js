function loadAllProductDetails() {

    let formData = new FormData();
    formData.append("action", "get_shop_all_products");

    $.ajax({

        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {

            let lclJSON = JSON.parse(response);
            let checkOutOfStock = "";
            if($("#categoryVal").val() == "") {
                for(let i = 0; i < lclJSON.products.length; i++) {

                    // if(Number(lclJSON.products[i].pd_stock) <= 0) {
                    //     checkOutOfStock = '<div class="sale pp-out-of-stock">Out Of Stock</div>';
                    // } else {
                        checkOutOfStock = '<div class="sale pp-sale">'+lclJSON.products[i].pd_discount+'% discount</div>';
                    // }


                    $("#products").append('<div class="col-6 col-lg-4 col-sm-6"><div class=product-item><div class=pi-pic><a href="product.php?id='+lclJSON.products[i].pd_id+'"><img alt="" src="'+lclJSON.products[i].pd_image+'"></a><ul class="quick-view-animation"><li class="w-icon active"><a href="#"><i class=icon_bag_alt></i></a><li class=quick-view><a href="product.php?id='+lclJSON.products[i].pd_id+'">+ Quick View</a><li class=w-icon><a href=#><i class="fa fa-random"></i></a></ul></div><div class=pi-text><div class=catagory-name>'+lclJSON.products[i].ca_name+'</div><a href="product.php?id='+lclJSON.products[i].pd_id+'"><h5>'+lclJSON.products[i].pd_name+'</h5></a>'+checkOutOfStock+'<div class=product-price>₹'+lclJSON.products[i].pd_discount_price+'&nbsp;<span>₹'+lclJSON.products[i].pd_price+'</span></div></div></div></div>');
                }
            }

            
            for(let i = 0; i < lclJSON.category.length; i++) {
                let categoryID = "'"+lclJSON.category[i].ca_id+"'";
                $("#category").append('<li class="ct-list" onclick="getCategoryShopDetails('+categoryID+')">'+lclJSON.category[i].ca_name+'</li>');
            }
                
        }
    });
    
  }
  

  if($("#categoryVal").val() == "" && $("#searchVal").val() == "") {
    loadAllProductDetails();
  } else if($("#searchVal").val() != "") {
    getSearchResults($("#searchVal").val());
  } else {
    getCategoryShopDetails($("#categoryVal").val());
    loadAllProductDetails();
  }

function getCategoryShopDetails(categoryName) {
    let formData = new FormData();
    formData.append("category", categoryName);
    formData.append("action", "get_category_shop_details");
    $("#products").empty();

    $.ajax({

        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {

            let lclJSON = JSON.parse(response);
            let checkOutOfStock = "";

            for(let i = 0; i < lclJSON.products.length; i++) {

                // if(Number(lclJSON.products[i].pd_stock) <= 0) {
                //     checkOutOfStock = '<div class="sale pp-out-of-stock">Out Of Stock</div>';
                // } else {
                    checkOutOfStock = '<div class="sale pp-sale">'+lclJSON.products[i].pd_discount+'% discount</div>';
                // }
                $("#products").append('<div class="col-6 col-lg-4 col-sm-6"><div class=product-item><div class=pi-pic><a href="product.php?id='+lclJSON.products[i].pd_id+'"><img alt="" src="'+lclJSON.products[i].pd_image+'"></a><ul class="quick-view-animation"><li class="w-icon active"><a href="#"><i class=icon_bag_alt></i></a><li class=quick-view><a href="product.php?id='+lclJSON.products[i].pd_id+'">+ Quick View</a><li class=w-icon><a href=#><i class="fa fa-random"></i></a></ul></div><div class=pi-text><div class=catagory-name>'+lclJSON.products[i].ca_name+'</div><a href="product.php?id='+lclJSON.products[i].pd_id+'"><h5>'+lclJSON.products[i].pd_name+'</h5></a>'+checkOutOfStock+'<div class=product-price>₹'+lclJSON.products[i].pd_discount_price+'&nbsp;<span>₹'+lclJSON.products[i].pd_price+'</span></div></div></div></div>');
            }

            $("#selSubCategory").empty();
            $("#selSubCategory").append('<option value="">Sort By Sub Category</option>');
            for(let i = 0; i < lclJSON.subCategory.length; i++) {
                $("#selSubCategory").append('<option value="'+lclJSON.subCategory[i].sub_id+'">'+lclJSON.subCategory[i].sub_category_name+'</option>');
            }
        }
    });
  }

  function getSubCategoryShopDetails() {
    let formData = new FormData();
    formData.append("subcategory", $("#selSubCategory").val());
    formData.append("action", "get_sub_category_shop_details");

    if($("#selSubCategory").val() !== "") {
        $("#products").empty();
        $.ajax({

            url: "backend/process_web.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {

                let lclJSON = JSON.parse(response);
                let checkOutOfStock = "";

                for(let i = 0; i < lclJSON.products.length; i++) {

                    // if(Number(lclJSON.products[i].pd_stock) <= 0) {
                    //     checkOutOfStock = '<div class="sale pp-out-of-stock">Out Of Stock</div>';
                    // } else {
                        checkOutOfStock = '<div class="sale pp-sale">'+lclJSON.products[i].pd_discount+'% discount</div>';
                    // }
                    $("#products").append('<div class="col-6 col-lg-4 col-sm-6"><div class=product-item><div class=pi-pic><a href="product.php?id='+lclJSON.products[i].pd_id+'"><img alt="" src="'+lclJSON.products[i].pd_image+'"></a><ul class="quick-view-animation"><li class="w-icon active"><a href="#"><i class=icon_bag_alt></i></a><li class=quick-view><a href="product.php?id='+lclJSON.products[i].pd_id+'">+ Quick View</a><li class=w-icon><a href=#><i class="fa fa-random"></i></a></ul></div><div class=pi-text><div class=catagory-name>'+lclJSON.products[i].ca_name+'</div><a href="product.php?id='+lclJSON.products[i].pd_id+'"><h5>'+lclJSON.products[i].pd_name+'</h5></a>'+checkOutOfStock+'<div class=product-price>₹'+lclJSON.products[i].pd_discount_price+'&nbsp;<span>₹'+lclJSON.products[i].pd_price+'</span></div></div></div></div>');
                }
            }
        });
    }
  }

  function getSearchResults(categoryName) {
    let formData = new FormData();
    formData.append("searchVal", categoryName);
    formData.append("action", "get_search_details");
    $("#products").empty();

    $.ajax({

        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {

            let lclJSON = JSON.parse(response);
            let checkOutOfStock = "";

            for(let i = 0; i < lclJSON.products.length; i++) {

                // if(Number(lclJSON.products[i].pd_stock) <= 0) {
                //     checkOutOfStock = '<div class="sale pp-out-of-stock">Out Of Stock</div>';
                // } else {
                    checkOutOfStock = '<div class="sale pp-sale">'+lclJSON.products[i].pd_discount+'% discount</div>';
                // }
                $("#products").append('<div class="col-6 col-lg-4 col-sm-6"><div class=product-item><div class=pi-pic><a href="product.php?id='+lclJSON.products[i].pd_id+'"><img alt="" src="'+lclJSON.products[i].pd_image+'"></a><ul class="quick-view-animation"><li class="w-icon active"><a href="#"><i class=icon_bag_alt></i></a><li class=quick-view><a href="product.php?id='+lclJSON.products[i].pd_id+'">+ Quick View</a><li class=w-icon><a href=#><i class="fa fa-random"></i></a></ul></div><div class=pi-text><div class=catagory-name>'+lclJSON.products[i].ca_name+'</div><a href="product.php?id='+lclJSON.products[i].pd_id+'"><h5>'+lclJSON.products[i].pd_name+'</h5></a>'+checkOutOfStock+'<div class=product-price>₹'+lclJSON.products[i].pd_discount_price+'&nbsp;<span>₹'+lclJSON.products[i].pd_price+'</span></div></div></div></div>');
            }
            
            for(let i = 0; i < lclJSON.category.length; i++) {
                let categoryID = "'"+lclJSON.category[i].ca_id+"'";
                $("#category").append('<li class="ct-list" onclick="getCategoryShopDetails('+categoryID+')">'+lclJSON.category[i].ca_name+'</li>');
            }
        }
    });
  }
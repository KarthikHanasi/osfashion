let setColorID = "";
// $(".btn-add-to-cart").hide();

function loadSingleProductDetails() {
    let productId = $("#product_id").val();

    let formData = new FormData();
    formData.append("action", "get_single_product_details");
    formData.append("id", productId);

        $.ajax({

            url: "backend/process_web.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
              let lclJSON = JSON.parse(response);
              const [{pd_color: color}] = lclJSON.products;
              // const [{pd_size : size}] = lclJSON.products;
              let saveSize = [];
              let sizeArray;
              for(let s = 0; s < lclJSON.productSize.length; s++) {
                saveSize.push(lclJSON.productSize[s].ps_sz_id);
              }
              saveSize = saveSize.toString();

              sizeArray = saveSize.split(',');
              let colorArray = color.split(',');
              

              const mappedColors = lclJSON.color.filter(({ co_id: co_id }) => colorArray.some((item) => item === co_id));
              const mappedSizes = lclJSON.size.filter(({ sz_id: sz_id }) => sizeArray.some((item) => item === sz_id));

              if(lclJSON.length != 0) {

                for(let i = 0; i < lclJSON.products.length; i++) {
                  
                  $("#container").append('<img src="'+lclJSON.products[i].pd_image+'" id="show-img">');

                  if(lclJSON.products[i].pd_sub_image1 != "") {
                    $("#small-img-roll").append('<img src="'+lclJSON.products[i].pd_sub_image1+'" class="show-small-img" alt="">');
                  }

                  if(lclJSON.products[i].pd_sub_image2 != "") {
                    $("#small-img-roll").append('<img src="'+lclJSON.products[i].pd_sub_image2+'" class="show-small-img" alt="">');
                  }

                  if(lclJSON.products[i].pd_sub_image3 != "") {
                    $("#small-img-roll").append('<img src="'+lclJSON.products[i].pd_sub_image3+'" class="show-small-img" alt="">');
                  }

                  if(lclJSON.products[i].pd_sub_image4 != "") {
                    $("#small-img-roll").append('<img src="'+lclJSON.products[i].pd_sub_image4+'" class="show-small-img" alt="">');
                  }

                  $("#product-details").append('<div class=pd-title><span>'+lclJSON.products[i].ca_name+'</span><h3>'+lclJSON.products[i].pd_name+'</h3><span class="text-danger font-weight-bold out-of-stock">OUT OF STOCK</span></div><a href="#customerReviewCount" id="reviewClick"><div class="pd-rating"><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star-o"></i> <span>(5)</span></div></a><div class=pd-desc><p>'+lclJSON.products[i].pd_short_desc+'<h4>₹'+lclJSON.products[i].pd_discount_price+'<span>₹'+lclJSON.products[i].pd_price+'</span><a style="font-size: 18px;">('+lclJSON.products[i].pd_discount+'% discount)</a></h4></div>');

                  
                  if(lclJSON.productSize.length <= 0) {
                    $(".out-of-stock").show();
                    $("#AddToCart").attr("disabled", true);
                    $("#checkout").attr("disabled", true);

                    $("#AddToCart").css("background", "gray");
                    $("#checkout").css("background", "gray");

                  } else {
                    $(".out-of-stock").hide();

                    $("#AddToCart").attr("disabled", false);
                    $("#checkout").attr("disabled", false);

                    $("#AddToCart").css("background", "#e7ab3c");
                    $("#checkout").css("background", "#e7ab3c");
                  }

                  if(lclJSON.products[0].pd_stock == 0 && lclJSON.productSize.length <= 0) {
                    $(".out-of-stock").show();
                    $("#AddToCart").attr("disabled", true);
                    $("#checkout").attr("disabled", true);

                    $("#AddToCart").css("background", "gray");
                    $("#checkout").css("background", "gray");
                  } else {

                    $(".out-of-stock").hide();

                    $("#AddToCart").attr("disabled", false);
                    $("#checkout").attr("disabled", false);

                    $("#AddToCart").css("background", "#e7ab3c");
                    $("#checkout").css("background", "#e7ab3c");

                  }

                  document.title = `OsFashion ${lclJSON.products[i].pd_name}`;

                  $("#longDesc").text(lclJSON.products[i].pd_long_desc);
                  
                  $("#product-bvpv").append('<span class="pb-3"><b class="d-none">Stock : </b><span id="spanStock" class="d-none">'+lclJSON.products[i].pd_stock+'</span><span class="pb-3"><b>Product Code : </b><span>'+lclJSON.products[i].pd_product_id+'</span>&emsp;<span class="pb-3"><b>BV : </b><span>'+lclJSON.products[i].pd_bv+' </span>');

                  $(".ps-slider").owlCarousel({
                    loop: true,
                    margin: 10,
                    nav: true,
                    items: 3,
                    dots: false,
                    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
                    smartSpeed: 600,
                    autoHeight: false,
                    autoplay: true,
                  });
                  
                }

                if(mappedSizes.length) {
                  $("#product-size").append('<h6 class="pb-3"><b>Size</b></h6>');
                }

                if(mappedColors.length) {
                  $("#product-color").append('<h6 class="pb-3"><b>Color</b></h6>');
                }
                
                for(let i = 0; i < mappedSizes.length; i++) {
                  let sz_id = "'"+mappedSizes[i].sz_id+"'";
                  $("#product-size").append('<div class="sc-item" id="sc-item'+i+'"><input id="sm-size" class="sm-size" type="radio" value='+mappedSizes[i].sz_name+'> <label onClick="getSize('+sz_id+', '+i+')" style="margin-bottom: 0px;">'+mappedSizes[i].sz_name+'</label></div>'); 
                }

                for(let i = 0; i < mappedColors.length; i++) {
                  let colorCode = "'"+mappedColors[i].co_code+"'";
                  let colorId = "'"+mappedColors[i].co_id+"'";
                  setColorID = mappedColors[i].co_id;

                   $("#product-color").append('<button id="btnColor'+i+'" class="btnColor" style="background-color:'+mappedColors[i].co_code+';border-style:none;border-radius:5px;width:20px;height:20px;" type="button" onClick="getColor('+i+','+colorId+')"><input id="txtColor" type="hidden" value='+mappedColors[i].co_code+'></button>'); 
                }

                let checkOutOfStock = "";

                for(let i = 0; i < lclJSON.similarProducts.length; i++) {


                  // if(Number(lclJSON.productSize.length) <= 0) {
                    // checkOutOfStock = '<div class="sale pp-out-of-stock">Out Of Stock</div>';
                  // } else {
                    checkOutOfStock = '<div class="sale pp-sale">'+lclJSON.similarProducts[i].pd_discount+'% discount</div>';
                  // }
                  
                  $("#similarProducts").append('<div class="col-6 col-lg-4 col-sm-6"><div class=product-item><div class=pi-pic><a href="product.php?id='+lclJSON.similarProducts[i].pd_id+'"><img alt="" src="'+lclJSON.similarProducts[i].pd_image+'"></a>'+checkOutOfStock+'<ul class="quick-view-animation"><li class="w-icon active"><a href="#"><i class=icon_bag_alt></i></a><li class=quick-view><a href="product.php?id='+lclJSON.similarProducts[i].pd_id+'">+ Quick View</a><li class=w-icon><a href=#><i class="fa fa-random"></i></a></ul></div><div class=pi-text><a href="product.php?id='+lclJSON.similarProducts[i].pd_id+'"><h5>'+lclJSON.similarProducts[i].pd_name+'</h5></a><div class=product-price>₹'+lclJSON.similarProducts[i].pd_discount_price+'&nbsp;<span>₹'+lclJSON.similarProducts[i].pd_price+'</span></div></div></div></div>');
                }

                const container = document.getElementById("container");
                const img = document.getElementById("show-img");

                container.addEventListener("mousemove", (e) => {
                    const x = e.clientX - e.target.offsetLeft;
                    const y = e.clientY - e.target.offsetTop;

                    img.style.transformOrigin = `${x}px ${y}px`;
                    img.style.transform = "scale(2)";

                });

                container.addEventListener("mouseleave", () => {
                    img.style.transformOrigin = "center";
                    img.style.transform = "scale(1)";
                });

                $('.show-small-img:first-of-type').css({'border': 'solid 1px #951b25', 'padding': '2px'})
                  $('.show-small-img:first-of-type').attr('alt', 'now').siblings().removeAttr('alt')
                  $('.show-small-img').click(function () {
                    $('#show-img').attr('src', $(this).attr('src'))
                    $('#big-img').attr('src', $(this).attr('src'))
                    $(this).attr('alt', 'now').siblings().removeAttr('alt')
                    $(this).css({'border': 'solid 1px #951b25', 'padding': '2px'}).siblings().css({'border': 'none', 'padding': '0'})
                    if ($('#small-img-roll').children().length > 4) {
                      if ($(this).index() >= 3 && $(this).index() < $('#small-img-roll').children().length - 1){
                        $('#small-img-roll').css('left', -($(this).index() - 2) * 76 + 'px')
                      } else if ($(this).index() == $('#small-img-roll').children().length - 1) {
                        $('#small-img-roll').css('left', -($('#small-img-roll').children().length - 4) * 76 + 'px')
                      } else {
                        $('#small-img-roll').css('left', '0')
                      }
                    }
                  })
                
            }

          }
        });
    
  }
  loadSingleProductDetails();

  const colorId = {
    id : null
  }

  const sizeId = {
    id : null
  }

  const getColor = (i,id) => {
    $(".btnColor").css("border","0");
    $("#btnColor"+i).css({
      'border': 'solid 2px #e7ab3c',
      'margin-top': '5px'
    });
    colorId.id = id
  }

  const getSize = (id,i) => {
    $(".sc-item").css("border","0")
    $('#sc-item'+i).css({
      'border': 'solid 1px red'
    });

    sizeId.id = id
  }

  $("#AddToCart").click(function() {

    // if(Number($("#quantity").val()) > Number($("#spanStock").text())) {
    //   alert("Your are selecting more quantity than available quantity");
    //   return false;
    // }

    if($("#product-size").text().trim().length != 0) {
      if(sizeId.id === null) {
        alert("Please Select Size");
        return false;
      }
    }

    let formData = new FormData();
  
    formData.append("product_id", $("#product_id").val());
    formData.append("quantity", $("#quantity").val());
    formData.append("color", setColorID);
    formData.append("size", sizeId.id);

    formData.append("action", "add_cart");
    $("#AddToCart").attr("disabled", true);
    $("#AddToCart").html("<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> Please Wait adding to cart...");
  
    $.ajax({
      url: "backend/process_web.php",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (res) {
        window.location = "shopping-cart.php";
      },
    });
  });

  $("#checkout").click(function() {
    if($("#product-size").text().trim().length != 0) {
      if(sizeId.id === null){
        alert("Please Select Size");
        return false;
      }
    }

    // if(Number($("#quantity").val()) > Number($("#spanStock").text())) {
    //   alert("Your are selecting more quantity than available quantity");
    //   return false;
    // }

    let encrypted = localStorage.getItem("login");
    let decrypted = CryptoJS.AES.decrypt(encrypted, "osfashionKey");
    let decVal = decrypted.toString(CryptoJS.enc.Utf8);
    if(decVal === "NO") {
      let checkConfirm = confirm("Login to checkout");

      if(checkConfirm) {
        window.location = 'login.php';
      }

      localStorage.setItem("url", 'check-out.php?q='+$("#product_id").val()+'&qty='+$("#quantity").val()+'&color='+colorId.id+'&size='+sizeId.id);
      return false;
    }

    $("#checkout").html("<span class='spinner-border spinner-border-sm btn-add-to-cart'></span> Please Wait adding to checkout...");

    window.location = 'check-out.php?q='+$("#product_id").val()+'&qty='+$("#quantity").val()+'&color='+setColorID+'&size='+sizeId.id;
  });

  // $(".pd-rating").click(function() {
  //   // $("#customerReviewCount").click();
  //   $("#customerReviewCount").addClass("active");
  // });

  
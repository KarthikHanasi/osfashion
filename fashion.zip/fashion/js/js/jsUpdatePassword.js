
$(document).on('keypress',function(e) {
    if(e.which == 13) {
        $("#updatePassword").click();
    }
});
  
    $("#updatePassword").click(function (e) {
      //verification
        if ($("#txtPassword").val() == "") {
            alert("Please Enter Password");
            $("#txtPassword").focus();
            return false;
        }

        if ($("#txtPassword").val().length < 5) {
            alert("Please Enter Password Minimum length 5");
            $("#txtPassword").focus();
            return false;
        }
  
        if ($("#txtCPassword").val() == "") {
            alert("Please Enter Confirm Password");
            $("#txtCPassword").focus();
            return false;
        }

        if ($("#txtPassword").val() != $("#txtCPassword").val()) {
            alert("Password and Confirm Password does not match");
            $("#txtCPassword").focus();
            return false;
        }
      
        let formData = new FormData();
        formData.append("txtPassword", $("#txtPassword").val());
        formData.append("action", "update_password");
  
        $.ajax({
            beforeSend: function () {
                $("#updatePassword").attr("disabled", true);
            },
            url: "backend/process_web.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (res) {

                if(res == "10") {
                    alert("Something went wrong!!!");
                } else {
                    alert("Password Updated Successfully");
                    window.location = "login.php";
                }
                
            },
            error: function (res, error) {
            console.error(error);
            },
            complete: function () {
            $("#updatePassword").attr("disabled", false);
            },
        });
    });
    
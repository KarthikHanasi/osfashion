function loadProfileDetails() {
  let formData = new FormData();
  formData.append("action", "get_user_details");
  formData.append("txtId", $("#txtId").val());

  $.ajax({
    url: "backend/process_web2.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      let lclJSON = JSON.parse(response);
      if (response == 10) {
        window.location = "login.php";
      } else {
        $("#txtName").val(lclJSON.userInfo[0].us_name);
        $("#headName").text(lclJSON.userInfo[0].us_name);
        $("#rank").text(`(${lclJSON.userInfo[0].us_rank})`);

        $("#txtMobileNo").val(lclJSON.userInfo[0].us_mobile);
        $("#txtEmailID").val(lclJSON.userInfo[0].us_email);
        referralCode =
          lclJSON.userInfo[0].us_referral_code == "No"
            ? "No Referral"
            : lclJSON.userInfo[0].us_referral_code;
        $("#myInput").val(referralCode);
        $("#myWallet").val(lclJSON.userInfo[0].us_wallet);
        $("#myCoins").val(lclJSON.userInfo[0].us_coins);
      }

      userAddressDetails = lclJSON.userAddress;

      for (let i = 0; i < lclJSON.userAddress.length; i++) {
        let addressID = "'" + lclJSON.userAddress[i].ads_id + "'";
        $("#addressList").append(
          '<div class="card mb-4 shadow-lg"><div class="card-body"><p class="card-text"><b>' +
            lclJSON.userAddress[i].ads_fullName +
            "," +
            lclJSON.userAddress[i].ads_address +
            "," +
            lclJSON.userAddress[i].ads_pincode +
            " " +
            lclJSON.userAddress[i].ads_city +
            ",<br> " +
            lclJSON.userAddress[i].st_name +
            ", " +
            lclJSON.userAddress[i].ads_mobile_number +
            '</b></p><a class="btn font-weight-bold text-white" href=JavaScript:void(0) onclick="editAddress(' +
            addressID +
            ')">Edit</a> <a class="btn font-weight-bold text-white" href="#address" onclick="deleteAddress(' +
            addressID +
            ')">Delete</a></div></div>'
        );
      }
    },
  });
}

loadProfileDetails();

function getMLM() {
  let formData = new FormData();
  formData.append("txtId", $("#txtId").val());
  formData.append("action", "get_user_heirarchy_details");

  $.ajax({
    beforeSend: function () {},
    url: "backend/process_web2.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
      let lclJSON = JSON.parse(response);
      // $("#chart-container").empty();
      const data = { items: lclJSON };

      const buildTree = (main_id) => (item) => {
        const children = data.items.filter(
          (child) => child.main_id === item.employee_id
        );
        return {
          ...item,
          ...(children.length > 0 && {
            children: children.map(buildTree(item.employee_id)),
          }),
        };
      };

      const nestedData = {
        items: data.items
          .filter((item) => !item.main_id)
          .map(buildTree(undefined)),
      };

      console.log(nestedData);

      const { items } = nestedData;
      const [data1] = items;
      // console.log(data1)

      $(function () {
        $.mockjax({
          url: "/orgchart/initdata",
          responseTime: 1000,
          contentType: "application/json",
          responseText: data1,
        });

        $("#chart-container").orgchart({
          data: "/orgchart/initdata",
          nodeContent: "title",
        });
      });
    },
    error: function (error) {
      console.error(error);
    },
    complete: function () {},
  });
}

getMLM();

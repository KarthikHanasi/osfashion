function isNumberKey(evt) {
    let charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

$(document).on('keypress',function(e) {
    if(e.which == 13) {
        $("#forgotPasswordOTP").click();
    }
});
  
    $("#forgotPasswordOTP").click(function (e) {
      //verification
      if ($("#txtOTP").val() == "") {
          alert("Please Enter OTP");
          $("#txtOTP").focus();
          return false;
      }
  
      if ($("#txtOTP").val().length !== 6) {
          alert("Please Enter Valid OTP");
          $("#txtOTP").focus();
          return false;
      }
      
      let formData = new FormData();
      formData.append("txtOTP", $("#txtOTP").val());
      formData.append("action", "verify_mobile");
  
      $.ajax({
        beforeSend: function () {
          $("#login").attr("disabled", true);
        },
        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {

          if(res == "10") {
            alert("Invalid OTP");
          } else {
            window.location = "login.php";
          }
            
        },
        error: function (res, error) {
          console.error(error);
        },
        complete: function () {
          $("#login").attr("disabled", false);
        },
      });
    });
    


    $("#resendOTP").click(function (e) {
      
      let formData = new FormData();
      formData.append("action", "resend_otp_mobile");
  
      $.ajax({
        beforeSend: function () {
          $("#login").attr("disabled", true);
        },
        url: "backend/process_web.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
          alert("OTP Resent Successfully");
        },
        error: function (res, error) {
          console.error(error);
        },
        complete: function () {
          $("#login").attr("disabled", false);
        },
      });
    });
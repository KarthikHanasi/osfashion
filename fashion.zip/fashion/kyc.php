<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description"
        content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <style>
        input[type="file"] {
            color: transparent;
        }
    </style>
</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>My Profile</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <!-- My Profile Begin -->
    <div class="my-profile mt-5">
        <div class="container">
            <div class="mobile-quick-access">
                <div class="row">
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="myprofile.php" class="text-dark">My Profile</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow  p-2 text-center">
                        <a href="my_orders.php" class="text-dark">My Orders</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="mlm.php" class="text-dark">My Network</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="add_address.php" class="text-dark">Add Address</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="my_credit_history.php" class="text-dark">My Credits</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="withdraw.php" class="text-dark">My Withdrawal</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center my-profile-color">
                        <a href="kyc.php" class="text-white">My KYC</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="identity_card.php" class="text-dark">My ID</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="networking_business_plan.php" class="text-dark">N & B Plans</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2 desktop-quick-access">
                    <h4>Quick Access</h4>

                    <ul class="quick-menu">
                    <li class="list"><a href="myprofile.php">My Profile</a></li>
                        <li class="list"><a href="my_orders.php">My Orders</a></li>
                        <li class="list"><a href="mlm.php">My Network</a></li>
                        <li class="list"><a href="add_address.php">Add Address</a></li>
                        <li class="list"><a href="my_credit_history.php">My Credits</a></li>
                        <li class="list"><a href="withdraw.php">My Withdrawal</a></li>
                        <li class="list"><a href="kyc.php">My KYC</a></li>
                        <li class="list"><a href="identity_card.php">My ID</a></li>
                        <li class="list"><a href="networking_business_plan.php">N & B Plans</a></li>

                    </ul>
                </div>
                <div class="col-md-9">
                    <h2 class="mt-5 text-center">KYC</h2>
                    <form action="#" method="get">
                        <div class="row p-3"
                            style="box-shadow: rgba(6, 24, 44, 0.4) 0px 0px 0px 2px, rgba(6, 24, 44, 0.65) 0px 4px 6px -1px, rgba(255, 255, 255, 0.08) 0px 1px 0px inset;">
                            <div class="col-md-3">
                                <label for="username">Aadhar Number</label>
                                <input type="text" id="txtAadharNumber" class="form-control"
                                    onkeypress="return isNumberKey(event);" maxlength="12">
                            </div>
                            <div class="col-md-3">
                                <div class="form-group mt-1">
                                    <label for="exampleFormControlFile1">Upload Aadhar</label>
                                    <input type="file" class="form-control-file" id="uploadAadharFile" value="">
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <a href="#" id="aadharLink" download><img src="img/No-Image.png" id="aadharImg"
                                            class="form-control" style="height:100px;width:100px"></a>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <button type="button" id="saveAadhar" class="mt-4">Save</button>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group mt-4 ml-5">
                                    <span class="badge badge-info p-3 mobile-view-badge" id="aadharStatus">Pending</span>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-5 p-3"
                            style="box-shadow: rgba(6, 24, 44, 0.4) 0px 0px 0px 2px, rgba(6, 24, 44, 0.65) 0px 4px 6px -1px, rgba(255, 255, 255, 0.08) 0px 1px 0px inset;">

                            <div class="col-md-3">
                                <div>
                                    <label for="username">Pan Number</label>
                                    <input type="text" id="txtPanNumber" class="form-control text-uppercase"
                                        maxlength="10">
                                </div>
                            </div>


                            <div class="col-md-3">
                                <div class="form-group mt-1">
                                    <label for="exampleFormControlFile1">Upload Pan</label>
                                    <input type="file" class="form-control-file" id="uploadPanFile">
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <a href="#" id="panLink" download><img src="img/No-Image.png" id="panImg"
                                            class="form-control" style="height:100px;width:100px"></a>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <button type="button" id="savePan" class="mt-4">Save</button>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group mt-4 ml-5">
                                    <span class="badge badge-info p-3 mobile-view-badge" id="panStatus">Pending</span>
                                </div>
                            </div>

                        </div>
                        <div class="row my-5 p-3"
                            style="box-shadow: rgba(6, 24, 44, 0.4) 0px 0px 0px 2px, rgba(6, 24, 44, 0.65) 0px 4px 6px -1px, rgba(255, 255, 255, 0.08) 0px 1px 0px inset;">
                            <div class="col-md-4">
                                <div>
                                    <label for="username">Bank Holder Name</label>
                                    <input type="text" id="txtBankUserName" class="form-control" value="">
                                </div>
                            </div>


                            <div class="col-md-4">
                                <div>
                                    <label for="username">Bank Account Number</label>
                                    <input type="text" id="txtBankNumber" class="form-control" value="">
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div>
                                    <label for="username">Bank Name</label>
                                    <input type="text" id="txtBankName" class="form-control" value="">
                                </div>
                            </div>

                            <div class="col-md-3 mt-2">
                                <div>
                                    <label for="username">IFSC Code</label>
                                    <input type="text" id="txtBankIfsc" class="form-control" value="">
                                </div>
                            </div>

                            <div class="col-md-3 mt-2">
                                <div class="form-group mt-1">
                                    <label for="exampleFormControlFile1">Upload First page of Bank Passbook</label>
                                    <input type="file" class="form-control-file" id="uploadBankFile">
                                </div>
                            </div>

                            <div class="col-md-2 mt-2">
                                <div class="form-group">
                                    <a href="#" id="bankLink" download><img src="img/No-Image.png" id="bankImg"
                                            class="form-control" style="height:100px;width:100px"></a>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group mt-4">
                                    <button type="button" id="saveBankDetails" class="mt-4">Save</button>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group mt-5 ml-5">
                                    <span class="badge badge-info p-3 mobile-view-badge" id="bankStatus">Pending</span>
                                </div>
                            </div>

                        </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    </div>


    <!-- My Profile Begin -->

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsKyc.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>


</body>

</html>
<script>
    $(function () {
        $('input[type="file"]').change(function () {
            if ($(this).val() != "") {
                $(this).css('color', '#333');
            } else {
                $(this).css('color', 'transparent');
            }
        });
    })

</script>
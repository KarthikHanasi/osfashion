<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion - Member</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <style>
        .password-container{
            position: relative;
        }
        .password-container input[type="password"],
        .password-container input[type="text"]{
            width: 100%;
            box-sizing: border-box;
        }
        .fa-eye{
            position: absolute;
            top: 30%;
            right: 4%;
            cursor: pointer;
            color: lightgray;
        }
    </style>
</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>Member</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <!-- Register Section Begin -->
    <div class="register-login-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="login-form">
                        <h2>Member</h2>
                        <form action="#" autocomplete="off">
                            <div id="planDetails">
                            </div>
                            <button type="button" id="member" class="site-btn login-btn">Become a member</button>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 ">
                    <div class="">
                        <p><b>Early Registering Advantage.</b></p>
                        <p>On Registering early during the launching of our digital shop, as a special benefit on registering you will get virtual coins worth the same value as free. You can redeem the virtual coins during your purchases.</p>

                        <p><b>Activation of Digital Shop.</b></p>
                        <p>You can become distributor of our company by opting for any of the above membership plans. Once registered you can as per your requirements make purchases.</p>
                        <p>When you register on our digital shop by paying any of the above-mentioned amount you become a distributor of our company, you can purchase any material using 25% of your valet Coins 2 times, remaining Coin can be used as peer the company offers.</p>
                        
                    </div>
                </div>

                <div class="col-lg-12 ">
                    <div class="">
                        <p><b>Benefits of Digital Shop</b></p>
                        <p>1) On registering on our website, you are allotted a Unique Referral ID (URI). Using this URI, you can shop on our website and avail attractive discounts and incentives.
                        <p>2) URI gives you the opportunity to create your own business, through which you can get others enrolled on our website promoting our business and in return earning referral Income.</p>
                        <p>3) You can also appoint Retailers, Distributors & Direct Leader Distributers, under you with the help of the referral number or code.</p>
                        <p>4) You will get 20% of the Virtual coins if you join any member (for Digital shop membership) under you using your URI.</p>
                        <p>5) 20% Of your 1st Levels Business Volume will be added to your Wallet as Virtual coins.</p>

                        <p><b>Every week there will be special offers for all the Digital shop members. You can Shop/Sell from our wide range of Products through our digital shop.</b></p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Register Form Section End -->

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/js/jsPlans.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>

</body>

</html>
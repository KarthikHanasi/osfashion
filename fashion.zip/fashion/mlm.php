<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="css/jquery.orgchart.css">
    <link rel="stylesheet" href="css/style1.css">

    <style>
        .profile {
            width: 100px;
            height: 100px;
        }

        .photo {
            width: 125px;
            padding: 10px;
        }
        .in {
            color:black;
        }
    </style>
</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>My Network</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <!-- My Profile Begin -->
    <div class="my-profile mt-5">
        <div class="container">
            <div class="mobile-quick-access">
                <div class="row">
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="myprofile.php" class="text-dark">My Profile</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow  p-2 text-center">
                        <a href="my_orders.php" class="text-dark">My Orders</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center my-profile-color">
                        <a href="mlm.php" class="text-white">My Network</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="add_address.php" class="text-dark">Add Address</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="my_credit_history.php" class="text-dark">My Credits</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="withdraw.php" class="text-dark">My Withdrawal</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="kyc.php" class="text-dark">My KYC</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="identity_card.php" class="text-dark">My ID</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="networking_business_plan.php" class="text-dark">N & B Plans</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3 desktop-quick-access">
                    <h4>Quick Access</h4>

                    <ul class="quick-menu">
                        <li class="list"><a href="myprofile.php">My Profile</a></li>
                        <li class="list"><a href="my_orders.php">My Orders</a></li>
                        <li class="list"><a href="mlm.php">My Network</a></li>
                        <li class="list"><a href="add_address.php">Add Address</a></li>
                        <li class="list"><a href="my_credit_history.php">My Credits</a></li>
                        <li class="list"><a href="withdraw.php">My Withdrawal</a></li>
                        <li class="list"><a href="kyc.php">My KYC</a></li>
                        <li class="list"><a href="identity_card.php">My ID</a></li>
                        <li class="list"><a href="networking_business_plan.php">N & B Plans</a></li>
                    </ul>
                </div>
                <div class="col-md-9">
                    <h2 class="text-center">My Network</h2>
                    <div id="chart-container"></div>
                </div>
            </div>
        </div>
    </div>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
            <div class="container ">
                <div class="row" id="mlmDetails">
                <!-- <img src="img/logo.png"> -->

                  <div class="photo">

                  <div class="col-">
                    <!-- <img class="profile rounded" src="img/about-1.jpg"  alt="profile"> -->
                    <img class ="profile rounded" src="img/myprofile.png" alt="profile">
     
                    <div class="mt-2">

                    <span class="in" for=""><b>Designation</b></label>
                    </div>

                    </div>
                  </div>
                  <div class="col ">
                    <span class="info"><b>Name  : </b></span>
                    <br/>
                    <span class="info"><b>Age  : </b></span>
                    <br/>

                    <span class="info"><b>Ref Code  :  </b></span>

                    <br/>
                    <span class="info"><b>Ref By  :  </b></span>
                    <br/>


                    <span class="info"><b>Gender  :  </b></span>
                    <br/>
                    <span class="info"><b>Email  :  </b></span>
                    <span></span>
                  </div>
                </div>
        </div>
      </div>
      <div class="modal-footer">
      </div></div></div>
</div>

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-mockjax/2.6.0/jquery.mockjax.min.js" integrity="sha512-XfnoLXUxtEYGVB+xpqJ8PIfAzz0oD6T4wX4BRFs/MLQxCI+DvQpgfAc3ydt3V7ZTyjaHwrtC/yTG508P1PBjXQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-mockjax/2.6.0/jquery.mockjax.js" integrity="sha512-ue/3zG3k88JRl94SfqJpn+iuWf20pPfk1e+BLqCFFrJvjtRtZP2IUjfUhUUjNVn52NK2b/uUNkic5q0oNRKwtQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript" src="js/jquery.orgchart.js"></script>
    <script src="js/js/jsMLM.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>
</body>

</html>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Junge' rel='stylesheet'>
    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <style>
        th, td {
            font-family: 'Junge';
        }

        th, td {
            font-size: 15px;
        }
    </style>
</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text product-more">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <!-- <a href="shop.php">Shop</a> -->
                        <span>My Credits</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Shopping Cart Section Begin -->
    <section class="my-profile my-5">
        <div class="container">
            <div class="mobile-quick-access">
                <div class="row">
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center ">
                        <a href="myprofile.php" class="text-dark">My Profile</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow  p-2 text-center">
                        <a href="my_orders.php" class="text-dark">My Orders</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="mlm.php" class="text-dark">My Network</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="add_address.php" class="text-dark">Add Address</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center  my-profile-color">
                        <a href="my_credit_history.php" class="text-white">My Credits</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="withdraw.php" class="text-dark">My Withdrawal</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="kyc.php" class="text-dark">My KYC</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="identity_card.php" class="text-dark">My ID</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="networking_business_plan.php" class="text-dark">N & B Plans</a>
                    </div>
                </div>
            </div>   

            <div class="row">
                <div class="col-md-3 desktop-quick-access">
                    <h4>Quick Access</h4>
                    <ul class="quick-menu">
                        <li class="list"><a href="myprofile.php">My Profile</a></li>
                        <li class="list"><a href="my_orders.php">My Orders</a></li>
                        <li class="list"><a href="mlm.php">My Network</a></li>
                        <li class="list"><a href="add_address.php">Add Address</a></li>
                        <li class="list"><a href="my_credit_history.php">My Credits</a></li>
                        <li class="list"><a href="withdraw.php">My Withdrawal</a></li>
                        <li class="list"><a href="kyc.php">My KYC</a></li>
                        <li class="list"><a href="identity_card.php">My ID</a></li>
                        <li class="list"><a href="networking_business_plan.php">N & B Plans</a></li>
                    </ul>
                </div>

                <div class="col-lg-9">
                    <div class="order-table">
                        <h4 class="text-center">Level wise User Count and Total Amount</h4>
                        <table id="levelDetails" class="table">
                            <thead>
                                <tr>
                                    <th>Level</th>
                                    <th>User Count</th>
                                    <th>BV</th>
                                    <th>%</th>
                                    <th>Level Income</th>
                                    <th>%</th>
                                    <th>Level Complete Income</th>
                                    <th>Total Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                               
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="col-md-3"></div>

                <div class="col-lg-9">
                    <div class="order-table">

                    <div class="row">
                        <div class="form-group col-sm-4">
                            <label>From Date</label>
                            <input type="date" id="fromDate" class="form-control">
                        </div>

                        <div class="form-group col-sm-4">
                            <label>To Date</label>
                            <input type="date" id="toDate" class="form-control">
                        </div>

                        <div class="form-group col-sm-4">
                            <label>Name</label>
                            <input type="text" id="txtName" class="form-control" placeholder="search by name">
                        </div>

                        <div class="form-group col-sm-4">
                            <label>Referal Code</label>
                            <input type="text" id="txtReferCode" class="form-control" placeholder="search by Referal Code">
                        </div>

                        <div class="form-group col-sm-3">
                            <label>Search</label>
                            <input type="button" id="btnSearch" class="primary-btn form-control" value="Search" style="padding: 4px 30px;" onclick="searchRes();">
                        </div>
                    </div>
                        <h4 class="text-center">My Credits</h4>
                        <span>R - Repurchase</span>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Credit From</th>
                                    <th>Amount</th>
                                    <th>BV</th>
                                    <th>%</th>
                                    <th>Level</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody id="creditHistoryDetails">
                               
                            </tbody>
                        </table>

                        <div class="col-md-4"></div>
                        <div class="col-md-1"></div>
                        <div style="display: flex;">

                            <div class="col-md-3">
                                <div class="proceed-checkout">
                                    <ul>
                                        <li class="cart-total">Total <span id="totalAmount">0.00</span></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="proceed-checkout">
                                    <ul>
                                        <li class="cart-total">Total BV <span id="totalBV">0</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <br>
                        <h4 class="text-center">My Ranks</h4>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Rank Name</th>
                                    <th>Amount</th>
                                    <th>%</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody id="businessRankDetails">
                               
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </section>


    <!-- print section -->
    <div style="display: none;">
        <table id="txtNameOfPage" border="1">
            <tr>
                <td id="tdPrintTable1" width="500">&nbsp;&nbsp;GSTIN : XXXXXXXXXXXX</td>
                <td id="tdtxtPrintTable1" width="200"></td>
            </tr>

            <tr>
                <td id="tdPrintTable1Head">&nbsp;OsFashion</td>
                <td id="tdtxtPrintTable1Tax">TAX - INVOICE</td>
            </tr>

            <tr>
                <td id="tdPrintTable1Add">&nbsp;Bharati sankul Building 2nd floor Club road belagavi Karnataka pin code 590001</td>
                <td id="tdtxtPrintTable1"></td>
            </tr>

            <tr>
                <td id="tdPrintTable1Add">&nbsp;Karnataka Phone : XXXXXXXXXX, XXXXXXXXXX</td>
                <td id="tdtxtPrintTable1"></td>
            </tr>
        </table>

        <table id="printTable1" border="1">

            <tr>
                <td id="tdPrintTableName1" width="400">&nbsp;M/s. <input type="text" class="input-val1" id="txtPrintName" size="45"></td>
                <td id="tdPrintDate" width="300">&nbsp;Date : <input type="text" class="input-val1" id="txtPrintDate" size="6"> <span style="color: black; width: 50%;">||</span> &nbsp;INVOICE No : <input type="text" class="input-val1" id="txtPrintInvoice" size="6"></td>
            </tr>

            <tr>
                <td id="tdPrintTableAddress1"></td>
                <td>&nbsp;GST No : <input type="text" class="input-val1" id="txtPrintGSTNo" size="25"></td>
            </tr>

            <tr>
                <td id="tdPrintTableAddress1"></td>
                <td id="txtPrintDelAddress">&nbsp;</td>
            </tr>
            
        </table>

        <table id="printTable2" border="1">

            <tr id="trPrintTable2">
                <th width="15" id="printHead" class="headPrint">Sl.No</th>
                <th width="420" id="" class="headPrint">Product</th>
                <th width="65" id="printHead" class="headPrint">Price</th>
                <th width="30" id="printHead" class="headPrint">QTY</th>
                <th width="90" id="printHead1" class="headPrint">Total</th>
            </tr>

            <tbody id="printTableData">

            </tbody>

        </table>

        <table id="printTable3">
            <tr>
                <td align="center" style="border-bottom: hidden; border-left: hidden; border-right: hidden; text-align: center;" width="700">This is computer generated copy, Signature is not Required</td>
            </tr>
        </table>
    </div>



    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/js/jsMyCreditHistory.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/print.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>
    
</body>

</html>
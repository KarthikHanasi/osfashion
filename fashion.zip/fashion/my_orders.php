<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text product-more">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <!-- <a href="shop.php">Shop</a> -->
                        <span>My Orders</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Shopping Cart Section Begin -->
    <section class="my-profile my-5">
        <div class="container">
            <div class="mobile-quick-access">
                <div class="row">
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center ">
                        <a href="myprofile.php" class="text-dark">My Profile</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow  p-2 text-center my-profile-color">
                        <a href="my_orders.php" class="text-white">My Orders</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="mlm.php" class="text-dark">My Network</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="add_address.php" class="text-dark">Add Address</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="my_credit_history.php" class="text-dark">My Credits</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="withdraw.php" class="text-dark">My Withdrawal</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="kyc.php" class="text-dark">My KYC</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="identity_card.php" class="text-dark">My ID</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="networking_business_plan.php" class="text-dark">N & B Plans</a>
                    </div>
                </div>
            </div>   

            <div class="row">
                <div class="col-md-3 desktop-quick-access">
                    <h4>Quick Access</h4>
                    <ul class="quick-menu">
                        <li class="list"><a href="myprofile.php">My Profile</a></li>
                        <li class="list"><a href="my_orders.php">My Orders</a></li>
                        <li class="list"><a href="mlm.php">My Network</a></li>
                        <li class="list"><a href="add_address.php">Add Address</a></li>
                        <li class="list"><a href="my_credit_history.php">My Credits</a></li>
                        <li class="list"><a href="withdraw.php">My Withdrawal</a></li>
                        <li class="list"><a href="kyc.php">My KYC</a></li>
                        <li class="list"><a href="identity_card.php">My ID</a></li>
                        <li class="list"><a href="networking_business_plan.php">N & B Plans</a></li>
                    </ul>
                </div>
                <div class="col-lg-9">
                    <div class="order-table">
                        <table id="orderDetails" class="table">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                    <th>Address</th>
                                    <th>Payment Type</th>
                                    <th>Amount</th>
                                    <th>Order Status</th>
                                    <th>View</th>
                                    <!-- <th>Action</th> -->
                                </tr>
                            </thead>
                            <tbody id="orderDetails">
                               
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="cart-buttons">
                                <a href="shop.php" class="primary-btn up-cart">Continue shopping</a>
                            </div>
                           
                        </div>
                        <div class="col-lg-4 offset-lg-4">
                            <div class="proceed-checkout">
                                <ul>
                                    <li class="cart-total">Total ₹<span id="totalAmount">0.00</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Shopping Cart Section End -->

    <div class="modal fade" id="productDetails" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="overflow: scroll !important;">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Order Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="overflow-y: auto !important;">
                <table class="table">
                    <tbody id="myOrders">
                        
                    </tbody>
                </table>
                <div style="overflow: auto">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th>QTY</th>
                                <th>Total Price</th>
                                <th>Review</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="myProducts">
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <!-- <button type="button" class="btn btn-danger">Print/Download</button> -->
            </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="reasonOrderReturn" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="overflow: scroll !important;">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Reason for Order Return</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="overflow-y: auto !important;">
                <label>Reason for Return</label>
                <textarea id="txtReason" class="form-control"></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" onclick="returnOrder();">Submit</button>
            </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="reviewProduct" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Review Product</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <div class="leave-comment">
                    <!-- <h4>Leave A Review</h4> -->
                    <form action="#" class="comment-form">
                        <input type="hidden" id="product_id">
                        <div class="row">
                            <div class="col-lg-12">
                                <input type="text" placeholder="Full Name" id="txtName" class='review'>
                            </div>
                            <div class="col-lg-12">
                                <input type="text" placeholder="Email" id="txtEmail" class='review'>
                            </div>
                            <div class="col-lg-12">
                                <select class="form-select" aria-label="Default select example" id="rating">
                                <option selected value="">Select Rating</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                </select>
                            </div>
                            <div class="col-lg-12">
                                <textarea placeholder="Write Review" id="comment"></textarea>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="site-btn" id="submitReview">Submit Review</button>
            </div>
            </div>
        </div>
    </div>

    <!-- print section -->
    <div style="display: none;">
        <table id="txtNameOfPage" border="1">
            <tr>
                <td id="tdPrintTable1" width="500">&nbsp;&nbsp;GSTIN : XXXXXXXXXXXX</td>
                <td id="tdtxtPrintTable1" width="200"></td>
            </tr>

            <tr>
                <td id="tdPrintTable1Head">&nbsp;OsFashion</td>
                <td id="tdtxtPrintTable1Tax">TAX - INVOICE</td>
            </tr>

            <tr>
                <td id="tdPrintTable1Add">&nbsp;Bharati sankul Building 2nd floor Club road belagavi Karnataka pin code 590001</td>
                <td id="tdtxtPrintTable1"></td>
            </tr>

            <tr>
                <td id="tdPrintTable1Add">&nbsp;Karnataka Phone : XXXXXXXXXX, XXXXXXXXXX</td>
                <td id="tdtxtPrintTable1"></td>
            </tr>
        </table>

        <table id="printTable1" border="1">

            <tr>
                <td id="tdPrintTableName1" width="400">&nbsp;M/s. <input type="text" class="input-val1" id="txtPrintName" size="45"></td>
                <td id="tdPrintDate" width="300">&nbsp;Date : <input type="text" class="input-val1" id="txtPrintDate" size="6"> <span style="color: black; width: 50%;">||</span> &nbsp;INVOICE No : <input type="text" class="input-val1" id="txtPrintInvoice" size="6"></td>
            </tr>

            <tr>
                <td id="tdPrintTableAddress1"></td>
                <td>&nbsp;GST No : <input type="text" class="input-val1" id="txtPrintGSTNo" size="25"></td>
            </tr>

            <tr>
                <td id="tdPrintTableAddress1"></td>
                <td id="txtPrintDelAddress">&nbsp;</td>
            </tr>
            
        </table>

        <table id="printTable2" border="1">

            <tr id="trPrintTable2">
                <th width="15" id="printHead" class="headPrint">Sl.No</th>
                <th width="420" id="" class="headPrint">Product</th>
                <th width="65" id="printHead" class="headPrint">Price</th>
                <th width="30" id="printHead" class="headPrint">QTY</th>
                <th width="90" id="printHead1" class="headPrint">Total</th>
            </tr>

            <tbody id="printTableData">

            </tbody>

        </table>

        <table id="printTable3">
            <tr>
                <td align="center" style="border-bottom: hidden; border-left: hidden; border-right: hidden; text-align: center;" width="700">This is computer generated copy, Signature is not Required</td>
            </tr>
        </table>
    </div>



    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/js/jsMyOrders.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/print.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>
    <script src="js/js/jsReview.js"></script>
    
</body>

</html>
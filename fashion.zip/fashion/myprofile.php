<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description"
        content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <style>
        .update-photo {
            padding: 7px 13px 5px !important;
            margin-left: 28px;
            display: none;
        }

        input[type="file"] {
            display: none;
        }

        .custom-file-upload {
            /* border: 1px solid #ccc; */
            display: inline-block;
            /* padding: 6px 12px; */
            cursor: pointer;
            width: 10px;
            text-align: center;
            width: 50px;
            position: relative;
            bottom: 40px;
            left: 123px;
            color: white;
        }
        .profile-image{
            border-radius: 50%;
            width: 200px;
            height: 181px;
        }
    </style>

</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>My Profile</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <!-- My Profile Begin -->
    <div class="my-profile mt-5">
        <div class="container">
            <div class="mobile-quick-access">
                <div class="row">
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center my-profile-color">
                        <a href="myprofile.php" class="text-white">My Profile</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow  p-2 text-center">
                        <a href="my_orders.php" class="text-dark">My Orders</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="mlm.php" class="text-dark">My Network</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="add_address.php" class="text-dark">Add Address</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="my_credit_history.php" class="text-dark">My Credits</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="withdraw.php" class="text-dark">My Withdrawal</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="kyc.php" class="text-dark">My KYC</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="identity_card.php" class="text-dark">My ID</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="networking_business_plan.php" class="text-dark">N & B Plans</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3 desktop-quick-access">
                    <div class="profile-q-title ">
                        <h4>Quick Access</h4>
                    </div>
                    <ul class="quick-menu">
                        <li class="list"><a href="myprofile.php">My Profile</a></li>
                        <li class="list"><a href="my_orders.php">My Orders</a></li>
                        <li class="list"><a href="mlm.php">My Network</a></li>
                        <li class="list"><a href="add_address.php">Add Address</a></li>
                        <li class="list"><a href="my_credit_history.php">My Credits</a></li>
                        <li class="list"><a href="withdraw.php">My Withdrawal</a></li>
                        <li class="list"><a href="kyc.php">My KYC</a></li>
                        <li class="list"><a href="identity_card.php">My ID</a></li>
                        <li class="list"><a href="networking_business_plan.php">N & B Plans</a></li>

                    </ul>
                </div>
                <div class="col-md-9">
                    <div class="my-profile-image">
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <img src="img/myprofile.png" alt="My Profile Image" class="img-responsive profile-image" id="profileImage">
                                <label class="custom-file-upload text-center">
                                    <input type="file" id="uploadProfileImage" onChange="uploadImage()"/>
                                    <i class="fa fa-camera" aria-hidden="true"></i>
                                </label>
                                <!-- <div class="my-profile-section">
                                    <input type="button" value="Upload" style="color: #ffffff;background: #e7ab3c;border: 1px solid #e7ab3c;" id="uploadImage"/>
                                </div> -->
                                <button class="update-photo btn btn-primary">update photo</button>

                            </div>
                            <div class="col-md-4 mt-3 col-6">
                                <div class="my-profile-name">
                                    <div>
                                        <h3 id="headName" style="display:inline">Your Name</h3>
                                        <span id="rank"></span>
                                    </div>
                                    <span>Update your profile</span>
                                </div>

                                <div class="my-profile-referal-code mt-2">
                                    <span>Referal Code</span>
                                    <div style="" class="mt-2">
                                        <input type="text" id="myInput"
                                            style="border: none;display: inline;font-weight: bold;" size="8" readonly>
                                        <i class="fa fa-clone" aria-hidden="true" onclick="myFunction()"
                                            style=" margin-top: 5px; color: #e7ab3c; font-weight: bold;font-size: 20px;">
                                            <span class="tooltiptext" id="myTooltip" style="font-size:15px"></span>
                                        </i>
                                    </div>
                                </div>

                                <div class="my-profile-referal-code mt-3">
                                    <span>Wallet Amount</span>
                                    <div style="display: flex;" class="mt-2">
                                        ₹ &nbsp;<input type="text" value="" id="myWallet"
                                            style="border: none;display: inline;font-weight: bold;" size="8" readonly>

                                    </div>
                                </div>

                                <div class="my-profile-referal-code mt-3">
                                    <span>My Coins</span>
                                    <div style="display: flex;" class="mt-2">
                                        <input type="text" value="" id="myCoins"
                                            style="border: none; display: inline;font-weight: bold;" size="8" readonly>

                                    </div>
                                </div>

                                <div class="my-profile-referal-code mt-3">
                                    <span>Team BV</span>
                                    <div style="display: flex;" class="mt-2">
                                        <input type="text" value="0" id="myTeamBV"
                                            style="border: none; display: inline; font-weight: bold;" size="8" readonly>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="profile-section">
                        <h2 class="mt-5">Your Information</h2>
                    </div>
                    <form action="#" method="get">
                        <div class="my-profile-section">
                            <label for="username">Name</label>
                            <input type="text" id="txtName">
                        </div>
                        <div class="my-profile-section">
                            <label for="email">Email</label>
                            <input type="text" id="txtEmailID">
                        </div>
                        <div class="my-profile-section">
                            <label for="phone-no">Mobile No.</label>
                            <input type="text" id="txtMobileNo" readonly>
                        </div>
                        <div class="my-profile-section">
                            <label for="phone-no">Occupation.</label>
                            <input type="text" id="txtDesignation">
                        </div>
                        <div class="my-profile-section">
                            <label for="phone-no">Blood Group.</label>
                            <select class="form-select" aria-label="Default select example" id="selBloodGroup">
                                <option selected>Select Blood Group</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                            </select>
                        </div>
                        <!-- <div class="my-profile-section d-none">
                            <label for="password">Password</label>
                            <input type="text" id="txtPassword">
                        </div> -->

                        <div class="my-profile-section">
                            <br>
                            <button type="button" id="updateProfile">Update Profile</button>

                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>


    <!-- My Profile Begin -->

    <!-- Partner Logo Section Begin -->
    <div class="partner-logo">
        <div class="container">
            <div class="logo-carousel owl-carousel">
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-1.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-2.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-3.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-4.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-5.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Partner Logo Section End -->

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsMyProfile.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>

    <script>

        function myFunction() {
            let checkCopyText = document.getElementById("myInput").value;

            if (checkCopyText == "No Referral") {
                alert("Please purchase product for Referral Code");
                return false;
            }

            let copyText = document.getElementById("myInput");

            copyText.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(copyText.value);

            let tooltip = document.getElementById("myTooltip");
            tooltip.innerHTML = "Copied ";

            setTimeout(() => {
                tooltip.innerHTML = "";
            }, 2000);
        }
    </script>
</body>

</html>
<?php

session_start();

include_once('conn/conn.php');
$db = new DatabaseClass();
$con = $db->getCon();
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>Networking and Business Plans</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <!-- My Profile Begin -->
    <div class="my-profile mt-5">
        <div class="container">
            <div class="mobile-quick-access">
                <div class="row">
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="myprofile.php" class="text-dark">My Profile</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="my_orders.php" class="text-dark">My Orders</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="mlm.php" class="text-dark">My Network</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="add_address.php" class="text-dark">Add Address</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="my_credit_history.php" class="text-dark">My Credits</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="withdraw.php" class="text-dark">My Withdrawal</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="kyc.php" class="text-dark">My KYC</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="identity_card.php" class="text-dark">My ID</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center my-profile-color">
                        <a href="networking_business_plan.php" class="text-white">N & B Plans</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3 desktop-quick-access">
                <div class="profile-q-title ">
                        <h4>Quick Access</h4>
                    </div>
                    <ul class="quick-menu">
                        <li class="list"><a href="myprofile.php">My Profile</a></li>
                        <li class="list"><a href="my_orders.php">My Orders</a></li>
                        <li class="list"><a href="mlm.php">My Network</a></li>
                        <li class="list"><a href="add_address.php">Add Address</a></li>
                        <li class="list"><a href="my_credit_history.php">My Credits</a></li>
                        <li class="list"><a href="withdraw.php">My Withdrawal</a></li>
                        <li class="list"><a href="kyc.php">My KYC</a></li>
                        <li class="list"><a href="identity_card.php">My ID</a></li>
                        <li class="list"><a href="networking_business_plan.php">N & B Plans</a></li>

                    </ul>
                </div>


                <div class="text-center col-md-9">
                <div class="network-section">
                    <h2 class="text-center fs-1">Networking  <span> & </span> Business Plans</h2>
                </div>
                    <div class="network-btn">
                        <button type="button" class="n-bt" id="Images">Images</button>
                        <button type="button" class="n-bt" id="PDF">PDF</button>
                        <button type="button" class="n-bt" id="Videos">Videos</button>
                    </div>
                    <!-- <h4 class="text-center">Images</h4> -->
                    <div class="container">
                        <div class="row" id="imageDetails"></div>
                    </div>
                    <!-- <h4 class="text-center mt-5">PDF`s</h4> -->
                    <div class="container">
                        <div class="row" id="pdfDetails"></div>
                    </div>
                    <!-- <h4 class="text-center mt-5">Videos</h4> -->
                    <div class="container">
                        <div class="row" id="videoDetails"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsCompanyNetwork.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>

</body>

</html>
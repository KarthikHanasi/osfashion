<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>

   <!-- Header Section Begin -->
   <?php include_once('includes/header.php') ?>
    <!-- Header End -->


    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>Privacy & Policy</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <div class="privacy-policy">
        <div class="container">
            <div class="row">
                <div class="col-md">
                    <h2 class="mb-4 mt-4">Privacy <span>&</span> Policy</h2>
                    <div class="mb-5">
                        <p>Thank you for visiting www.osfashion.in As used in this privacy statement, the terms “our”, ”we” and “us” refer to ONESTEP FASHION NETWORK PVT. LTD (“OS FASHION”) and the terms “You”, “Your”, “User” refer to Customer unless the context provides otherwise. This privacy policy sets out how ONE STEP FASHION NETWORK uses and protects any information that you give us when you use this website. ONESTEP FASHION NETWORK PVT.LTD is committed to ensuring that your privacy is always protected. Should we ask you to provide certain information by which you can be identified when using this website, and then you can be
                             assured that it will only be used in accordance with this privacy statement.</p>
                        <p>What Information We Collect and How We Use the information collected on our website comes under two general categories-</p>
                        <ul>
                            <li><p>Personally Identifiable Information</p></li>
                            <li><p>Aggregate Information</p></li>
                        </ul>
                        <ol>
                            <li><p>Personally Identifiable Information</p></li>
                            <p>Personally Identifiable Information refers to information that lets us know who you are or things specifically about you.</p>
                            <ol type="A">
                                <li><p><b>Visitors:</b>As visitors you can browse our website without sharing any Personally Identifiable Information. If you want to register with us as a customer or place an order, you may voluntarily provide your Personally Identifiable Information (name, address, email address or telephone number) We might also maintain a record of your contact information to help us provide better services in case you contact us again.</p></li>
                                <li><p><b>Ordering:</b>When you place an order on our website, Personally Identifiable Information (such as name, contact info, order info, credit card and other transaction info) will be collected for the purpose of processing and delivering your order. We may also provide certain necessary order details to our shipping partners to complete the delivery of the order.</p></li>
                                <li><p><b>Credit/Debit Card Storage:</b>The Credit/Debit Card Information collected for online shopping is used only to process payments for the orders and, it is not retained on our website. The information is securely transmitted to the bank, and we store only the transaction history such as reference number and amount paid information provided by the bank.</p></li>
                                <li><p><b>Surveys and Promotions:</b>You may voluntarily provide Personally Identifiable Information to participate in occasional surveys, user polls or to answer questionnaires. This information is used by us to improve our products and provide you better services. We may also use this information to provide you marketing and promotional information. If you do not wish to receive any such information, you can adjust the setting for the same through a link provided in the email communication.</p></li>

                            </ol>
                            <li><p>Aggregate Information.</p></li>
                           <p><b>Aggregate Information: </b>This refers to information that does not distinguish you as a particular individual. This information includes your browser and operating system type, your IP address, URL (Uniform Source Locator) of the website that directed you to our site and any search terms you enter on our site. Such information is aggregated by our web server to monitor the activities on the site and evaluate its performance. This helps us improve the features and functions on the website to provide you a satisfactory user experience. We might compile, publish, store, collect, promote, disclose or use any Aggregate Information. We generally do not correlate any Personally Identifiable Information with Aggregate Information. In case we do this, it will be protected as per the terms mentioned for Personally Identifiable Information in this Privacy Policy.</p>
                           <p><b>Security</b>we are committed to ensuring that your information is secure. In order to prevent unauthorized access or disclosure, we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online. It is your sole responsibility to safeguard the password created by you for your online account. In case you suspect that your password has been compromised, contact ONESTEP FASHION NETWORK PVT. LTD. Customer care as soon as possible. 
                            Since your Customer ID and account password are specific to you, you take full responsibility for any and all activity conducted on our site with your ID and password.
                            </p>
                        </ol>
                        <p><u><b>How we use cookies</b></u></p>
                        <p>A cookie is a small file which asks permission to be placed on your computer's hard drive. Once you agree, the file is added and the cookie helps analyze web traffic or lets you know when you visit a particular site. Cookies allow web applications to respond to you as an individual. The web application can tailor its operations to your needs, likes and dislikes by gathering and remembering information about your preferences. We use traffic log cookies to identify which pages are being used. This helps us analyze data about web page traffic and improve our website in order to tailor it to customer needs. We only use this information for statistical analysis purposes and then the data is removed from the system. Overall, cookies help us to provide you with a better website by enabling us to monitor which pages you find useful and which you do not. They also help online retailers to keep track of a user’s electronic shopping cart before completing a purchase. A cookie in no way gives us access to your computer or any information about you, other than the data you choose to share with us. We have to use cookie-based authentication to identify you as a registered customer or send cookies to your computer to support personalized features on our website like your country and language codes as well as shopping and browsing functions. You can choose to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. This may prevent you from taking full advantage of the website.</p>
                        <p><b>Use of Third-Party Media and Research Companies:</b></p>
                        <p> We may use third-party media and research companies to place ads for us on websites of other parties. Our site may also run third-party ads for specific Merchants and Service Partners with whom we link.</p>
                        <p><b>Links to other websites: </b></p>
                        <p>Our website may contain links to other websites of interest. However, once you have used these links to leave our site, you should note that we do not have any control over that other website. Therefore, we cannot be responsible for the protection and privacy of any information which you provide while visiting such sites and such sites are not governed by this privacy statement. You should exercise caution and look at the privacy statement applicable to the website in question.</p>
                        <p><u><b>Changes to this Statement:</b></u></p>
                        <p>Please check frequently for any updates or changes in this privacy policy before using our website or submitting any Personally Identifiable Information at our site. By using our Site, you acknowledge acceptance of this Privacy Statement in effect at the time of use.</p>
                        <p><u><b>Controlling your Personally Identifiable Information:</b></u></p>
                        <p>We try our best to ensure that the Personally Identifiable Information we collect on our site is current, accurate and complete. You may choose to restrict the collection or use of   your Personally Identifiable Information in the following ways:</p>
                        <p><b>Intellectual Property and Use of content on the ONE STEP FASHION NETWORK Website.</b></p>
                        <p> The ONESTEP FASHION NETWORK PVT.LTD Website “www.osfashion.in” and the content on the same are protected by intellectual property rights, including copyrights, trade names and trademarks, including the name ‘ONESTEP FASHION NETWORK’ and the ONESTEP FASHION logo, and are owned by ONESTEP FASHION NETWORK  PVT. LTD 
                        (“ONESTEP FASHION NETWORK”) or used by ONE STEP FASHION NETWORK under a license or with permission from the owner of such rights. The content protected by such intellectual property rights includes the design, layout, look, appearance, visuals, photographs, images, articles, stories and other content on the ONESTEP FASHION NETWORK Website. 
                        The content on the ONE STEP FASHION NETWORK website may only be reproduced, distributed, published or otherwise used only after prior written consent of ONESTEP FASHION NETWORK.
                        © 2023 ONE STEP FAHION NETWORK PVT.LTD | All rights reserved
                        </p>
                        <p><b>Shipping Policy:</b></p>
                        <p> Orders may be placed online at our E-commerce website ww.osfashion.in or picked up from the company office and / or from any of the shopping outlets (stores). Details are given below:</p>
                        <p><b>PICKUP FROM OFFICE OR SHOPPING OUTLET (STORES):</b></p>
                        <p>Pickup orders can be placed at any of the outlets (stores). Payment options for Pickup Orders can be Credit Card, Debit Card, Net Banking and by wallets etc. Pickup hours for all Outlets (stores) are:* Monday to Saturday 10:00 a.m. - 06:00 p.m.* Sunday (Closed) Please refers to website for www.osfashion.in updated information.</p>
                        <p><b>Home Delivery:</b></p>
                        <p> Home Delivery orders can be placed through our website  www.osfashion.in Payment mode for these online orders: Through payment gateway by Credit Card, Debit Card, Net Banking and by wallet etc.</p>
                        <p><b>Home Delivery Orders Delivery fees:</b></p>
                        <p> Please refer to the website www.osfashion.in for more details on Delivery fees. The shipments are in perfect condition when the carrier takes possession of the same. By signing “received” on the delivery note, the recipient(s) acknowledges that the order was received in satisfactory condition. Do not sign in the event of damages or product shortages. Hidden damages discovered after the carrier has left and all other discrepancies must be notified within twenty-four (24) hours of receipt of shipment. Failure to notify about any shipping discrepancy or damage to ONE STEP FASHION NETWORK Private Limited within twenty- four (24) hours of receipt of the shipment shall be considered deemed acceptance of the products. Orders placed are typically shipped the very next business day. Orders placed on Saturday will be shipped on the following Monday. Delivery time will vary according to the location of customers. The average time for delivery is in between 5 -7 working days. Delivery of the products may not be possible on Sundays or on major holidays as per the policy of the delivery partner</p>
                        <p><ul><b>Delivery of the Product</b></ul></p>
                        <ul>
                            <li><p>There are various delivery models for delivery of purchased Product to the Customers, as decided by ONESTEP FASHION NETWORK Pvt. Ltd. The risk and responsibility of any damage, loss or deterioration of the Products during the course or delivery or during transit shall be of ONESTEP FASHION NETWORK Company and not of the customer. ONE STEP FASHION NETWORK Pvt. Ltd. Ensures that the Products being delivered to the customers are not faulty and are exactly the same Products which are listed and advertised on the Website and all descriptions and specifications are same as provided on the Website.</p></li>
                            <li><p>Customer's shipping address, pin code is verified by the database on the Website before customers are directed for payment for their purchase. In case the order is not serviceable by logistic service providers or the delivery address is not located in the given pin code area, Customer may provide an alternate shipping address on which the Product can be delivered by the logistics service provider.</p></li>
                            <li><p>* Customers shall be bound to take delivery of the Products purchased by him/her. If any Customers neglects or refuses to accept the delivery of the Products ordered by him/her, the Customers may be liable to ONE STEP FASHION NETWORK Pvt. Ltd. for such non-acceptance of products. ONESTEP FASHION NETWORK Pvt. Ltd. at its own discretion may call up the customers to evaluate the reason of non-acceptance of the product. The decision of ONESTEP FASHION NETWORK Company would be final and binding on whether to redeliver or initiate refund process as per the refund policy.</p></li>
                            <li><p>The title in the Products and other rights and interest in the Products shall directly pass on to the customers from ONESTEP FASHION NETWORK Company. The risk or loss after delivery of goods/Product and after full payment of the Product will be borne by the customer.</p></li>
                            <li><p>Before accepting delivery of any Product, the Customer shall reasonably ensure that the Product's packaging is in good condition and is not damaged or tampered.</p></li>
                        </ul>

                        <p><b><ul>Governing Law</ul></b></p>
                        <ul>
                            <li><p>Any dispute in between customer and ONESTEP FASHION NETWORK Company, arising on any issue by this policy, shall be referred to the sole arbitrator (appointed by the company) and same shall be adjudicated by such Arbitrator as per provisions of Arbitration Conciliation Act, 1996. However, all proceedings shall come within the jurisdiction of Belagavi Courts only and such arbitration proceedings shall be held in District courts of Belagavi only.</p></li>
                            <li><p>* The final decision of the Arbitrator would be binding upon both the parties. Any breach of this covenant by the Customer will make him liable for damages and legal costs to the Company.</p></li>
                        </ul>
                        <p>© 2023 ONE STEP FAHION NETWORK PVT.LTD | All rights reserved</p>

                    </div>
                    

                </div>
            </div>
        </div>
    </div>

   
    
    <!-- Partner Logo Section Begin -->
    <div class="partner-logo">
        <div class="container">
            <div class="logo-carousel owl-carousel">
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-1.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-2.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-3.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-4.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-5.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Partner Logo Section End -->

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>
</body>

</html>
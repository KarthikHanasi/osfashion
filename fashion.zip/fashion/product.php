<!DOCTYPE html>
<html lang="zxx">

<head>
    <!-- <meta charset="UTF-8">
    <meta name="description" content="Products"> -->
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta property="og:title" content="One step fashion network.pvt ltd" />
    <meta property="og:url" content="https://www.osfashion.in" />
    <meta name="image" property="og:image" content="https://www.osfashion.in/img/logo.png" />
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta property="og:site_name" content="One step fashion network.pvt ltd" />

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="css/main.css" type="text/css">
    <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">

    <style>
        html {
            scroll-behavior: smooth;
        }

        #container {
            overflow: hidden;
        }

        #show-img {
            transform-origin: center;
            object-fit: cover;
            height: 100%;
            width: 100%;
        }
    </style>
</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <input type="hidden" value="<?php echo $_GET['id'] ?>" id="product_id">

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text product-more">
                        <a href="./home.php"><i class="fa fa-home"></i> Home</a>
                        <a href="./shop.php">Shop</a>
                        <span>Details</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Product Shop Section Begin -->
    <section class="product-shop spad page-details">
        <div class="container">
            <div class="row">
                
                <div class="col-sm-10">
                    <div class="row">
                        <div class="col-lg-6" id="products">
                        <div class="show" id="container">
                        </div>
                            <div class="small-img">
                                <img src="img/online_icon_right@2x.png" class="icon-left" alt="" id="prev-img">
                                <div class="small-container">
                                    <div id="small-img-roll">
                                    </div>
                                </div>
                                <img src="img/online_icon_right@2x.png" class="icon-right" alt="" id="next-img">
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="product-details">
                                <div id="product-details">
                                </div>

                                <div class="pd-size-choose" id="product-bvpv">
                                    
                                </div>

                                <div class="pd-size-choose" id="product-size"></div>
                            
                                <div class="pd-color">
                                    <!-- <h6>Color</h6> -->
                                    <div class="pd-color-choose" id="product-color"></div>
                                </div>

                                <div class="quantity">
                                    <div class="pro-qty">
                                        <input type="text" value="1" id="quantity">
                                    </div>
                                    <button type="button" class="primary-btn pd-cart" id="AddToCart"> Add To Cart</button>
                                </div>

                                <div class="quantity">
                                    <button type="button" class="primary-btn pd-cart" id="checkout">Continue to Checkout</button>
                                </div>

                                <div class="pd-share">
                                    <div class="p-code">

                                        <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                                            <a class="a2a_button_facebook"></a>
                                            <a class="a2a_button_twitter"></a>
                                            <a class="a2a_button_whatsapp"></a>
                                            <a class="a2a_dd" href="https://www.addtoany.com/share"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-tab">
                        <div class="tab-item">
                            <ul class="nav" role="tablist">
                                <li class="">
                                    <a class="active" data-toggle="tab" href="#tab-1" role="tab">DESCRIPTION</a>
                                </li>
                                <li class="d-none">
                                    <a data-toggle="tab" href="#tab-2" role="tab">SPECIFICATIONS</a>
                                </li>
                                <li>
                                    <a data-toggle="tab" href="#tab-3" role="tab" id="customerReviewCount">Customer Reviews (0)</a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-item-content">
                            <div class="tab-content">
                                <div class="tab-pane fade-in active" id="tab-1" role="tabpanel">
                                    <div class="product-content">
                                        <div class="row">
                                            <div class="col-lg-7" id="longDesc">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="tab-2" role="tabpanel">
                                    <div class="specification-table">
                                        <table id="specification">
                                            
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="tab-3" role="tabpanel">
                                    <div class="customer-review-option">
                                        <h4 id="reviewCount">2 Review</h4>
                                        <div class="comment-option" id="review">
                                        </div>
            
                                        <div class="leave-comment d-none">
                                            <h4>Leave A Review</h4>
                                            <form action="#" class="comment-form">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <input type="text" placeholder="Full Name" id="txtName">
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <input type="text" placeholder="Email" id="txtEmail">
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <select class="form-select" aria-label="Default select example" id="rating">
                                                        <option selected value="">Select Rating</option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <textarea placeholder="Write Review
                                                        " id="comment"></textarea>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <button type="button" class="site-btn" id="submitReview">Submit Review</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Product Shop Section End -->

    <!-- Related Products Section End -->
    <div class="related-products spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Related Products</h2>
                    </div>
                </div>
            </div>
            <div class="row" id="similarProducts">
                
            </div>
        </div>
    </div>
    <!-- Related Products Section End -->

    <!-- Partner Logo Section Begin -->
    <div class="partner-logo">
        <div class="container">
            <div class="logo-carousel owl-carousel">
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-1.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-2.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-3.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-4.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-5.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Partner Logo Section End -->

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/js/jsSingleProduct.js"></script>
    <script src="js/zoom-image.js"></script>
    <script src="js/js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>
    <script src="js/js/jsReview.js"></script>
    <script async src="https://static.addtoany.com/menu/page.js"></script>
    <script>
        // const container = document.getElementById("container");
        // const img = document.getElementById("show-img");

        // container.addEventListener("mousemove", (e) => {
        //     const x = e.clientX - e.target.offsetLeft;
        //     const y = e.clientY - e.target.offsetTop;

        //     img.style.transformOrigin = `${x}px ${y}px`;
        //     img.style.transform = "scale(2)";

        // });

        // container.addEventListener("mouseleave", () => {
        //     img.style.transformOrigin = "center";
        //     img.style.transform = "scale(1)";
        // });
    </script>

</body>

</html>


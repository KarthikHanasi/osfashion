<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="www.osfashion.in, osfashion, fashion, belagavi">
    <meta property="og:description" content="We M/s One Step Fashions Pvt Ltd are a Belagavi based company, we are into the business of Manufacturing and trading of apparels (Clothing) for men, women and kids for the past 3 decades, we are also into Tourism Industry." />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OsFashion</title>
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>

    <!-- Header Section Begin -->
    <?php include_once('includes/header.php') ?>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text product-more">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <!-- <a href="shop.php">Shop</a> -->
                        <span>My Withdrawal</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Shopping Cart Section Begin -->
    <section class="my-profile my-5">
        <div class="container">
            <div class="mobile-quick-access">
                <div class="row">
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="myprofile.php" class="text-dark">My Profile</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow  p-2 text-center ">
                        <a href="my_orders.php" class="text-dark">My Orders</a>

                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="mlm.php" class="text-dark">My Network</a>
                    </div>
                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="add_address.php" class="text-dark">Add Address</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="my_credit_history.php" class="text-dark">My Credits</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center my-profile-color">
                        <a href="withdraw.php" class="text-white">My Withdrawal</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="kyc.php" class="text-dark">My KYC</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="identity_card.php" class="text-dark">My ID</a>
                    </div>

                    <div class="col-5 card ml-3 mb-3 shadow p-2 text-center">
                        <a href="networking_business_plan.php" class="text-dark">N & B Plans</a>
                    </div>
                </div>
            </div>   

            <div class="row">
                <div class="col-md-3 desktop-quick-access">
                    <h4>Quick Access</h4>
                    <ul class="quick-menu">
                        <li class="list"><a href="myprofile.php">My Profile</a></li>
                        <li class="list"><a href="my_orders.php">My Orders</a></li>
                        <li class="list"><a href="mlm.php">My Network</a></li>
                        <li class="list"><a href="add_address.php">Add Address</a></li>
                        <li class="list"><a href="my_credit_history.php">My Credits</a></li>
                        <li class="list"><a href="withdraw.php">My Withdrawal</a></li>
                        <li class="list"><a href="kyc.php">My KYC</a></li>
                        <li class="list"><a href="identity_card.php">My ID</a></li>
                        <li class="list"><a href="networking_business_plan.php">N & B Plans</a></li>
                    </ul>
                </div>
                <div class="col-lg-8">
                    <div class="order-table">

                    <div class="row">
                        <div class="form-group col-sm-4">
                            <label>From Date</label>
                            <input type="date" id="fromDate" class="form-control">
                        </div>

                        <div class="form-group col-sm-4">
                            <label>To Date</label>
                            <input type="date" id="toDate" class="form-control">
                        </div>

                        <div class="form-group col-sm-3">
                            <label>Search</label>
                            <input type="button" id="btnSearch" class="primary-btn form-control" value="Search" style="padding: 4px 30px;" onclick="searchRes();">
                        </div>
                    </div>
                <div class="col-lg-14">
                    <div class="order-table">
                        <table id="" class="table">
                            <thead>
                                <tr>
                                    <th>Sl.No</th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Transaction ID</th>
                                    <th>A/C Name</th>
                                    <th>A/C Number</th>
                                    
                                </tr>
                            </thead>
                            <tbody id="withdrawalsDetails">
                               
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <!-- <div class="cart-buttons">
                                <a href="shop.php" class="primary-btn up-cart">Continue shopping</a>
                            </div>
                            -->
                        </div>
                        <div class="col-lg-4 offset-lg-4">
                            <div class="proceed-checkout">
                                <ul>
                                    <li class="cart-total">Total ₹<span id="totalAmount">0.00</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section Begin -->
    <?php include_once('includes/footer.php'); ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/js/jsMyWithdrawals.js"></script>
    <script src="js/main.js"></script>
    <script src="js/aes.js"></script>
    <script src="js/print.js"></script>
    <script src="js/js/jsCollectionCart.js"></script>
    <script src="js/js/jsReview.js"></script>
    
</body>

</html>